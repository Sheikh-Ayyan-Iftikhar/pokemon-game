-- ModuleScript
-- Location: ServerScriptService > Server > InventoryService
-- Pokemon ownership. Every Pokemon is a UNIQUE instance (uid) so stealing/wagers move one specific instance.
local HttpService = game:GetService("HttpService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local PokemonData = require(ReplicatedStorage.Shared.Config.PokemonData)
local Economy = require(ReplicatedStorage.Shared.Config.Economy)
local DataService = require(script.Parent.DataService)
local SyncService = require(script.Parent.SyncService)
local LoadoutService = require(script.Parent.LoadoutService)

local Inventory = {}

local function countOwned(data)
	local n = 0
	for _ in pairs(data.Owned) do n += 1 end
	return n
end

function Inventory.Grant(player, pokemonId)
	local data = DataService.Get(player)
	if not data then return nil, "NoData" end
	if not PokemonData.Get(pokemonId) then return nil, "UnknownPokemon" end
	if countOwned(data) >= Economy.MaxOwned then return nil, "CollectionFull" end
	local uid = HttpService:GenerateGUID(false)
	data.Owned[uid] = { Id = pokemonId, Obtained = os.time() }
	SyncService.Queue(player)
	return uid
end

function Inventory.Owns(player, uid)
	local data = DataService.Get(player)
	return data ~= nil and data.Owned[uid] ~= nil
end

-- Hard remove (stealing, wager loss). Also unstations and clears loadout slots.
function Inventory.Remove(player, uid)
	local data = DataService.Get(player)
	if not data or not data.Owned[uid] then return false end
	data.Owned[uid] = nil
	local idx = table.find(data.Stationed, uid)
	if idx then table.remove(data.Stationed, idx) end
	LoadoutService.ClearUid(data, uid)
	SyncService.Queue(player)
	return true
end

function Inventory.Buy(player, pokemonId)
	local data = DataService.Get(player)
	if not data then return false, "NoData" end
	local def = PokemonData.Get(pokemonId)
	if not def then return false, "UnknownPokemon" end
	if not Economy.PurchasableRarities[def.Rarity] then return false, "NotForSale" end
	local price = Economy.RarityPrice[def.Rarity]
	if data.Coins < price then return false, "NotEnoughCoins" end
	if countOwned(data) >= Economy.MaxOwned then return false, "CollectionFull" end

	-- No yields between check and change, so this is atomic.
	data.Coins -= price
	local uid = Inventory.Grant(player, pokemonId)
	return true, uid
end

function Inventory.Init(Router)
	Router.Register("Buy", { rate = 1, burst = 3 }, function(player, p)
		if not Router.IsId(p.pokemonId) then return false, "BadRequest" end
		return Inventory.Buy(player, p.pokemonId)
	end)
end

return Inventory
