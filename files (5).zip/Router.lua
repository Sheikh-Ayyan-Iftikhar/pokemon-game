-- ModuleScript
-- Location: ServerScriptService > Server > Router
-- Single entry point for every client request: validates, rate-limits, dispatches.
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Remotes = require(ReplicatedStorage.Shared.Remotes)
local DataService = require(script.Parent.DataService)
local RateLimiter = require(script.Parent.RateLimiter)

local Router = {}
local handlers = {}

-- opts = { rate = requests/second, burst = max burst }
function Router.Register(action, opts, fn)
	assert(not handlers[action], "Duplicate action: " .. action)
	handlers[action] = { fn = fn, rate = opts.rate or 2, burst = opts.burst or 4 }
end

-- Validation helper for ids/uids/slot names coming from the client.
function Router.IsId(x)
	return type(x) == "string" and #x >= 1 and #x <= 64 and string.match(x, "^[%w_%-]+$") ~= nil
end

function Router.Start()
	local rf = Remotes.Get("Request")
	rf.OnServerInvoke = function(player, action, payload)
		if type(action) ~= "string" then
			return false, "BadRequest"
		end
		local h = handlers[action]
		if not h then
			return false, "UnknownAction"
		end
		if not RateLimiter.Allow(player, action, h.rate, h.burst) then
			return false, "RateLimited"
		end
		if type(payload) ~= "table" then
			payload = {}
		end
		if not DataService.Get(player) then
			return false, "NoData"
		end
		local ok, a, b = pcall(h.fn, player, payload)
		if not ok then
			warn("[Router] error in '" .. action .. "': " .. tostring(a))
			return false, "ServerError"
		end
		return a, b
	end
end

return Router
