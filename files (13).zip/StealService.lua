-- ModuleScript
-- Location: ServerScriptService > Server > StealService
-- Architecture doc flow: thief enters a vulnerable base -> takes a Pokemon -> owner can respond ->
-- ownership transfers ONLY if the thief gets it back to their OWN base. Previous owner loses income + equipped ability.
-- Only players in the SAME server can be stolen from (offline/other-server bases are never touched: that is the safe way to do it).
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local StealCfg = require(ReplicatedStorage.Shared.Config.StealConfig)
local DataService = require(script.Parent.DataService)
local InventoryService = require(script.Parent.InventoryService)
local BaseService = require(script.Parent.BaseService)
local BaseWorld = require(script.Parent.BaseWorld)
local Combat = require(script.Parent.CombatService)
local Locks = require(script.Parent.Locks)
local Notify = require(script.Parent.Notify)
local TransferJournal = require(script.Parent.TransferJournal)

local Steal = {}
local carrying = {}  -- [thief] = { Uid, Owner, Started }
local lastSteal = {}
local leaving = {}   -- players whose session is closing: never touch their data

local MESSAGES = {
	OwnBase = "That is your own base.", NoBase = "You need a base to deliver stolen Pokemon to.",
	AlreadyCarrying = "You are already carrying a Pokemon.", BaseLocked = "This base is locked.",
	InMatch = "Not possible during a match.", Dead = "You are down.", TooFar = "Too far from the pedestal.",
	NoData = "Data not ready.", Empty = "Nothing there.", AlreadyStolen = "Someone is already taking it.",
	Cooldown = "Wait a moment before stealing again.", OwnerLeaving = "The owner is leaving.",
}

-- Returns ok, errCode, context
function Steal.CanTarget(thief, slot, index)
	local owner = slot.Owner
	if not owner or owner == thief then return false, "OwnBase" end
	if leaving[owner] or leaving[thief] then return false, "OwnerLeaving" end
	if not BaseWorld.GetBase(thief) then return false, "NoBase" end
	if carrying[thief] then return false, "AlreadyCarrying" end
	if slot.LockedUntil > os.clock() then return false, "BaseLocked" end
	if thief:GetAttribute("InMatch") or owner:GetAttribute("InMatch") then return false, "InMatch" end
	local ent = Combat.EntityOf(thief)
	if not ent then return false, "Dead" end
	local ped = slot.Pedestals[index]
	if not ped then return false, "Empty" end
	if (ent.Root.Position - ped.Position).Magnitude > StealCfg.Range then return false, "TooFar" end
	local od, td = DataService.Get(owner), DataService.Get(thief)
	if not od or not td then return false, "NoData" end
	local uid = od.Stationed[index]
	if not uid then return false, "Empty" end
	if Locks.IsLocked(uid) then return false, "AlreadyStolen" end
	if os.clock() < (lastSteal[thief] or 0) + StealCfg.Cooldown then return false, "Cooldown" end
	return true, nil, { Ent = ent, Owner = owner, Uid = uid }
end

local function clearRaid(thief)
	thief:SetAttribute("Carrying", nil)
	thief:SetAttribute("RaidTarget", nil)
	local model = thief.Character
	if model then Combat.RemoveStatus(model, "CarryingPokemon") end
end

local function finish(thief, c, success, reason)
	if carrying[thief] ~= c then return end
	carrying[thief] = nil

	if success and not leaving[thief] and not leaving[c.Owner] then
		-- 1) Record the intent in the TransferJournal while the Pokemon is still locked (this call yields).
		local od = DataService.Get(c.Owner)
		local inst = od and od.Owned[c.Uid]
		local journaled = inst and TransferJournal.Begin(c.Uid, inst, c.Owner.UserId, thief.UserId)
		-- 2) From here on: no yields. Unlock and transfer together.
		Locks.Unlock(c.Uid)
		clearRaid(thief)
		if not journaled then
			Notify.Send(thief, "Could not complete the steal right now. The Pokemon returned.", "bad")
			Notify.Send(c.Owner, "Your Pokemon is safe.", "good")
			return
		end
		if leaving[thief] or leaving[c.Owner] then
			return -- someone left while journaling: the journal finishes the transfer on their next load
		end
		local ok, err = InventoryService.Transfer(c.Owner, thief, c.Uid)
		if ok then
			BaseService.Station(thief, c.Uid) -- fails harmlessly if the thief's base is full; stays owned, unstationed
			-- Save both sides, then delete the journal entry. If the server dies before this, the journal repairs it on next load.
			task.spawn(function()
				local savedThief = DataService.SaveNow(thief)
				local savedOwner = DataService.SaveNow(c.Owner)
				if savedThief and savedOwner then
					TransferJournal.Complete(c.Uid, c.Owner.UserId, thief.UserId)
				end
			end)
			Notify.Send(thief, "You stole a Pokemon!", "good")
			Notify.Send(c.Owner, "A Pokemon was stolen from your base!", "bad")
			return
		end
		Notify.Send(thief, "The steal will finish automatically (" .. tostring(err) .. ").", "info")
		return
	end

	Locks.Unlock(c.Uid)
	clearRaid(thief)
	Notify.Send(thief, reason or "The Pokemon returned to its owner.", "bad")
	Notify.Send(c.Owner, "Your Pokemon is safe again.", "good")
end

local function carryLoop(thief, c)
	while carrying[thief] == c do
		if not thief.Parent or leaving[thief] or leaving[c.Owner] then return finish(thief, c, false, "Steal cancelled.") end
		local ent = Combat.EntityOf(thief)
		if not ent then return finish(thief, c, false, "You were knocked out. The Pokemon returned.") end
		local od = DataService.Get(c.Owner)
		if not od or not od.Owned[c.Uid] then return finish(thief, c, false, "Steal cancelled.") end
		if os.clock() - c.Started > StealCfg.CarryTime then return finish(thief, c, false, "Too slow! The Pokemon returned.") end

		local mine = BaseWorld.GetBase(thief)
		if mine and (ent.Root.Position - mine.Delivery.Position).Magnitude <= StealCfg.DeliveryRadius then
			return finish(thief, c, true)
		end
		task.wait(0.25)
	end
end

-- Hold started: both players may fight from now on (owner can react during the hold).
function Steal.RaidBegin(thief, slot, index)
	local ok, _, ctx = Steal.CanTarget(thief, slot, index)
	if not ok then return end
	thief:SetAttribute("RaidTarget", ctx.Owner.UserId)
	Notify.Send(ctx.Owner, thief.DisplayName .. " is stealing from your base!", "bad")
	task.delay(StealCfg.RaidGrace, function()
		if not carrying[thief] then thief:SetAttribute("RaidTarget", nil) end
	end)
end

function Steal.Attempt(thief, slot, index)
	local ok, err, ctx = Steal.CanTarget(thief, slot, index)
	if not ok then
		Notify.Send(thief, MESSAGES[err] or "Cannot steal that.", "bad")
		return
	end
	lastSteal[thief] = os.clock()
	local c = { Uid = ctx.Uid, Owner = ctx.Owner, Started = os.clock() }
	carrying[thief] = c
	Locks.Lock(ctx.Uid, "carried")
	thief:SetAttribute("Carrying", ctx.Uid)
	thief:SetAttribute("RaidTarget", ctx.Owner.UserId)
	Combat.AddStatus(ctx.Ent.Model, "CarryingPokemon", nil, { Speed = StealCfg.CarrySpeed })
	Notify.Send(thief, "Run to your base's green pad!", "good")
	Notify.Send(ctx.Owner, thief.DisplayName .. " grabbed a Pokemon! Stop them!", "bad")
	task.spawn(carryLoop, thief, c)
end

-- Owner-side defensive system: lock the base for a while, then a cooldown.
function Steal.LockBase(player)
	local slot = BaseWorld.GetBase(player)
	if not slot then return false, "NoBase" end
	local now = os.clock()
	if slot.LockedUntil > now then return false, "AlreadyLocked" end
	if now < slot.LockCooldownUntil then return false, "OnCooldown" end
	slot.LockedUntil = now + StealCfg.LockDuration
	slot.LockCooldownUntil = slot.LockedUntil + StealCfg.LockCooldown
	Notify.Send(player, ("Base locked for %d seconds."):format(StealCfg.LockDuration), "good")
	return true
end

-- MUST be called synchronously on PlayerRemoving, BEFORE DataService.Release.
function Steal.OnLeaving(player)
	leaving[player] = true
	local mine = carrying[player]
	if mine then finish(player, mine, false, "Steal cancelled.") end
	for thief, c in pairs(carrying) do
		if c.Owner == player then finish(thief, c, false, "The owner left. The steal was cancelled.") end
	end
	lastSteal[player] = nil
	task.delay(10, function() leaving[player] = nil end)
end

function Steal.Init(Router)
	BaseWorld.OnHold = Steal.RaidBegin
	BaseWorld.OnTrigger = Steal.Attempt
	Router.Register("LockBase", { rate = 1, burst = 2 }, function(player) return Steal.LockBase(player) end)
end

return Steal
