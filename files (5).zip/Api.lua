-- ModuleScript
-- Location: StarterPlayer > StarterPlayerScripts > Api
-- Thin client wrapper. The client only displays state and REQUESTS actions; the server decides everything.
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Remotes = require(ReplicatedStorage.Shared.Remotes)

local Api = { State = nil }
local changed = Instance.new("BindableEvent")
Api.Changed = changed.Event

-- Returns ok:boolean, result_or_errorCode
function Api.Request(action, payload)
	local ok, success, result = pcall(function()
		return Remotes.Get("Request"):InvokeServer(action, payload or {})
	end)
	if not ok then
		return false, "NetworkError"
	end
	return success, result
end

function Api.Start()
	Remotes.Get("Sync").OnClientEvent:Connect(function(state)
		Api.State = state
		changed:Fire(state)
	end)
	local ok, state = Api.Request("GetState")
	if ok and state then
		Api.State = state
		changed:Fire(state)
	end
end

return Api
