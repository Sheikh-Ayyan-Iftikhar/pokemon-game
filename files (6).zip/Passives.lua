-- ModuleScript
-- Location: ReplicatedStorage > Shared > Config > Passives
-- Passive Pokemon effects. Rules = condition + stat mods. Triggers = timed/one-off behaviours (see Server/PassiveService.lua).
-- Mod keys: DamageDealt, DamageTaken, DamageTakenNonDimensional, BasicDamageTaken, AbilityPower, Speed, Dash, MaxHealth, MaxStamina (multipliers);
--           Dodge, Reflect (0..1 added); RevealCooldowns (bool).
-- Where the doc was unclear, I picked the reading marked AMBIGUOUS. Change it here (one line each).
return {
	-- AMBIGUOUS: doc ends with "WHEN HEALTH LESS THAN 40%". Reading: +40% HP/stamina always, -60% damage only below 40% HP.
	GROUDON = { Rules = {
		{ When = "Always", Mods = { MaxHealth = 1.4, MaxStamina = 1.4 } },
		{ When = "HpBelow", Ratio = 0.4, Mods = { DamageTakenNonDimensional = 0.4 } },
	} },
	-- Regenerates health for 10s once HP < 30%. Heal amount is not in the doc: 20% max HP total (bestiary cap for one heal).
	DRAGONITE = { Triggers = { { Type = "RegenOnce", Ratio = 0.3, Seconds = 10, TotalPct = 0.2 } } },
	-- AMBIGUOUS: "10 seconds, in every 6 seconds". Implemented literally: a new random +30% buff every 6s, each lasting 10s (they overlap).
	DEOXYS = { Triggers = { { Type = "CycleBuff", Every = 6, Duration = 10, Boost = 1.3 } } },
	MEW = { Triggers = { { Type = "MewBorrow", Charges = 2 } } },
	GARDEVOIR = { Rules = { { When = "HpBelow", Ratio = 0.4, Mods = { RevealCooldowns = true } } } },
	ALAKAZAM = { Rules = { { When = "HpBelow", Ratio = 0.2, Mods = { Dodge = 0.4 } } } },
	GENGAR = { Triggers = { { Type = "RandomInvisible", Every = 15, Duration = 4, When = "Night" } } },
	SNORLAX = { Rules = { { When = "HpBelow", Ratio = 0.15, Mods = { DamageTaken = 0.5 } } } },
	SYLVEON = { Rules = { { When = "Always", Mods = { BasicDamageTaken = 0.8 } } } },
	UMBREON = { Rules = { { When = "Night", Mods = { AbilityPower = 1.05 } } } },
	EEVEE = { Rules = { { When = "Always", Mods = { Dash = 1.15 } } } },
	BULBASAUR = { Rules = { { When = "Day", Mods = { MaxHealth = 1.05, MaxStamina = 1.05, Speed = 1.05, DamageDealt = 1.05, Dash = 1.05 } } } },
	CHARMANDER = { Rules = { { When = "HpBelow", Ratio = 0.5, Mods = { DamageDealt = 1.15 } } } },
}
