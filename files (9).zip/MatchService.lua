-- ModuleScript
-- Location: ServerScriptService > Server > MatchService
-- Ranked PvP (Elo, no Pokemon at stake) and Wager PvP (winner receives the loser's wagered Pokemon).
-- Safe-by-default rules:
--   * Wagered Pokemon are LOCKED from the moment both players confirm until the match is settled.
--   * A Pokemon only ever moves on an explicit win. Draw, time-out, disconnect, error, no arena, server shutdown = nobody loses anything.
--   * Settlement is idempotent (Phase flips to "Ended" once) so a payout can never happen twice.
-- Only players in the SAME server can be matched (cross-server queue needs MemoryStoreService + reserved servers: later phase).
local Players = game:GetService("Players")
local HttpService = game:GetService("HttpService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local PvpCfg = require(ReplicatedStorage.Shared.Config.PvpConfig)
local Rarity = require(ReplicatedStorage.Shared.Config.Rarity)
local PokemonData = require(ReplicatedStorage.Shared.Config.PokemonData)
local Economy = require(ReplicatedStorage.Shared.Config.Economy)
local DataService = require(script.Parent.DataService)
local SyncService = require(script.Parent.SyncService)
local InventoryService = require(script.Parent.InventoryService)
local BaseService = require(script.Parent.BaseService)
local Combat = require(script.Parent.CombatService)
local PassiveService = require(script.Parent.PassiveService)
local Locks = require(script.Parent.Locks)
local Notify = require(script.Parent.Notify)

local Match = {}
local queue = {}    -- [Player] = { Joined }
local invites = {}  -- [id] = { Id, A, B, UidA, UidB, Stage, ExpiresAt }
local matches = {}  -- [id] = match
local byPlayer = {} -- [Player] = match
local leaving = {}

-- ---------- arenas ----------
local arenas = {}
local usePlaceholders = true

local function buildPlaceholderArena(i)
	local model = Instance.new("Model")
	model.Name = "Arena" .. i
	local c = Vector3.new(i * 300, 8000, 0)
	local function part(name, size, pos, solid)
		local p = Instance.new("Part")
		p.Name = name
		p.Anchored = true
		p.Size = size
		p.Position = pos
		p.Parent = model
		if not solid then
			p.Transparency = 1
			p.CanCollide = false
		end
		return p
	end
	local floor = part("Floor", Vector3.new(140, 2, 140), c, true)
	floor.Color = Color3.fromRGB(60, 60, 75)
	for _, w in ipairs({
		{ Vector3.new(140, 60, 2), Vector3.new(0, 30, 70) }, { Vector3.new(140, 60, 2), Vector3.new(0, 30, -70) },
		{ Vector3.new(2, 60, 140), Vector3.new(70, 30, 0) }, { Vector3.new(2, 60, 140), Vector3.new(-70, 30, 0) },
	}) do
		local wall = part("Wall", w[1], c + w[2], true)
		wall.Transparency = 1
	end
	local a = part("SpawnA", Vector3.new(4, 0.4, 4), c + Vector3.new(-40, 2, 0), false)
	local b = part("SpawnB", Vector3.new(4, 0.4, 4), c + Vector3.new(40, 2, 0), false)
	model.Parent = workspace
	return { Model = model, SpawnA = a, SpawnB = b, InUse = false }
end

-- Your own arenas: Models in Workspace > Arenas, each with parts named SpawnA and SpawnB.
local function initArenas()
	local folder = workspace:FindFirstChild("Arenas")
	if not folder then return end
	for _, model in ipairs(folder:GetChildren()) do
		local a, b = model:FindFirstChild("SpawnA"), model:FindFirstChild("SpawnB")
		if model:IsA("Model") and a and b then
			table.insert(arenas, { Model = model, SpawnA = a, SpawnB = b, InUse = false })
		end
	end
	if #arenas > 0 then usePlaceholders = false end
end

local function acquireArena()
	for _, a in ipairs(arenas) do
		if not a.InUse then a.InUse = true return a end
	end
	if usePlaceholders and #arenas < PvpCfg.MaxArenas then
		local a = buildPlaceholderArena(#arenas + 1)
		a.InUse = true
		table.insert(arenas, a)
		return a
	end
	return nil
end

-- ---------- helpers ----------
local function rarityIndex(r)
	return table.find(Rarity.Order, r) or 1
end

local function describe(data, uid)
	local inst = data.Owned[uid]
	local def = inst and PokemonData.Get(inst.Id)
	return def and (def.Name .. " (" .. def.Rarity .. ")") or "unknown"
end

local function countOwned(data)
	local n = 0
	for _ in pairs(data.Owned) do n += 1 end
	return n
end

local function cancelInvitesOf(player, reason)
	for id, inv in pairs(invites) do
		if inv.A == player or inv.B == player then
			invites[id] = nil
			local other = inv.A == player and inv.B or inv.A
			if reason then Notify.Send(other, reason, "bad") end
		end
	end
end

-- Can this player enter a ranked queue / wager / match right now?
local function eligible(p, ignoreQueue)
	if not p or not p.Parent or leaving[p] then return false, "Unavailable" end
	if not DataService.Get(p) then return false, "NoData" end
	if byPlayer[p] or p:GetAttribute("InMatch") then return false, "AlreadyInMatch" end
	if not ignoreQueue and queue[p] then return false, "InQueue" end
	if p:GetAttribute("Carrying") or p:GetAttribute("RaidTarget") then return false, "InRaid" end
	if not Combat.EntityOf(p) then return false, "Dead" end
	return true
end

local function checkWagerPokemon(player, uid)
	local data = DataService.Get(player)
	if type(uid) ~= "string" or not data or not data.Owned[uid] then return false, "NotOwned" end
	if Locks.IsLocked(uid) then return false, "Locked" end
	if countOwned(data) >= Economy.MaxOwned then return false, "CollectionFull" end -- you could win one more
	return true
end

local function expected(ra, rb)
	return 1 / (1 + 10 ^ ((rb - ra) / 400))
end

-- ---------- settlement ----------
local function settleRanked(m, res)
	if res.Cancelled then
		Notify.Send(m.A, "Match cancelled. No rank change.", "info")
		Notify.Send(m.B, "Match cancelled. No rank change.", "info")
		return
	end
	local da, db = DataService.Get(m.A), DataService.Get(m.B)
	if not da or not db then return end
	local ra, rb = da.Rank.Elo, db.Rank.Elo
	local sa = res.Draw and 0.5 or (res.Winner == m.A and 1 or 0)
	local ea = expected(ra, rb)
	local K = PvpCfg.RankedK
	da.Rank.Elo = math.max(PvpCfg.MinElo, math.floor(ra + K * (sa - ea) + 0.5))
	db.Rank.Elo = math.max(PvpCfg.MinElo, math.floor(rb + K * ((1 - sa) - (1 - ea)) + 0.5))

	local function record(p, d, score)
		if score == 1 then
			d.Rank.Wins += 1
			d.Coins += PvpCfg.WinCoins
		elseif score == 0 then
			d.Rank.Losses += 1
			d.Coins += PvpCfg.LossCoins
		else
			d.Rank.Draws = (d.Rank.Draws or 0) + 1
			d.Coins += PvpCfg.DrawCoins
		end
		SyncService.Queue(p)
	end
	record(m.A, da, sa)
	record(m.B, db, 1 - sa)

	local why = res.Reason == "disconnect" and " (opponent left)" or ""
	local function msg(p, d, old, score)
		local word = score == 1 and "WIN" or (score == 0 and "LOSS" or "DRAW")
		Notify.Send(p, ("Ranked %s%s. Elo %d -> %d"):format(word, why, old, d.Rank.Elo), score == 1 and "good" or "info")
	end
	msg(m.A, da, ra, sa)
	msg(m.B, db, rb, 1 - sa)
end

local function settleWager(m, res)
	-- Unlock first: Transfer refuses locked Pokemon.
	for _, uid in pairs(m.Wager) do Locks.Unlock(uid) end
	if not res.Winner then
		Notify.Send(m.A, "Wager match ended with no winner. Nobody loses a Pokemon.", "info")
		Notify.Send(m.B, "Wager match ended with no winner. Nobody loses a Pokemon.", "info")
		return
	end
	local winner = res.Winner
	local loser = (winner == m.A) and m.B or m.A
	local uid = m.Wager[loser]
	local ok, err = InventoryService.Transfer(loser, winner, uid)
	if ok then
		BaseService.Station(winner, uid) -- fails harmlessly if the base is full; Pokemon stays owned
		task.spawn(DataService.SaveNow, winner)
		task.spawn(DataService.SaveNow, loser)
		Notify.Send(winner, "You won the wager! The Pokemon is yours.", "good")
		Notify.Send(loser, "You lost the wager and the Pokemon.", "bad")
	else
		Notify.Send(winner, "Wager could not be completed (" .. tostring(err) .. "). Nobody lost a Pokemon.", "info")
		Notify.Send(loser, "Wager could not be completed (" .. tostring(err) .. "). You kept your Pokemon.", "info")
	end
end

local MATCH_ATTRS = { "MatchId", "InMatch", "CombatEnabled", "MatchOpponent", "MatchPhase", "MatchCountdown", "MatchEndsAt" }

local function endMatch(m, res)
	if m.Phase == "Ended" then return end -- idempotent: never settle twice
	m.Phase = "Ended"

	for _, p in ipairs({ m.A, m.B }) do
		byPlayer[p] = nil
		for _, name in ipairs(MATCH_ATTRS) do p:SetAttribute(name, nil) end
	end

	if m.Mode == "Ranked" then settleRanked(m, res) else settleWager(m, res) end

	for _, p in ipairs({ m.A, m.B }) do
		local ent = Combat.EntityOf(p)
		if ent and p.Parent and not leaving[p] then
			Combat.ResetFor(ent.Model)
			ent.Hum.Health = ent.Hum.MaxHealth
			ent.Model:PivotTo(m.Saved[p])
		end
	end
	m.Arena.InUse = false
	matches[m.Id] = nil
end

-- ---------- running a match ----------
local function run(m)
	for i = PvpCfg.Countdown, 1, -1 do
		if m.Phase == "Ended" then return end
		for _, p in ipairs({ m.A, m.B }) do
			p:SetAttribute("MatchPhase", "Countdown")
			p:SetAttribute("MatchCountdown", i)
		end
		task.wait(1)
	end
	if m.Phase == "Ended" then return end

	m.Phase = "Fight"
	m.EndsAt = os.clock() + PvpCfg.MatchTime
	for _, p in ipairs({ m.A, m.B }) do
		p:SetAttribute("MatchPhase", "Fight")
		p:SetAttribute("MatchCountdown", nil)
		p:SetAttribute("MatchEndsAt", workspace:GetServerTimeNow() + PvpCfg.MatchTime)
		p:SetAttribute("CombatEnabled", true)
		local ent = Combat.EntityOf(p)
		if ent then Combat.RemoveStatus(ent.Model, "MatchFreeze") end
	end

	while m.Phase == "Fight" do
		local aDead = Combat.EntityOf(m.A) == nil
		local bDead = Combat.EntityOf(m.B) == nil
		if aDead and bDead then
			return endMatch(m, { Draw = true, Reason = "double-ko" })
		elseif aDead then
			return endMatch(m, { Winner = m.B, Reason = "ko" })
		elseif bDead then
			return endMatch(m, { Winner = m.A, Reason = "ko" })
		end
		if os.clock() >= m.EndsAt then
			return endMatch(m, { Draw = true, Reason = "timeout" })
		end
		task.wait(0.25)
	end
end

local function startMatch(mode, a, b, wager)
	local ea, eb = Combat.EntityOf(a), Combat.EntityOf(b)
	if not ea or not eb then return nil, "NotAlive" end
	local arena = acquireArena()
	if not arena then return nil, "NoArena" end

	for _, p in ipairs({ a, b }) do
		queue[p] = nil
		cancelInvitesOf(p, "The other player started another match.")
	end

	local id = HttpService:GenerateGUID(false)
	local m = {
		Id = id, Mode = mode, A = a, B = b, Wager = wager, Arena = arena, Phase = "Countdown",
		Saved = { [a] = ea.Root.CFrame, [b] = eb.Root.CFrame },
	}
	matches[id] = m
	byPlayer[a] = m
	byPlayer[b] = m

	local posA = arena.SpawnA.Position + Vector3.new(0, 4, 0)
	local posB = arena.SpawnB.Position + Vector3.new(0, 4, 0)
	for i, p in ipairs({ a, b }) do
		local ent = i == 1 and ea or eb
		p:SetAttribute("MatchId", id)
		p:SetAttribute("InMatch", true)
		p:SetAttribute("MatchOpponent", (i == 1 and b or a).DisplayName)
		Combat.State(ent.Model)
		Combat.ResetFor(ent.Model)
		ent.Hum.Health = ent.Hum.MaxHealth
		PassiveService.ResetForMatch(p)
		Combat.AddStatus(ent.Model, "MatchFreeze", nil, { Rooted = true, Invulnerable = true })
		local from, to = i == 1 and posA or posB, i == 1 and posB or posA
		ent.Model:PivotTo(CFrame.lookAt(from, Vector3.new(to.X, from.Y, to.Z)))
	end
	task.spawn(run, m)
	return m
end

-- ---------- ranked queue ----------
function Match.QueueRanked(player)
	local ok, err = eligible(player)
	if not ok then return false, err end
	queue[player] = { Joined = os.clock() }
	Notify.Send(player, "Searching for a ranked opponent...", "info")
	return true
end

function Match.LeaveQueue(player)
	queue[player] = nil
	return true
end

-- ---------- wager flow: invite -> accept (opponent picks) -> confirm (challenger) ----------
function Match.WagerInvite(a, userId, uid)
	if type(userId) ~= "number" or userId % 1 ~= 0 then return false, "BadRequest" end
	local b = Players:GetPlayerByUserId(userId)
	if not b or b == a then return false, "NoSuchPlayer" end
	local ok, err = eligible(a)
	if not ok then return false, err end
	ok, err = eligible(b)
	if not ok then return false, "OpponentUnavailable" end
	ok, err = checkWagerPokemon(a, uid)
	if not ok then return false, err end

	cancelInvitesOf(a)
	local inv = { Id = HttpService:GenerateGUID(false), A = a, B = b, UidA = uid, Stage = "Offered", ExpiresAt = os.clock() + PvpCfg.InviteTimeout }
	invites[inv.Id] = inv
	local da = DataService.Get(a)
	Notify.Send(b, ("%s challenges you to a WAGER. They risk: %s. Pick yours to accept."):format(a.DisplayName, describe(da, uid)), "info")
	return true, inv.Id
end

function Match.WagerAccept(b, inviteId, uid)
	local inv = invites[inviteId]
	if not inv or inv.B ~= b or inv.Stage ~= "Offered" or os.clock() > inv.ExpiresAt then return false, "NoSuchInvite" end
	local a = inv.A
	local ok, err = eligible(a)
	if not ok then invites[inviteId] = nil return false, "OpponentUnavailable" end
	ok, err = eligible(b)
	if not ok then return false, err end
	ok, err = checkWagerPokemon(b, uid)
	if not ok then return false, err end
	ok, err = checkWagerPokemon(a, inv.UidA)
	if not ok then invites[inviteId] = nil return false, "OpponentPokemonUnavailable" end

	local da, db = DataService.get and nil or DataService.Get(a), DataService.Get(b)
	local ia, ib = da.Owned[inv.UidA], db.Owned[uid]
	local defA, defB = PokemonData.Get(ia.Id), PokemonData.Get(ib.Id)
	if math.abs(rarityIndex(defA.Rarity) - rarityIndex(defB.Rarity)) > PvpCfg.MaxRarityGap then
		return false, "RarityGapTooBig"
	end

	inv.UidB = uid
	inv.Stage = "Picked"
	inv.ExpiresAt = os.clock() + PvpCfg.InviteTimeout
	Notify.Send(a, ("%s offers: %s. Your wager: %s. Confirm to start!"):format(b.DisplayName, describe(db, uid), describe(da, inv.UidA)), "info")
	Notify.Send(b, "Waiting for " .. a.DisplayName .. " to confirm the wager...", "info")
	return true, inv.Id
end

function Match.WagerConfirm(a, inviteId)
	local inv = invites[inviteId]
	if not inv or inv.A ~= a or inv.Stage ~= "Picked" or os.clock() > inv.ExpiresAt then return false, "NoSuchInvite" end
	local b = inv.B
	invites[inviteId] = nil

	local ok = eligible(a) and eligible(b)
	local pa = ok and checkWagerPokemon(a, inv.UidA)
	local pb = ok and checkWagerPokemon(b, inv.UidB)
	if not (ok and pa and pb) then
		Notify.Send(a, "Wager cancelled: something changed.", "bad")
		Notify.Send(b, "Wager cancelled: something changed.", "bad")
		return false, "Changed"
	end

	-- Lock BOTH wagers atomically (no yields between check and lock), then start.
	Locks.Lock(inv.UidA, "wager")
	Locks.Lock(inv.UidB, "wager")
	local m, err = startMatch("Wager", a, b, { [a] = inv.UidA, [b] = inv.UidB })
	if not m then
		Locks.Unlock(inv.UidA)
		Locks.Unlock(inv.UidB)
		Notify.Send(a, "Could not start the match (" .. tostring(err) .. "). Nobody lost anything.", "bad")
		Notify.Send(b, "Could not start the match (" .. tostring(err) .. "). Nobody lost anything.", "bad")
		return false, err
	end
	return true
end

function Match.WagerDecline(player, inviteId)
	local inv = invites[inviteId]
	if inv and (inv.A == player or inv.B == player) then
		invites[inviteId] = nil
		local other = inv.A == player and inv.B or inv.A
		Notify.Send(other, player.DisplayName .. " declined the wager.", "info")
	end
	return true
end

-- MUST be called synchronously on PlayerRemoving, BEFORE DataService.Release (so rank changes still get saved).
function Match.OnLeaving(player)
	leaving[player] = true
	queue[player] = nil
	cancelInvitesOf(player, player.DisplayName .. " left. Wager cancelled.")
	local m = byPlayer[player]
	if m and m.Phase ~= "Ended" then
		local other = (m.A == player) and m.B or m.A
		if m.Mode == "Ranked" and m.Phase == "Fight" then
			endMatch(m, { Winner = other, Reason = "disconnect" }) -- leaving a ranked fight = loss
		else
			endMatch(m, { Cancelled = true, Reason = "disconnect" }) -- wager or pre-fight: nobody loses anything
		end
	end
	task.delay(10, function() leaving[player] = nil end)
end

function Match.Start()
	initArenas()
	task.spawn(function()
		while true do
			task.wait(1)
			local now = os.clock()
			for id, inv in pairs(invites) do
				if now > inv.ExpiresAt then
					invites[id] = nil
					Notify.Send(inv.A, "Wager invite expired.", "info")
					Notify.Send(inv.B, "Wager invite expired.", "info")
				end
			end

			local list = {}
			for p, q in pairs(queue) do
				local d = DataService.Get(p)
				if p.Parent and d then table.insert(list, { P = p, Joined = q.Joined, Elo = d.Rank.Elo }) end
			end
			table.sort(list, function(x, y) return x.Joined < y.Joined end)
			local used = {}
			for i, x in ipairs(list) do
				if not used[x.P] then
					local rx = math.min(PvpCfg.QueueMaxRange, PvpCfg.QueueBaseRange + (now - x.Joined) * PvpCfg.QueueRangeGrowth)
					for j = i + 1, #list do
						local y = list[j]
						if not used[y.P] then
							local ry = math.min(PvpCfg.QueueMaxRange, PvpCfg.QueueBaseRange + (now - y.Joined) * PvpCfg.QueueRangeGrowth)
							if math.abs(x.Elo - y.Elo) <= math.max(rx, ry) and eligible(x.P, true) and eligible(y.P, true) then
								if startMatch("Ranked", x.P, y.P, nil) then
									used[x.P], used[y.P] = true, true
								end
								break
							end
						end
					end
				end
			end
		end
	end)
end

function Match.Init(Router)
	Router.Register("QueueRanked", { rate = 1, burst = 2 }, function(p) return Match.QueueRanked(p) end)
	Router.Register("LeaveQueue", { rate = 1, burst = 2 }, function(p) return Match.LeaveQueue(p) end)
	Router.Register("WagerInvite", { rate = 1, burst = 2 }, function(p, a)
		if not Router.IsId(a.uid) then return false, "BadRequest" end
		return Match.WagerInvite(p, a.userId, a.uid)
	end)
	Router.Register("WagerAccept", { rate = 1, burst = 2 }, function(p, a)
		if not Router.IsId(a.inviteId) or not Router.IsId(a.uid) then return false, "BadRequest" end
		return Match.WagerAccept(p, a.inviteId, a.uid)
	end)
	Router.Register("WagerConfirm", { rate = 1, burst = 2 }, function(p, a)
		if not Router.IsId(a.inviteId) then return false, "BadRequest" end
		return Match.WagerConfirm(p, a.inviteId)
	end)
	Router.Register("WagerDecline", { rate = 1, burst = 2 }, function(p, a)
		if not Router.IsId(a.inviteId) then return false, "BadRequest" end
		return Match.WagerDecline(p, a.inviteId)
	end)
end

return Match
