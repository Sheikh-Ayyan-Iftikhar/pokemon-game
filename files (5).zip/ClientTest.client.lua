-- LocalScript
-- Location: StarterPlayer > StarterPlayerScripts > ClientTest
-- Quick test: prints state and tries a few actions. Delete once you build real UI.
local Api = require(script.Parent:WaitForChild("Api"))

Api.Changed:Connect(function(state)
	local owned = 0
	for _ in pairs(state.Owned) do owned += 1 end
	print(("[State] coins=%d pending=%d owned=%d stationed=%d baseLevel=%d")
		:format(state.Coins, state.Pending, owned, #state.Stationed, state.BaseLevel))
end)

Api.Start()

task.wait(5)
print("Collect:", Api.Request("CollectIncome"))
print("Buy Pikachu:", Api.Request("Buy", { pokemonId = "PIKACHU" }))
-- Then station it / equip it (use a uid from Api.State.Owned):
-- print(Api.Request("Station", { uid = "<uid>" }))
-- print(Api.Request("Equip", { slot = "Active", uid = "<uid>" }))
