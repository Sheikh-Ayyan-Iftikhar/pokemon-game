-- LocalScript  (REPLACES the Phase 3 version)
-- Location: StarterPlayer > StarterPlayerScripts > AnimClient
-- Combat animations for EVERY character (you, other players, dummies), triggered by attributes the server bumps.
--  1) If you put animation ids in Shared/Config/Animations, those play.
--  2) Otherwise a built-in PROCEDURAL fallback moves the arms/torso (works on the default R15 avatar).
local Players = game:GetService("Players")
local CollectionService = game:GetService("CollectionService")
local TweenService = game:GetService("TweenService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Anim = require(ReplicatedStorage.Shared.Config.Animations)

local function hook(model)
	local hum = model:WaitForChild("Humanoid", 10)
	if not hum then return end
	local animator = hum:FindFirstChildOfClass("Animator") or hum:WaitForChild("Animator", 5)

	-- ----- real animations (if ids were provided) -----
	local cache = {}
	local function track(id)
		if not animator or type(id) ~= "string" or id == "" then return nil end
		if not cache[id] then
			local a = Instance.new("Animation")
			a.AnimationId = id
			cache[id] = animator:LoadAnimation(a)
		end
		return cache[id]
	end
	local function play(id)
		local t = track(id)
		if t then t:Play() end
		return t ~= nil
	end

	-- ----- procedural fallback -----
	task.wait(0.5) -- let the character finish assembling
	local RS = model:FindFirstChild("RightShoulder", true) or model:FindFirstChild("Right Shoulder", true)
	local LS = model:FindFirstChild("LeftShoulder", true) or model:FindFirstChild("Left Shoulder", true)
	local Root = model:FindFirstChild("Root", true) or model:FindFirstChild("RootJoint", true)
	local orig = {}
	for _, m in ipairs({ RS, LS, Root }) do
		if m then orig[m] = m.C0 end
	end
	local function pose(motor, delta, t)
		if motor and orig[motor] then
			TweenService:Create(motor, TweenInfo.new(t, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { C0 = orig[motor] * delta }):Play()
		end
	end
	local function rest(motor, t)
		pose(motor, CFrame.new(), t)
	end
	local function swing(motors, lean)
		for _, m in ipairs(motors) do pose(m, CFrame.Angles(math.rad(110), 0, 0), 0.08) end
		pose(Root, CFrame.Angles(math.rad(-lean), 0, 0), 0.08)
		task.delay(0.12, function()
			for _, m in ipairs(motors) do rest(m, 0.2) end
			rest(Root, 0.2)
		end)
	end

	model:GetAttributeChangedSignal("AttackTick"):Connect(function()
		local combo = model:GetAttribute("Combo") or 1
		if not play(Anim.Attack[combo]) then
			if combo == 1 then swing({ RS }, 12) elseif combo == 2 then swing({ LS }, 12) else swing({ RS, LS }, 24) end
		end
	end)
	model:GetAttributeChangedSignal("HitTick"):Connect(function()
		if not play(Anim.HitReact) then
			pose(Root, CFrame.Angles(math.rad(20), 0, 0), 0.05)
			task.delay(0.12, function() rest(Root, 0.2) end)
		end
	end)
	model:GetAttributeChangedSignal("DashTick"):Connect(function()
		if not play(Anim.Dash) then
			pose(Root, CFrame.Angles(math.rad(-30), 0, 0), 0.06)
			task.delay(0.22, function() rest(Root, 0.25) end)
		end
	end)
	model:GetAttributeChangedSignal("Blocking"):Connect(function()
		local on = model:GetAttribute("Blocking")
		local t = track(Anim.Block)
		if t then
			if on then t.Looped = true t:Play() else t:Stop() end
		elseif on then
			pose(RS, CFrame.Angles(math.rad(70), 0, math.rad(35)), 0.1)
			pose(LS, CFrame.Angles(math.rad(70), 0, math.rad(-35)), 0.1)
		else
			rest(RS, 0.15)
			rest(LS, 0.15)
		end
	end)
end

local function onPlayer(p)
	if p.Character then task.spawn(hook, p.Character) end
	p.CharacterAdded:Connect(function(c) task.spawn(hook, c) end)
end
for _, p in ipairs(Players:GetPlayers()) do onPlayer(p) end
Players.PlayerAdded:Connect(onPlayer)

for _, m in ipairs(CollectionService:GetTagged("CombatDummy")) do task.spawn(hook, m) end
CollectionService:GetInstanceAddedSignal("CombatDummy"):Connect(function(m) task.spawn(hook, m) end)
