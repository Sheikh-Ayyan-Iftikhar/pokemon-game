# Phase 2: Abilities, 50 Moves, Passives

Compiles as Luau (15 files) and the data passes a validation script (exactly 50 moves, every Active Pokemon has a kit,
every Passive Pokemon has a passive, no missing references). **Not run in Roblox Studio** - I have no Studio. Expect small bugs; report them.
Roster used: the 30 Pokemon from Pokemon_Inherited_Powers_Updated.docx. The bestiary is NOT used yet.

## Install (on top of Phase 1)
REPLACE these Phase 1 files with the Phase 2 versions: `Shared/Remotes`, `Server/Main` (Script), `Client/Api`, `Client/ClientTest`.
ADD the rest:

| File | Type | Location |
|---|---|---|
| Shared/Config/CombatConfig, Moves, Kits, Passives | ModuleScript | ReplicatedStorage > Shared > Config |
| Server/CombatService, Fx, Executors, PassiveService, AbilityService, DebugService | ModuleScript | ServerScriptService > Server |
| Client/CombatClient | LocalScript | StarterPlayer > StarterPlayerScripts |

## How to test in Studio
1. Edit `TEST_POKEMON` in ClientTest (e.g. `{"RAYQUAZA","SNORLAX"}`) and press Play. DebugEquip grants, stations and equips them.
2. Press keys **1-6** to use moves (aims at your mouse). **R** = Mew's borrowed ability.
3. To hit something: Rig Builder dummy in Workspace + add tag `CombatDummy` (Tag Editor), or test with 2 players. In Studio anyone can hit anyone.
4. DebugEquip only exists in Studio. WARNING: with Studio API access on, debug-granted Pokemon are saved to your real DataStore.

## Design
- Active slot = one Pokemon; its moves become your move list. Below the HP threshold its transformed form adds moves/mods (Rayquaza, Mewtwo, Kyogre, Garchomp, Charizard, Arceus).
- A move = a config entry (`Moves.lua`) + an executor type (`Executors.lua`: Projectile, Aoe, Dash, Self, Teleport, Rewind, Flight, Compound, Carry, Realm, Burrow, Transform). Adding a move needs no new script.
- Server decides everything: cooldown, stamina, ownership, stationed check, hits, damage. Client sends only "move N + aim".
- On a live server NOBODY can be damaged until the PvP phase sets `MatchId` on both players. This is deliberate.

## Values I invented (not in your docs, tunable)
Every cooldown, stamina cost, damage number, range and radius; stamina pool (100, +6/s); Dragonite heal size (20% max HP);
body hit padding. Combined damage reduction is NOT capped (your docs say -60% / -50%).

## Known limits / not done
- VFX are plain neon parts, no sounds, no animations. Add `Sfx = "rbxassetid://..."` per move. Real animations/VFX are Phase 7+/art work.
- Flight is client-steered (hold W, move toward camera). Needs server speed checks in the anti-exploit pass.
- No basic attacks yet (Phase 3 combat). Basic-attack modifiers (Pikachu +30%, Sylveon -20%, Charizard/Arceus immunities) are wired and waiting.
- Gardevoir: sets a `RevealCooldowns` attribute on the player; the PvP phase must push the opponent's cooldowns to that client.
- Gengar/Umbreon/Bulbasaur need `workspace:SetAttribute("MapTime", "Day" or "Night")` per map (default Day).
- Kyogre "30% WATER" (transformed) was unclear: not implemented. Ditto "other basic moves" undefined: not implemented.
- Dialga's "slow environment" only slows the enemy and their projectiles.
- Mobile aiming is not handled yet (mouse only).

## Doc ambiguities I resolved (change in Passives.lua / Moves.lua)
- Groudon: -60% damage only below 40% HP; +40% HP/stamina always.
- Deoxys: new random +30% buff every 6s, each lasting 10s (overlapping).
- Palkia "50 SECOND" read as 50% less enemy damage.
- Arceus: pick 4 of 10 moves from Dialga/Palkia/Giratina (action `SetArceusPicks`; default = first 4). No pick UI yet.
