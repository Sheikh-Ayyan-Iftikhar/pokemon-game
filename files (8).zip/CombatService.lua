-- ModuleScript
-- Location: ServerScriptService > Server > CombatService
-- Statuses (buffs/debuffs), damage pipeline, stamina, history (for rewind), who-can-fight rules.
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Remotes = require(ReplicatedStorage.Shared.Remotes)
local Cfg = require(ReplicatedStorage.Shared.Config.CombatConfig)

local Combat = {}
-- In Studio anyone can hit anyone (and CombatDummy-tagged rigs) so you can test.
-- In a live server nobody can be damaged until the PvP phase sets the "MatchId" attribute on both players.
Combat.TestMode = RunService:IsStudio()

local states = setmetatable({}, { __mode = "k" }) -- [character Model] = state

-- Multiplicative keys (default 1), additive keys (default 0, clamped 0..1). Anything else is a boolean flag.
local MULT = {
	DamageDealt = true, DamageTaken = true, DamageTakenNonDimensional = true, BasicDamageTaken = true, BasicDamageDealt = true,
	AbilityPower = true, Speed = true, Dash = true, AttackSpeed = true, ProjectileSpeed = true, MaxHealth = true, MaxStamina = true,
}
local ADD = { Dodge = true, Reflect = true }

function Combat.Mod(model, key)
	local s = states[model]
	if MULT[key] then
		local v = 1
		if s then
			for _, st in pairs(s.Statuses) do
				local m = st.Mods[key]
				if m then v *= m end
			end
		end
		return v
	elseif ADD[key] then
		local v = 0
		if s then
			for _, st in pairs(s.Statuses) do
				local m = st.Mods[key]
				if m then v += m end
			end
		end
		return math.clamp(v, 0, 1)
	else
		if s then
			for _, st in pairs(s.Statuses) do
				if st.Mods[key] then return true end
			end
		end
		return false
	end
end

local function setInvisible(model, invisible)
	for _, d in ipairs(model:GetDescendants()) do
		if (d:IsA("BasePart") and d.Name ~= "HumanoidRootPart") or d:IsA("Decal") then
			if invisible then
				if d:GetAttribute("OrigT") == nil then d:SetAttribute("OrigT", d.Transparency) end
				d.Transparency = 1
			else
				local o = d:GetAttribute("OrigT")
				if o ~= nil then
					d.Transparency = o
					d:SetAttribute("OrigT", nil)
				end
			end
		end
	end
end

-- Recomputes everything that depends on statuses (speed, max health, visibility, flags for clients).
local function refresh(model)
	local s = states[model]
	local hum = model:FindFirstChildOfClass("Humanoid")
	if not s or not hum then return end

	hum.UseJumpPower = true
	local rooted = Combat.Mod(model, "Rooted")
	hum.WalkSpeed = rooted and 0 or Cfg.BaseWalkSpeed * Combat.Mod(model, "Speed")
	hum.JumpPower = rooted and 0 or Cfg.BaseJumpPower

	local newMax = s.BaseMaxHealth * Combat.Mod(model, "MaxHealth")
	if math.abs(hum.MaxHealth - newMax) > 0.01 and hum.MaxHealth > 0 then
		local ratio = hum.Health / hum.MaxHealth
		hum.MaxHealth = newMax
		hum.Health = ratio * newMax
	end
	s.MaxStamina = Cfg.MaxStamina * Combat.Mod(model, "MaxStamina")
	s.Stamina = math.min(s.Stamina, s.MaxStamina)

	local invis = Combat.Mod(model, "Invisible")
	if invis ~= s.AppliedInvisible then
		s.AppliedInvisible = invis
		setInvisible(model, invis)
	end
	model:SetAttribute("Blinded", Combat.Mod(model, "Blind"))
	model:SetAttribute("Glitched", Combat.Mod(model, "Glitch"))
	model:SetAttribute("Flying", Combat.Mod(model, "Flying"))
	model:SetAttribute("Blocking", Combat.Mod(model, "Blocking"))
	local player = Players:GetPlayerFromCharacter(model)
	if player then
		player:SetAttribute("RevealCooldowns", Combat.Mod(model, "RevealCooldowns"))
	end
end

function Combat.State(model)
	local s = states[model]
	if not s then
		local hum = model:FindFirstChildOfClass("Humanoid")
		s = {
			Statuses = {}, Cooldowns = {}, History = {},
			Stamina = Cfg.MaxStamina, MaxStamina = Cfg.MaxStamina,
			BaseMaxHealth = hum and hum.MaxHealth or 100,
			Transformed = false, TransformInto = nil, TransformUntil = nil,
		}
		states[model] = s
		if hum then
			hum.Died:Connect(function() states[model] = nil end)
		end
	end
	return s
end

-- opts: { Shield = n, Dot = { Damage, Every }, Source = model }
-- Adding a status with the same name REFRESHES it (nothing stacks), as in the bestiary rules.
function Combat.AddStatus(model, name, duration, mods, opts)
	local s = Combat.State(model)
	local now = os.clock()
	s.Statuses[name] = {
		Name = name,
		Mods = mods or {},
		Expires = duration and (now + duration) or nil,
		Shield = opts and opts.Shield or nil,
		Dot = opts and opts.Dot or nil,
		Source = opts and opts.Source or nil,
		NextDot = now + ((opts and opts.Dot and opts.Dot.Every) or 1),
	}
	refresh(model)
end

function Combat.RemoveStatus(model, name)
	local s = states[model]
	if s and s.Statuses[name] then
		s.Statuses[name] = nil
		refresh(model)
	end
end

function Combat.HasStatus(model, name)
	local s = states[model]
	return s ~= nil and s.Statuses[name] ~= nil
end

-- ---------- who can fight whom ----------
local function matchOf(model)
	local p = Players:GetPlayerFromCharacter(model)
	return p and p:GetAttribute("MatchId") or nil
end

function Combat.CanFight(a, b)
	if a == b then return false end
	local ma, mb = matchOf(a), matchOf(b)
	if ma or mb then
		return ma ~= nil and ma == mb
	end
	-- Raid: a thief and the owner they are stealing from may fight each other (StealService sets RaidTarget).
	local pa, pb = Players:GetPlayerFromCharacter(a), Players:GetPlayerFromCharacter(b)
	if pa and pb then
		if pa:GetAttribute("RaidTarget") == pb.UserId or pb:GetAttribute("RaidTarget") == pa.UserId then
			return true
		end
	end
	return Combat.TestMode
end

-- True while this player is a thief mid-raid, or the victim of one.
function Combat.InRaid(player)
	if player:GetAttribute("RaidTarget") ~= nil then return true end
	for _, other in ipairs(Players:GetPlayers()) do
		if other:GetAttribute("RaidTarget") == player.UserId then return true end
	end
	return false
end

function Combat.CanUse(player)
	return Combat.TestMode or player:GetAttribute("CombatEnabled") == true or Combat.InRaid(player)
end

function Combat.EntityFromModel(model)
	if not model or not model.Parent then return nil end
	local hum = model:FindFirstChildOfClass("Humanoid")
	local root = model:FindFirstChild("HumanoidRootPart")
	if not hum or not root or hum.Health <= 0 then return nil end
	return { Model = model, Hum = hum, Root = root, Player = Players:GetPlayerFromCharacter(model) }
end

function Combat.EntityOf(player)
	return Combat.EntityFromModel(player.Character)
end

function Combat.AllEntities()
	local list = {}
	for _, p in ipairs(Players:GetPlayers()) do
		local e = Combat.EntityOf(p)
		if e then table.insert(list, e) end
	end
	for _, m in ipairs(CollectionService:GetTagged("CombatDummy")) do
		local e = Combat.EntityFromModel(m)
		if e then table.insert(list, e) end
	end
	return list
end

function Combat.Enemies(casterModel)
	local out = {}
	for _, e in ipairs(Combat.AllEntities()) do
		if Combat.CanFight(casterModel, e.Model) then
			table.insert(out, e)
		end
	end
	return out
end

-- ---------- damage ----------
-- tags: Basic, Ability, Melee, Dimensional, DoT, Reflected, Unavoidable
function Combat.Damage(attacker, victim, amount, tags)
	tags = tags or {}
	local hum = victim:FindFirstChildOfClass("Humanoid")
	if not hum or hum.Health <= 0 or amount <= 0 then return 0 end
	if attacker and not Combat.CanFight(attacker, victim) then return 0 end

	local function vm(key) return Combat.Mod(victim, key) end
	if vm("Invulnerable") then return 0 end
	if tags.Basic then
		local attackerTransformed = attacker and states[attacker] and states[attacker].Transformed
		if vm("BasicInvulnerable") and not attackerTransformed then return 0 end
		if vm("ImmuneBasic") then return 0 end
	end
	if tags.Melee and vm("ImmuneMelee") then return 0 end
	if not tags.DoT and not tags.Unavoidable and math.random() < vm("Dodge") then return 0 end

	local dmg = amount
	if attacker then
		dmg *= Combat.Mod(attacker, "DamageDealt")
		if tags.Basic then dmg *= Combat.Mod(attacker, "BasicDamageDealt") end
		if tags.Ability then dmg *= Combat.Mod(attacker, "AbilityPower") end
	end
	dmg *= vm("DamageTaken")
	if not tags.Dimensional then dmg *= vm("DamageTakenNonDimensional") end
	if tags.Basic then dmg *= vm("BasicDamageTaken") end

	-- Blocking: costs stamina per hit; when stamina runs out the guard breaks and you are stunned.
	local blocked = false
	if not tags.DoT and not tags.Unavoidable and vm("Blocking") then
		local cost = dmg * Cfg.BlockStaminaPerDamage
		local bs = states[victim]
		if bs and bs.Stamina >= cost then
			bs.Stamina -= cost
			dmg *= (1 - Cfg.BlockReduction)
			blocked = true
		else
			Combat.RemoveStatus(victim, "Blocking")
			Combat.Stun(victim, Cfg.GuardBreakStun)
		end
	end

	-- Shields absorb before HP.
	local vs = states[victim]
	if vs then
		for _, st in pairs(vs.Statuses) do
			if st.Shield and st.Shield > 0 and dmg > 0 then
				local absorbed = math.min(st.Shield, dmg)
				st.Shield -= absorbed
				dmg -= absorbed
			end
		end
	end
	if dmg <= 0 then return 0 end

	hum.Health = math.max(0, hum.Health - dmg)

	if attacker and not tags.Reflected and not tags.DoT then
		local r = vm("Reflect")
		if r > 0 then
			Combat.Damage(victim, attacker, dmg * r, { Reflected = true, Unavoidable = true })
		end
	end
	return dmg, blocked
end

function Combat.Stun(model, seconds)
	Combat.AddStatus(model, "Stun", seconds, { Stunned = true, Rooted = true })
end

function Combat.Heal(model, amount)
	local hum = model:FindFirstChildOfClass("Humanoid")
	if hum and hum.Health > 0 then
		hum.Health = math.min(hum.MaxHealth, hum.Health + amount)
	end
end

-- ---------- stamina / rewind ----------
function Combat.SpendStamina(model, n)
	local s = Combat.State(model)
	if s.Stamina < n then return false end
	s.Stamina -= n
	return true
end

function Combat.Rewind(ent, seconds, opts)
	local s = Combat.State(ent.Model)
	local target = os.clock() - seconds
	local best = s.History[1]
	for _, h in ipairs(s.History) do
		if h.t <= target then best = h else break end
	end
	if not best then return false end
	if opts.Health then ent.Hum.Health = math.clamp(best.hp, 1, ent.Hum.MaxHealth) end
	if opts.Stamina then s.Stamina = math.min(best.st, s.MaxStamina) end
	if opts.Position then ent.Model:PivotTo(CFrame.new(best.pos) * ent.Root.CFrame.Rotation) end
	return true
end

-- Velocity changes must be applied by the client that owns the character.
function Combat.Impulse(ent, velocity, duration)
	if ent.Player then
		Remotes.Get("Impulse"):FireClient(ent.Player, { mode = "Set", v = velocity, t = duration or 0.25 })
	else
		ent.Root.AssemblyLinearVelocity = velocity
	end
end

-- Call at the start of every match (PvP phase).
function Combat.ResetFor(model)
	local s = states[model]
	if s then
		s.Statuses = {}
		s.Cooldowns = {}
		s.Stamina = Cfg.MaxStamina
		s.Transformed = false
		s.TransformInto = nil
		refresh(model)
	end
end

function Combat.Start()
	task.spawn(function()
		local last = os.clock()
		local historyAcc = 0
		while true do
			task.wait(Cfg.StepInterval)
			local now = os.clock()
			local dt = now - last
			last = now
			historyAcc += dt
			local record = historyAcc >= Cfg.HistoryInterval
			if record then historyAcc = 0 end

			for _, ent in ipairs(Combat.AllEntities()) do
				local s = Combat.State(ent.Model)
				local changed = false
				for name, st in pairs(s.Statuses) do
					if st.Expires and now >= st.Expires then
						s.Statuses[name] = nil
						changed = true
					elseif st.Dot and now >= st.NextDot then
						st.NextDot = now + st.Dot.Every
						Combat.Damage(st.Source, ent.Model, st.Dot.Damage, { DoT = true, Ability = true })
					end
				end
				if changed then refresh(ent.Model) end

				s.Stamina = math.min(s.MaxStamina, s.Stamina + Cfg.StaminaRegen * dt)
				if record then
					table.insert(s.History, { t = now, hp = ent.Hum.Health, st = s.Stamina, pos = ent.Root.Position })
					while #s.History > 0 and now - s.History[1].t > Cfg.HistorySeconds do
						table.remove(s.History, 1)
					end
					ent.Model:SetAttribute("Stamina", math.floor(s.Stamina))
					ent.Model:SetAttribute("MaxStamina", math.floor(s.MaxStamina))
				end
			end
		end
	end)
end

return Combat
