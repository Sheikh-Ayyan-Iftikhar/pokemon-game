-- ModuleScript  (REPLACES the Phase 1 version)
-- Location: ReplicatedStorage > Shared > Remotes
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local FOLDER_NAME = "Remotes"
local Remotes = {}

function Remotes.Init()
	assert(RunService:IsServer(), "Remotes.Init is server-only")
	local folder = ReplicatedStorage:FindFirstChild(FOLDER_NAME)
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = FOLDER_NAME
		folder.Parent = ReplicatedStorage
	end
	local function ensure(className, name)
		if not folder:FindFirstChild(name) then
			local inst = Instance.new(className)
			inst.Name = name
			inst.Parent = folder
		end
	end
	ensure("RemoteFunction", "Request") -- client -> server actions
	ensure("RemoteEvent", "Sync")       -- server -> client state
	ensure("RemoteEvent", "Impulse")    -- server -> client: knockback / dash / flight (client owns its character physics)
end

function Remotes.Get(name)
	return ReplicatedStorage:WaitForChild(FOLDER_NAME):WaitForChild(name)
end

return Remotes
