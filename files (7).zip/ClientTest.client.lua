-- LocalScript  (REPLACES the Phase 1 version)
-- Location: StarterPlayer > StarterPlayerScripts > ClientTest
-- Studio testing helper. Press Play, then in the client command bar / or edit TEST_POKEMON below.
-- Change TEST_POKEMON to any id from PokemonData (e.g. "RAYQUAZA", "PIKACHU", "GROUDON") and press Play.
local TEST_POKEMON = { "PIKACHU", "SNORLAX" }

local Api = require(script.Parent:WaitForChild("Api"))
Api.Start()

task.wait(3)
for _, id in ipairs(TEST_POKEMON) do
	print("DebugEquip", id, Api.Request("DebugEquip", { pokemonId = id }))
end
print("Now press 1-6 to use moves. A passive Pokemon works automatically.")
print("To test damage: insert a Rig (Rig Builder) into Workspace and tag it 'CombatDummy' (Tag Editor), or play with 2 players.")
