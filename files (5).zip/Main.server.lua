-- Script (NOT a ModuleScript)
-- Location: ServerScriptService > Server > Main
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Remotes = require(ReplicatedStorage.Shared.Remotes)
local Economy = require(ReplicatedStorage.Shared.Config.Economy)

local Server = script.Parent
local DataService = require(Server.DataService)
local RateLimiter = require(Server.RateLimiter)
local Router = require(Server.Router)
local SyncService = require(Server.SyncService)
local InventoryService = require(Server.InventoryService)
local BaseService = require(Server.BaseService)
local LoadoutService = require(Server.LoadoutService)

Remotes.Init()

SyncService.Init(Router)
InventoryService.Init(Router)
BaseService.Init(Router)
LoadoutService.Init(Router)

Router.Start()
DataService.Start()
BaseService.Start()

local function onPlayerAdded(player)
	local data, err = DataService.Load(player)
	if not data then
		if err ~= "Left" and player.Parent then
			player:Kick("Could not load your data (" .. tostring(err) .. "). Please rejoin.")
		end
		return
	end
	if not player.Parent then
		DataService.Release(player)
		return
	end

	if not data.StarterGiven then
		data.StarterGiven = true
		for _, id in ipairs(Economy.StarterPokemonIds) do
			local uid = InventoryService.Grant(player, id)
			if uid then
				BaseService.Station(player, uid)
			end
		end
	end

	BaseService.ApplyOffline(player)
	SyncService.Push(player)
end

Players.PlayerAdded:Connect(onPlayerAdded)
for _, player in ipairs(Players:GetPlayers()) do
	task.spawn(onPlayerAdded, player)
end

Players.PlayerRemoving:Connect(function(player)
	RateLimiter.Clear(player)
	DataService.Release(player)
end)
