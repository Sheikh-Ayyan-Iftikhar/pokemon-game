-- ModuleScript
-- Location: ServerScriptService > Server > MapService
-- Builds the 6 maps with CODE (Terrain + parts), the 8 base plots (in Celestial Valley), one PvP arena per map,
-- and handles map travel, per-player "which map am I on", lava and lightning hazards.
-- Maps are placeholders-with-style: real terrain, lighting and structures, but not hand-sculpted art. You can replace any
-- map later by building your own and deleting that map's builder call.
local Players = game:GetService("Players")
local Debris = game:GetService("Debris")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local MapCfg = require(ReplicatedStorage.Shared.Config.MapConfig)
local Combat = require(script.Parent.CombatService)
local Security = require(script.Parent.Security)
local BaseWorld = require(script.Parent.BaseWorld)
local Notify = require(script.Parent.Notify)
local Fx = require(script.Parent.Fx)

local Map = {}
local Terrain = workspace.Terrain
local M = Enum.Material
local C3 = Color3.fromRGB

local spawns = {} -- [mapId] = Vector3
local mapsFolder

-- ---------- helpers ----------
local function part(parent, name, size, cf, color, material, props)
	local p = Instance.new("Part")
	p.Name = name
	p.Anchored = true
	p.Size = size
	p.CFrame = typeof(cf) == "Vector3" and CFrame.new(cf) or cf
	p.Color = color
	p.Material = material or M.SmoothPlastic
	p.TopSurface = Enum.SurfaceType.Smooth
	p.BottomSurface = Enum.SurfaceType.Smooth
	if props then
		for k, v in pairs(props) do p[k] = v end
	end
	p.Parent = parent
	return p
end

local function glow(p, color, range, brightness)
	local l = Instance.new("PointLight")
	l.Color = color
	l.Range = range or 20
	l.Brightness = brightness or 2
	l.Parent = p
end

local function emitter(parent, props)
	local e = Instance.new("ParticleEmitter")
	e.Texture = "rbxasset://textures/particles/sparkles_main.dng"
	e.LightEmission = 0.4
	e.Parent = parent
	for k, v in pairs(props) do e[k] = v end
	return e
end

local function invisible(parent, name, size, pos)
	return part(parent, name, size, pos, C3(255, 255, 255), nil, { Transparency = 1, CanCollide = false, CanQuery = false, CanTouch = false })
end

-- Height of the map surface at x,z (terrain + map parts), or fallback.
function Map.GroundAt(x, z, fallbackY)
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Include
	params.FilterDescendantsInstances = { Terrain, mapsFolder }
	local r = workspace:Raycast(Vector3.new(x, 400, z), Vector3.new(0, -800, 0), params)
	return r and r.Position.Y or fallbackY or 0
end

local function ring(rng, minR, maxR)
	local a, r = rng:NextNumber(0, math.pi * 2), rng:NextNumber(minR, maxR)
	return math.cos(a) * r, math.sin(a) * r
end

local function tree(parent, pos, rng)
	local h = rng:NextNumber(10, 18)
	part(parent, "Trunk", Vector3.new(h, 2.4, 2.4), CFrame.new(pos + Vector3.new(0, h / 2, 0)) * CFrame.Angles(0, 0, math.rad(90)), C3(110, 80, 55), M.Wood, { Shape = Enum.PartType.Cylinder })
	local leaf = rng:NextNumber(10, 15)
	part(parent, "Leaves", Vector3.one * leaf, pos + Vector3.new(0, h + leaf * 0.3, 0), C3(70 + rng:NextInteger(0, 40), 160 + rng:NextInteger(0, 40), 90), M.Grass, { Shape = Enum.PartType.Ball })
end

local function crystal(parent, pos, color, rng)
	for i = 1, 3 do
		local h = rng:NextNumber(4, 10)
		local p = part(parent, "Crystal", Vector3.new(1.6, h, 1.6), CFrame.new(pos + Vector3.new(rng:NextNumber(-2, 2), h / 2, rng:NextNumber(-2, 2)))
			* CFrame.Angles(rng:NextNumber(-0.3, 0.3), 0, rng:NextNumber(-0.3, 0.3)), color, M.Neon, { Transparency = 0.2 })
		if i == 1 then glow(p, color, 18, 1.5) end
	end
end

-- ---------- arenas (one per map) ----------
local function buildArena(arenaFolder, map, color, material)
	local center = map.Origin + MapCfg.ArenaOffset + Vector3.new(0, 30, 0)
	local model = Instance.new("Model")
	model.Name = "Arena_" .. map.Id
	part(model, "Floor", Vector3.new(4, 130, 130), CFrame.new(center) * CFrame.Angles(0, 0, math.rad(90)), color, material, { Shape = Enum.PartType.Cylinder })
	for _, w in ipairs({ { Vector3.new(130, 60, 2), Vector3.new(0, 30, 65) }, { Vector3.new(130, 60, 2), Vector3.new(0, 30, -65) },
		{ Vector3.new(2, 60, 130), Vector3.new(65, 30, 0) }, { Vector3.new(2, 60, 130), Vector3.new(-65, 30, 0) } }) do
		part(model, "Wall", w[1], center + w[2], color, nil, { Transparency = 1 })
	end
	for i = 1, 8 do
		local a = (i / 8) * math.pi * 2
		local pil = part(model, "Pillar", Vector3.new(16, 3, 3), CFrame.new(center + Vector3.new(math.cos(a) * 62, 8, math.sin(a) * 62)) * CFrame.Angles(0, 0, math.rad(90)), color, material, { Shape = Enum.PartType.Cylinder })
		glow(pil, color, 16, 1)
	end
	invisible(model, "SpawnA", Vector3.new(4, 0.4, 4), center + Vector3.new(-35, 2.2, 0))
	invisible(model, "SpawnB", Vector3.new(4, 0.4, 4), center + Vector3.new(35, 2.2, 0))
	model.Parent = arenaFolder
end

-- ---------- base plots (Celestial Valley) ----------
local function buildBases(o)
	local folder = Instance.new("Folder")
	folder.Name = "Bases"
	for i = 1, 8 do
		local model = Instance.new("Model")
		model.Name = "Base" .. i
		local c = o + Vector3.new((i - 1) * 110 - 385, 0, 300)
		part(model, "Floor", Vector3.new(100, 1, 100), c + Vector3.new(0, 0.5, 0), C3(95, 130, 95), M.Grass)
		local zone = part(model, "Zone", Vector3.new(100, 40, 100), c + Vector3.new(0, 20, 0), C3(80, 200, 120), nil,
			{ Transparency = 1, CanCollide = false, CanQuery = false })
		part(model, "Delivery", Vector3.new(12, 0.4, 12), c + Vector3.new(0, 1.2, 38), C3(60, 220, 100), M.Neon)
		invisible(model, "Spawn", Vector3.new(6, 0.4, 6), c + Vector3.new(0, 1.2, 28))
		for k = 1, 12 do
			local row, col = math.floor((k - 1) / 6), (k - 1) % 6
			part(model, "Pedestal" .. k, Vector3.new(6, 2, 6), c + Vector3.new(-30 + col * 12, 2, -20 + row * 18), C3(185, 185, 200), M.Marble)
		end
		for _, corner in ipairs({ { -48, -48 }, { 48, -48 }, { -48, 48 }, { 48, 48 } }) do
			local lamp = part(model, "Lamp", Vector3.new(10, 1.4, 1.4), CFrame.new(c + Vector3.new(corner[1], 6, corner[2])) * CFrame.Angles(0, 0, math.rad(90)), C3(120, 120, 130), M.Metal, { Shape = Enum.PartType.Cylinder })
			local bulb = part(model, "LampLight", Vector3.one * 2.2, c + Vector3.new(corner[1], 11.5, corner[2]), C3(255, 240, 190), M.Neon, { Shape = Enum.PartType.Ball })
			glow(bulb, C3(255, 235, 180), 30, 1.2)
		end
		model.Parent = folder
	end
	folder.Parent = workspace
end

-- ---------- the six builders ----------
local function celestial(o, f, rng)
	Terrain:FillBlock(CFrame.new(o + Vector3.new(0, -10, 0)), Vector3.new(1100, 20, 1100), M.Grass)
	for _ = 1, 18 do
		local x, z = ring(rng, 120, 500)
		local pos = o + Vector3.new(x, -rng:NextNumber(6, 14), z)
		if not (math.abs(pos.Z - o.Z - 300) < 100 and math.abs(pos.X - o.X) < 470) then
			Terrain:FillBall(pos, rng:NextNumber(22, 46), M.Grass)
		end
	end
	Terrain:FillCylinder(CFrame.new(o + Vector3.new(-120, -3, -60)), 6, 44, M.Sand)
	Terrain:FillCylinder(CFrame.new(o + Vector3.new(-120, -2, -60)), 6, 36, M.Water)
	for _ = 1, 9 do -- floating islands
		local x, z = ring(rng, 110, 420)
		local y, r = rng:NextNumber(80, 220), rng:NextNumber(26, 48)
		local c = o + Vector3.new(x, y, z)
		Terrain:FillCylinder(CFrame.new(c), 10, r, M.Grass)
		Terrain:FillBall(c + Vector3.new(0, -12, 0), r * 0.8, M.Rock)
		tree(f, c + Vector3.new(rng:NextNumber(-r / 2, r / 2), 5, rng:NextNumber(-r / 2, r / 2)), rng)
		crystal(f, c + Vector3.new(rng:NextNumber(-r / 2, r / 2), 5, rng:NextNumber(-r / 2, r / 2)), C3(150, 220, 255), rng)
	end
	for _ = 1, 45 do
		local x, z = ring(rng, 60, 520)
		if not (math.abs(z - 300) < 110 and math.abs(x) < 480) then
			local pos = o + Vector3.new(x, 0, z)
			tree(f, Vector3.new(pos.X, Map.GroundAt(pos.X, pos.Z, 0), pos.Z), rng)
		end
	end
	for _ = 1, 14 do
		local x, z = ring(rng, 40, 500)
		if not (math.abs(z - 300) < 110 and math.abs(x) < 480) then
			crystal(f, Vector3.new(o.X + x, Map.GroundAt(o.X + x, o.Z + z, 0), o.Z + z), C3(255, 170, 230), rng)
		end
	end
	spawns.celestial = o + Vector3.new(0, 5, 0)
end

local function volcanic(o, f, rng)
	Terrain:FillBlock(CFrame.new(o + Vector3.new(0, -10, 0)), Vector3.new(1100, 20, 1100), M.Basalt)
	for _, x in ipairs({ -330, 330 }) do -- lava rivers (kept away from the spawn)
		Terrain:FillBlock(CFrame.new(o + Vector3.new(x, -3, 0)) * CFrame.Angles(0, rng:NextNumber(-0.15, 0.15), 0), Vector3.new(34, 6, 900), M.CrackedLava)
	end
	Terrain:FillBlock(CFrame.new(o + Vector3.new(0, -3, 220)), Vector3.new(500, 6, 30), M.CrackedLava)
	local volcano = o + Vector3.new(0, 0, -320)
	for _, t in ipairs({ { 130, 40, 20, M.Basalt }, { 100, 40, 60, M.Slate }, { 70, 40, 100, M.Basalt }, { 45, 30, 135, M.Slate } }) do
		Terrain:FillCylinder(CFrame.new(volcano + Vector3.new(0, t[3], 0)), t[2], t[1], t[4])
	end
	Terrain:FillCylinder(CFrame.new(volcano + Vector3.new(0, 150, 0)), 12, 28, M.CrackedLava)
	local ash = invisible(f, "Ash", Vector3.new(60, 1, 60), volcano + Vector3.new(0, 170, 0))
	emitter(ash, { Rate = 25, Lifetime = NumberRange.new(5, 8), Speed = NumberRange.new(14, 24), Color = ColorSequence.new(C3(255, 120, 40), C3(60, 40, 40)),
		Size = NumberSequence.new(4, 9), Transparency = NumberSequence.new(0.2, 1), SpreadAngle = Vector2.new(25, 25), EmissionDirection = Enum.NormalId.Top })
	glow(ash, C3(255, 100, 40), 80, 3)
	for _ = 1, 28 do
		local x, z = ring(rng, 90, 500)
		local h = rng:NextNumber(14, 44)
		local pos = o + Vector3.new(x, 0, z)
		if math.abs(x) > 40 or math.abs(z) > 40 then
			part(f, "Spire", Vector3.new(h, rng:NextNumber(5, 9), rng:NextNumber(5, 9)), CFrame.new(pos.X, h / 2, pos.Z) * CFrame.Angles(0, rng:NextNumber(0, 6), math.rad(90)),
				C3(40, 35, 38), M.Basalt, { Shape = Enum.PartType.Cylinder })
			if rng:NextNumber() < 0.4 then
				local ember = part(f, "Ember", Vector3.new(1, h * 0.7, 1), CFrame.new(pos.X + 3, h * 0.35, pos.Z), C3(255, 110, 30), M.Neon)
				glow(ember, C3(255, 120, 40), 18, 2)
			end
		end
	end
	spawns.volcanic = o + Vector3.new(0, 5, 0)
end

local function frozen(o, f, rng)
	Terrain:FillBlock(CFrame.new(o + Vector3.new(0, -10, 0)), Vector3.new(1100, 20, 1100), M.Snow)
	for i = 1, 9 do
		local a = (i / 9) * math.pi * 2
		Terrain:FillBall(o + Vector3.new(math.cos(a) * 500, -25, math.sin(a) * 500), rng:NextNumber(80, 130), M.Glacier)
	end
	-- ice cave: a big glacier block with a tunnel carved through it
	local cave = o + Vector3.new(0, 0, 380)
	Terrain:FillBlock(CFrame.new(cave + Vector3.new(0, 36, 0)), Vector3.new(220, 72, 220), M.Glacier)
	Terrain:FillBlock(CFrame.new(cave + Vector3.new(0, 14, 0)), Vector3.new(34, 26, 240), M.Air)
	for i = 1, 8 do
		local c = crystal
		c(f, cave + Vector3.new((i % 2 == 0) and 12 or -12, 2, -100 + i * 26), C3(120, 230, 255), rng)
	end
	Terrain:FillCylinder(CFrame.new(o + Vector3.new(0, -2, -140)), 4, 70, M.Ice)
	for _ = 1, 34 do
		local x, z = ring(rng, 70, 480)
		local h = rng:NextNumber(20, 60)
		part(f, "IceSpire", Vector3.new(rng:NextNumber(5, 9), h, rng:NextNumber(5, 9)),
			CFrame.new(o.X + x, h / 2, o.Z + z) * CFrame.Angles(rng:NextNumber(-0.12, 0.12), rng:NextNumber(0, 6), rng:NextNumber(-0.12, 0.12)),
			C3(170, 220, 255), M.Ice, { Transparency = 0.25 })
	end
	for _, pos in ipairs({ Vector3.new(0, 130, 0), Vector3.new(-250, 130, 200), Vector3.new(250, 130, 200) }) do
		local snow = invisible(f, "Snow", Vector3.new(400, 1, 400), o + pos)
		emitter(snow, { Rate = 40, Lifetime = NumberRange.new(6, 9), Speed = NumberRange.new(8, 14), Color = ColorSequence.new(C3(255, 255, 255)),
			Size = NumberSequence.new(0.5), Transparency = NumberSequence.new(0.1, 0.4), SpreadAngle = Vector2.new(30, 30), EmissionDirection = Enum.NormalId.Bottom })
	end
	spawns.frozen = o + Vector3.new(0, 5, 0)
end

local function stormbound(o, f, rng)
	Terrain:FillBlock(CFrame.new(o + Vector3.new(0, -40, 0)), Vector3.new(1100, 20, 1100), M.Sand)
	Terrain:FillBlock(CFrame.new(o + Vector3.new(0, -15, 0)), Vector3.new(1100, 30, 1100), M.Water)
	Terrain:FillCylinder(CFrame.new(o + Vector3.new(0, -4, 0)), 16, 72, M.Sand)
	Terrain:FillCylinder(CFrame.new(o + Vector3.new(0, -3, 0)), 14, 54, M.Grass)
	for _ = 1, 6 do
		local x, z = ring(rng, 150, 440)
		Terrain:FillBall(o + Vector3.new(x, -24, z), rng:NextNumber(30, 52), M.Sand)
	end
	for i = 1, 7 do -- wooden platforms joined by planks
		local a = (i / 7) * math.pi * 2
		local c = o + Vector3.new(math.cos(a) * 230, 2.5, math.sin(a) * 230)
		part(f, "Platform", Vector3.new(38, 2, 38), c, C3(120, 85, 55), M.Wood)
		local from = o + Vector3.new(0, 2.5, 0)
		local dir = (c - from).Unit
		part(f, "Plank", Vector3.new(7, 1, 155), CFrame.lookAt(from + dir * 137.5, c), C3(105, 75, 50), M.Wood) -- spans r=60..215
	end
	local tower = o + Vector3.new(0, 0, -20)
	part(f, "Lighthouse", Vector3.new(60, 12, 12), CFrame.new(tower + Vector3.new(0, 34, 0)) * CFrame.Angles(0, 0, math.rad(90)), C3(240, 240, 240), M.Concrete, { Shape = Enum.PartType.Cylinder })
	local lamp = part(f, "LighthouseLamp", Vector3.new(10, 8, 10), tower + Vector3.new(0, 68, 0), C3(255, 240, 160), M.Neon)
	glow(lamp, C3(255, 240, 160), 90, 3)
	for i = 1, 9 do
		part(f, "Cloud", Vector3.new(rng:NextNumber(120, 220), rng:NextNumber(30, 50), rng:NextNumber(120, 220)),
			o + Vector3.new(rng:NextNumber(-450, 450), rng:NextNumber(180, 230), rng:NextNumber(-450, 450)), C3(70, 75, 90), M.SmoothPlastic,
			{ Shape = Enum.PartType.Ball, Transparency = 0.1, CanCollide = false, CanQuery = false, CanTouch = false })
	end
	for _, pos in ipairs({ Vector3.new(-250, 150, -250), Vector3.new(250, 150, -250), Vector3.new(-250, 150, 250), Vector3.new(250, 150, 250), Vector3.new(0, 150, 0) }) do
		local rain = invisible(f, "Rain", Vector3.new(350, 1, 350), o + pos)
		emitter(rain, { Rate = 120, Lifetime = NumberRange.new(1.2, 1.6), Speed = NumberRange.new(90, 110), Color = ColorSequence.new(C3(170, 190, 230)),
			Size = NumberSequence.new(0.25), Transparency = NumberSequence.new(0.3, 0.6), SpreadAngle = Vector2.new(5, 5), EmissionDirection = Enum.NormalId.Bottom, Acceleration = Vector3.new(15, 0, 0) })
	end
	spawns.stormbound = o + Vector3.new(30, 8, 30)
end

local function shadow(o, f, rng)
	Terrain:FillCylinder(CFrame.new(o + Vector3.new(0, -6, 0)), 12, 95, M.Basalt)
	for _ = 1, 11 do
		local x, z = ring(rng, 110, 320)
		local y, r = rng:NextNumber(30, 130), rng:NextNumber(20, 40)
		local c = o + Vector3.new(x, y, z)
		Terrain:FillBall(c, r, M.Basalt)
		for k = 1, 4 do
			part(f, "Root", Vector3.new(4, r * 0.8, 4), CFrame.new(c + Vector3.new(rng:NextNumber(-r / 2, r / 2), -r - 4, rng:NextNumber(-r / 2, r / 2))) * CFrame.Angles(math.pi, 0, 0),
				C3(30, 25, 40), M.Slate)
		end
		local orb = part(f, "Wisp", Vector3.one * 3, c + Vector3.new(0, r + 4, 0), C3(170, 90, 255), M.Neon, { Shape = Enum.PartType.Ball })
		glow(orb, C3(170, 90, 255), 40, 2)
	end
	for i = 1, 6 do -- arches with glowing runes
		local a = (i / 6) * math.pi * 2
		local c = o + Vector3.new(math.cos(a) * 55, 0, math.sin(a) * 55)
		local cf = CFrame.new(c) * CFrame.Angles(0, -a + math.pi / 2, 0)
		part(f, "ArchPillar", Vector3.new(36, 5, 5), cf * CFrame.new(-9, 18, 0) * CFrame.Angles(0, 0, math.rad(90)), C3(35, 30, 50), M.Slate, { Shape = Enum.PartType.Cylinder })
		part(f, "ArchPillar", Vector3.new(36, 5, 5), cf * CFrame.new(9, 18, 0) * CFrame.Angles(0, 0, math.rad(90)), C3(35, 30, 50), M.Slate, { Shape = Enum.PartType.Cylinder })
		part(f, "ArchTop", Vector3.new(26, 4, 6), cf * CFrame.new(0, 37, 0), C3(35, 30, 50), M.Slate)
		local rune = part(f, "Rune", Vector3.new(14, 1, 0.5), cf * CFrame.new(0, 37, -3.2), C3(190, 110, 255), M.Neon)
		glow(rune, C3(190, 110, 255), 35, 2)
	end
	for _ = 1, 26 do
		local x, z = ring(rng, 12, 88)
		local h = rng:NextNumber(8, 24)
		part(f, "Spike", Vector3.new(3, h, 3), CFrame.new(o.X + x, h / 2, o.Z + z) * CFrame.Angles(rng:NextNumber(-0.2, 0.2), 0, rng:NextNumber(-0.2, 0.2)), C3(25, 22, 32), M.Slate)
	end
	spawns.shadow = o + Vector3.new(0, 5, 0)
end

local function cosmic(o, f, rng)
	Terrain:FillCylinder(CFrame.new(o + Vector3.new(0, -6, 0)), 12, 110, M.Limestone)
	for i = 1, 14 do
		local x, z = ring(rng, 140, 360)
		local y, r = rng:NextNumber(20, 150), rng:NextNumber(14, 35)
		Terrain:FillBall(o + Vector3.new(x, y, z), r, M.Rock)
	end
	for i = 1, 24 do -- ruined colonnade
		local row, col = math.floor((i - 1) / 12), (i - 1) % 12
		local broken = rng:NextNumber() < 0.35
		local h = broken and rng:NextNumber(8, 18) or 34
		part(f, "Column", Vector3.new(h, 5, 5), CFrame.new(o + Vector3.new(-66 + col * 12, h / 2, -30 + row * 60)) * CFrame.Angles(0, 0, math.rad(90)), C3(225, 225, 235), M.Marble, { Shape = Enum.PartType.Cylinder })
	end
	local gate = o + Vector3.new(0, 48, -200)
	for i = 1, 28 do
		local a = (i / 28) * math.pi * 2
		part(f, "GateRing", Vector3.new(5, 5, 5), CFrame.new(gate + Vector3.new(math.cos(a) * 42, math.sin(a) * 42, 0)), C3(110, 200, 255), M.Neon)
	end
	part(f, "GatePlatform", Vector3.new(90, 3, 60), gate + Vector3.new(0, -50, 0), C3(210, 210, 225), M.Marble)
	for i = 1, 7 do
		local a = (i / 7) * math.pi * 2
		part(f, "Nebula", Vector3.one * rng:NextNumber(120, 260), o + Vector3.new(math.cos(a) * 520, rng:NextNumber(250, 480), math.sin(a) * 520),
			(i % 2 == 0) and C3(150, 90, 230) or C3(80, 130, 240), M.Neon, { Shape = Enum.PartType.Ball, Transparency = 0.75, CanCollide = false, CanQuery = false, CanTouch = false })
	end
	spawns.cosmic = o + Vector3.new(0, 5, 20)
end

local BUILDERS = {
	celestial = { celestial, C3(120, 180, 120), M.Grass },
	volcanic = { volcanic, C3(60, 45, 45), M.Basalt },
	frozen = { frozen, C3(180, 215, 245), M.Ice },
	stormbound = { stormbound, C3(110, 80, 55), M.Wood },
	shadow = { shadow, C3(45, 30, 70), M.Slate },
	cosmic = { cosmic, C3(215, 215, 230), M.Marble },
}

function Map.Build()
	local baseplate = workspace:FindFirstChild("Baseplate")
	if baseplate then baseplate:Destroy() end

	mapsFolder = Instance.new("Folder")
	mapsFolder.Name = "Maps"
	mapsFolder.Parent = workspace
	local arenas = Instance.new("Folder")
	arenas.Name = "Arenas"

	for _, m in ipairs(MapCfg.List) do
		local f = Instance.new("Folder")
		f.Name = m.Name
		f.Parent = mapsFolder
		local b = BUILDERS[m.Id]
		local ok, err = pcall(b[1], m.Origin, f, Random.new(m.Origin.X + 7))
		if not ok then warn("[MapService] failed building " .. m.Id .. ": " .. tostring(err)) end
		spawns[m.Id] = spawns[m.Id] or (m.Origin + Vector3.new(0, 5, 0))
		pcall(buildArena, arenas, m, b[2], b[3])
	end
	arenas.Parent = workspace
	if not workspace:FindFirstChild("Bases") then
		local ok, err = pcall(buildBases, MapCfg.ById.celestial.Origin)
		if not ok then warn("[MapService] bases failed: " .. tostring(err)) end
	end
end

-- ---------- travel ----------
local lastTravel = {}
local function canMove(player)
	if not Combat.EntityOf(player) then return false, "Dead" end
	if player:GetAttribute("InMatch") or player:GetAttribute("Carrying") or Combat.InRaid(player) then return false, "Busy" end
	if os.clock() < (lastTravel[player] or 0) + 5 then return false, "Cooldown" end
	return true
end

function Map.Travel(player, mapId)
	local m = type(mapId) == "string" and MapCfg.ById[mapId]
	if not m then return false, "BadMap" end
	local ok, err = canMove(player)
	if not ok then return false, err end
	local ent = Combat.EntityOf(player)
	lastTravel[player] = os.clock()
	Security.GraceModel(ent.Model, 3)
	local base = spawns[m.Id]
	ent.Model:PivotTo(CFrame.new(base + Vector3.new(math.random(-18, 18), 4, math.random(-18, 18))))
	Notify.Send(player, "Travelled to " .. m.Name, "info")
	return true
end

function Map.GoHome(player)
	local slot = BaseWorld.GetBase(player)
	if not slot then return false, "NoBase" end
	local ok, err = canMove(player)
	if not ok then return false, err end
	local ent = Combat.EntityOf(player)
	lastTravel[player] = os.clock()
	Security.GraceModel(ent.Model, 3)
	ent.Model:PivotTo((slot.Spawn or slot.Delivery).CFrame + Vector3.new(0, 4, 0))
	return true
end

-- ---------- loops ----------
function Map.Start()
	task.spawn(function() -- which map is each player on?
		while true do
			task.wait(1)
			for _, player in ipairs(Players:GetPlayers()) do
				local ent = Combat.EntityOf(player)
				if ent then
					local m = MapCfg.Detect(ent.Root.Position)
					if m and player:GetAttribute("MapId") ~= m.Id then
						player:SetAttribute("MapId", m.Id)
						player:SetAttribute("MapTime", m.Time)
					end
				end
			end
		end
	end)

	task.spawn(function() -- lava burns
		while true do
			task.wait(0.5)
			for _, player in ipairs(Players:GetPlayers()) do
				local ent = Combat.EntityOf(player)
				if ent and not player:GetAttribute("InMatch") and ent.Hum.FloorMaterial == Enum.Material.CrackedLava then
					Combat.Damage(nil, ent.Model, 9, { Unavoidable = true, DoT = true })
				end
			end
		end
	end)

	task.spawn(function() -- lightning in Stormbound Ocean (telegraphed, then strikes)
		local o = MapCfg.ById.stormbound.Origin
		local rng = Random.new()
		while true do
			task.wait(rng:NextNumber(6, 13))
			local pos = o + Vector3.new(rng:NextNumber(-380, 380), 0, rng:NextNumber(-380, 380))
			local y = Map.GroundAt(pos.X, pos.Z, 0)
			pos = Vector3.new(pos.X, y, pos.Z)
			Fx.Telegraph(pos, 7, 1.2, C3(255, 255, 120))
			task.wait(1.2)
			local bolt = part(workspace, "Lightning", Vector3.new(1.4, 320, 1.4), pos + Vector3.new(0, 160, 0), C3(230, 240, 255), M.Neon,
				{ CanCollide = false, CanQuery = false, CanTouch = false })
			glow(bolt, C3(220, 230, 255), 120, 6)
			Debris:AddItem(bolt, 0.25)
			for _, player in ipairs(Players:GetPlayers()) do
				local ent = Combat.EntityOf(player)
				if ent and (ent.Root.Position - pos).Magnitude <= 9 and not player:GetAttribute("InMatch") then
					Combat.Damage(nil, ent.Model, 25, { Unavoidable = true, DoT = true })
				end
			end
		end
	end)
end

function Map.Init(Router)
	Router.Register("Travel", { rate = 1, burst = 2 }, function(p, a) return Map.Travel(p, a.map) end)
	Router.Register("GoHome", { rate = 1, burst = 2 }, function(p) return Map.GoHome(p) end)
end

return Map
