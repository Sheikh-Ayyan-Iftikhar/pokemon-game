-- ModuleScript
-- Location: ServerScriptService > Server > DataService
-- Persistent data with session locking, retries, versioning, autosave, BindToClose.
local DataStoreService = game:GetService("DataStoreService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Economy = require(ReplicatedStorage.Shared.Config.Economy)

local STORE_NAME = "PlayerData_v1"
local SCHEMA_VERSION = 1
local LOCK_TIMEOUT = 120      -- seconds before a stale lock (crashed server) can be taken over
local AUTOSAVE_INTERVAL = 60  -- must be well below LOCK_TIMEOUT
local LOAD_LOCK_RETRIES = 5

local store = DataStoreService:GetDataStore(STORE_NAME)
local profiles = {} -- [Player] = { Player, Key, Data, Saving, Released, Temp }

local DataService = {}

local function deepCopy(t)
	if type(t) ~= "table" then
		return t
	end
	local out = {}
	for k, v in pairs(t) do
		out[k] = deepCopy(v)
	end
	return out
end

local function template()
	return {
		Version = SCHEMA_VERSION,
		Coins = Economy.StartingCoins,
		Pending = 0,                 -- uncollected passive income
		Owned = {},                  -- [uid] = { Id = "PIKACHU", Obtained = os.time() }
		Stationed = {},              -- array of uids (no holes)
		BaseLevel = 1,
		Loadout = { Active = "", Passive1 = "", Passive2 = "", Passive3 = "" }, -- uid or ""
		Rebirths = 0,
		Rank = { Elo = 1000, Wins = 0, Losses = 0 },
		Settings = {},
		StarterGiven = false,
		LastSeen = 0,
	}
end

-- Fill in missing keys (new fields added in later versions) without touching player content tables.
local SKIP = { Owned = true, Settings = true, Stationed = true }
local function reconcile(data, tmpl)
	for k, v in pairs(tmpl) do
		if data[k] == nil then
			data[k] = deepCopy(v)
		elseif type(v) == "table" and type(data[k]) == "table" and not SKIP[k] then
			reconcile(data[k], v)
		end
	end
end

local function migrate(data)
	-- Example for the future:
	-- if data.Version < 2 then ... data.Version = 2 end
	data.Version = SCHEMA_VERSION
end

local function withRetry(fn, attempts)
	local lastErr
	for i = 1, attempts do
		local ok, res = pcall(fn)
		if ok then
			return true, res
		end
		lastErr = res
		warn(("[DataService] attempt %d/%d failed: %s"):format(i, attempts, tostring(res)))
		if i < attempts then
			task.wait(math.min(2 ^ i, 8))
		end
	end
	return false, lastErr
end

function DataService.Load(player)
	local key = "Player_" .. player.UserId
	local result, reason

	for attempt = 1, LOAD_LOCK_RETRIES do
		local locked = false
		local ok, res = withRetry(function()
			return store:UpdateAsync(key, function(old)
				locked = false
				if old and old.Lock and old.Lock.JobId ~= game.JobId
					and os.time() - old.Lock.Time < LOCK_TIMEOUT then
					locked = true
					return nil -- cancel: another live server owns this player
				end
				old = old or {}
				old.Lock = { JobId = game.JobId, Time = os.time() }
				return old
			end)
		end, 3)

		if not ok then
			reason = "DataStoreError"
			break
		end
		if locked then
			reason = "SessionLocked"
			task.wait(4) -- previous server may still be saving on leave
			if not player.Parent then
				return nil, "Left"
			end
		else
			result = res
			reason = nil
			break
		end
	end

	local temp = false
	if not result then
		if RunService:IsStudio() then
			warn("[DataService] Could not load real data (" .. tostring(reason) ..
				"). Using TEMPORARY data - nothing will be saved. Enable 'Studio Access to API Services' to test saving.")
			temp = true
		else
			return nil, reason or "Unknown"
		end
	end

	local data = result and result.Data
	if data ~= nil and type(data) ~= "table" then
		warn("[DataService] Corrupt data for " .. key)
		return nil, "CorruptData"
	end
	data = data or {}
	reconcile(data, template())
	migrate(data)

	profiles[player] = { Player = player, Key = key, Data = data, Saving = false, Released = false, Temp = temp }
	return data
end

local function saveProfile(profile, release, attempts)
	while profile.Saving do
		task.wait()
	end
	if profile.Released or profile.Temp then
		return true
	end
	profile.Saving = true

	local snapshot = deepCopy(profile.Data)
	snapshot.LastSeen = os.time()
	profile.Data.LastSeen = snapshot.LastSeen

	local lostLock = false
	local ok = withRetry(function()
		return store:UpdateAsync(profile.Key, function(old)
			lostLock = false
			if old and old.Lock and old.Lock.JobId ~= game.JobId then
				lostLock = true
				return nil -- someone else took over this player: never overwrite
			end
			return {
				Lock = (not release) and { JobId = game.JobId, Time = os.time() } or nil,
				Data = snapshot,
			}
		end)
	end, attempts or 4)

	profile.Saving = false

	if ok and lostLock then
		warn("[DataService] Lost session lock for " .. profile.Key)
		profile.Released = true -- stop all further saves from this server
		if profile.Player.Parent then
			profile.Player:Kick("Your session was opened on another server.")
		end
		return false
	end
	if ok then
		if release then
			profile.Released = true
		end
		return true
	end
	warn("[DataService] SAVE FAILED for " .. profile.Key)
	return false
end

function DataService.Get(player)
	local profile = profiles[player]
	return profile and not profile.Released and profile.Data or nil
end

function DataService.SaveNow(player)
	local profile = profiles[player]
	if profile then
		return saveProfile(profile, false, 3)
	end
	return false
end

function DataService.Release(player)
	local profile = profiles[player]
	if not profile then
		return
	end
	saveProfile(profile, true, 5)
	profiles[player] = nil
end

function DataService.Start()
	task.spawn(function()
		while true do
			task.wait(AUTOSAVE_INTERVAL)
			for _, profile in pairs(profiles) do
				task.spawn(saveProfile, profile, false, 3)
			end
		end
	end)

	game:BindToClose(function()
		local pending = 0
		for _, profile in pairs(profiles) do
			pending += 1
			task.spawn(function()
				saveProfile(profile, true, 2)
				pending -= 1
			end)
		end
		while pending > 0 do
			task.wait()
		end
	end)
end

return DataService
