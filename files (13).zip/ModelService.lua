-- ModuleScript
-- Location: ServerScriptService > Server > ModelService
-- Fills ServerStorage > PokemonModels with a model for every Pokemon (yours win if they already exist).
local ServerStorage = game:GetService("ServerStorage")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local PokemonData = require(ReplicatedStorage.Shared.Config.PokemonData)
local ModelFactory = require(ReplicatedStorage.Shared.ModelFactory)

local M = {}

function M.Init()
	local folder = ServerStorage:FindFirstChild("PokemonModels")
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = "PokemonModels"
		folder.Parent = ServerStorage
	end
	for _, def in ipairs(PokemonData.List) do
		if not folder:FindFirstChild(def.Id) then
			local ok, model = pcall(ModelFactory.Build, def.Id)
			if ok and model then
				model.Parent = folder
			else
				warn("[ModelService] could not build model for " .. def.Id)
			end
		end
	end
end

return M
