-- ModuleScript
-- Location: ServerScriptService > Server > RebirthService
-- Economic rebirth. RESETS: coins, uncollected income, base level (configurable).
-- KEEPS: every Pokemon owned, the equipped combat loadout, ranked standing, settings.
-- Pokemon that no longer fit the smaller base are UNSTATIONED, never deleted.
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Economy = require(ReplicatedStorage.Shared.Config.Economy)
local RebirthCfg = require(ReplicatedStorage.Shared.Config.RebirthConfig)
local DataService = require(script.Parent.DataService)
local SyncService = require(script.Parent.SyncService)
local LoadoutService = require(script.Parent.LoadoutService)
local Locks = require(script.Parent.Locks)
local Notify = require(script.Parent.Notify)

local Rebirth = {}
local busy = {} -- [Player] = true while a rebirth is being applied

-- Returns nil if rebirth is allowed right now, else a reason code.
local function blocker(player, data)
	if data.Rebirths >= RebirthCfg.MaxRebirths then return "MaxRebirths" end
	if player:GetAttribute("InMatch") then return "InMatch" end
	if player:GetAttribute("Carrying") or player:GetAttribute("RaidTarget") then return "InRaid" end
	for _, uid in ipairs(data.Stationed) do
		if Locks.IsLocked(uid) then return "PokemonLocked" end
	end
	-- also refuse while anyone is raiding THIS player (their Pokemon may be mid-steal)
	for _, other in ipairs(Players:GetPlayers()) do
		if other:GetAttribute("RaidTarget") == player.UserId then return "InRaid" end
	end
	return nil
end

function Rebirth.Info(player)
	local data = DataService.Get(player)
	if not data then return false, "NoData" end
	local n = data.Rebirths
	local cost = RebirthCfg.Cost(n)
	return true, {
		Rebirths = n,
		MaxRebirths = RebirthCfg.MaxRebirths,
		Cost = cost,
		CanAfford = data.Coins >= cost,
		Blocker = blocker(player, data),
		IncomeMultiplierNow = Economy.RebirthMultiplier(n),
		IncomeMultiplierNext = Economy.RebirthMultiplier(n + 1),
		ShopMultiplierNow = RebirthCfg.ShopMultiplier(n),
		ShopMultiplierNext = RebirthCfg.ShopMultiplier(n + 1),
		Resets = RebirthCfg.ResetBaseLevel and { "Coins", "Uncollected income", "Base level" } or { "Coins", "Uncollected income" },
		Keeps = { "All Pokemon", "Equipped abilities", "Ranked standing" },
	}
end

-- expected = the Rebirths count the client saw. A stale or double click can never rebirth twice.
function Rebirth.Do(player, expected)
	local data = DataService.Get(player)
	if not data then return false, "NoData" end
	if busy[player] then return false, "Busy" end
	if type(expected) ~= "number" or expected ~= data.Rebirths then return false, "Stale" end
	local why = blocker(player, data)
	if why then return false, why end
	local cost = RebirthCfg.Cost(data.Rebirths)
	if data.Coins < cost then return false, "NotEnoughCoins" end

	busy[player] = true
	-- ---- everything below has no yields: all-or-nothing ----
	data.Coins = Economy.StartingCoins
	data.Pending = 0
	data.Rebirths += 1
	if RebirthCfg.ResetBaseLevel then
		data.BaseLevel = 1
		local cap = Economy.BaseCapacity[1]
		local keep = RebirthCfg.PickKept(data.Loadout, data.Stationed, cap)
		local keepSet = {}
		for _, uid in ipairs(keep) do keepSet[uid] = true end
		for _, uid in ipairs(data.Stationed) do
			if not keepSet[uid] then LoadoutService.ClearUid(data, uid) end -- only if it could not stay stationed
		end
		data.Stationed = keep
	end
	-- ---- end of atomic block ----
	busy[player] = nil

	SyncService.Queue(player)
	task.spawn(DataService.SaveNow, player) -- persist right away so a crash cannot undo (or double) a rebirth
	Notify.Send(player, ("Rebirth %d complete! Income x%.2f"):format(data.Rebirths, Economy.RebirthMultiplier(data.Rebirths)), "good")
	return true, data.Rebirths
end

function Rebirth.Init(Router)
	Router.Register("RebirthInfo", { rate = 2, burst = 4 }, function(p) return Rebirth.Info(p) end)
	Router.Register("Rebirth", { rate = 0.5, burst = 1 }, function(p, a) return Rebirth.Do(p, a.expected) end)

	if RunService:IsStudio() then
		-- STUDIO ONLY test helper so you can afford a rebirth. Not registered on live servers.
		Router.Register("DebugCoins", { rate = 5, burst = 5 }, function(p, a)
			local d = DataService.Get(p)
			if type(a.amount) ~= "number" or a.amount ~= a.amount or math.abs(a.amount) > 1e12 then return false, "BadRequest" end
			d.Coins = math.max(0, d.Coins + math.floor(a.amount))
			SyncService.Queue(p)
			return true, d.Coins
		end)
	end
end

return Rebirth
