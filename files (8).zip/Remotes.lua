-- ModuleScript  (REPLACES the Phase 2 version - adds Notify)
-- Location: ReplicatedStorage > Shared > Remotes
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local FOLDER_NAME = "Remotes"
local Remotes = {}

function Remotes.Init()
	assert(RunService:IsServer(), "Remotes.Init is server-only")
	local folder = ReplicatedStorage:FindFirstChild(FOLDER_NAME)
	if not folder then
		folder = Instance.new("Folder")
		folder.Name = FOLDER_NAME
		folder.Parent = ReplicatedStorage
	end
	local function ensure(className, name)
		if not folder:FindFirstChild(name) then
			local inst = Instance.new(className)
			inst.Name = name
			inst.Parent = folder
		end
	end
	ensure("RemoteFunction", "Request")
	ensure("RemoteEvent", "Sync")
	ensure("RemoteEvent", "Impulse")
	ensure("RemoteEvent", "Notify")
end

function Remotes.Get(name)
	return ReplicatedStorage:WaitForChild(FOLDER_NAME):WaitForChild(name)
end

return Remotes
