-- ModuleScript
-- Location: ServerScriptService > Server > BasicCombat
-- Basic 3-hit combo, block, dash. All hit detection and damage happen on the server.
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Cfg = require(ReplicatedStorage.Shared.Config.CombatConfig)
local DataService = require(script.Parent.DataService)
local Combat = require(script.Parent.CombatService)

local Basic = {}
local ps = {} -- [Player] = { Combo, LastAttack, NextAttack, NextDash }

local function pstate(player)
	if not ps[player] then ps[player] = { Combo = 0, LastAttack = 0, NextAttack = 0, NextDash = 0 } end
	return ps[player]
end

function Basic.Clear(player)
	ps[player] = nil
end

local function finite(v)
	return v.X == v.X and v.Y == v.Y and v.Z == v.Z and math.abs(v.X) < 1e6 and math.abs(v.Y) < 1e6 and math.abs(v.Z) < 1e6
end

local function flatDir(ent, payload)
	local d = payload.dir
	if typeof(d) ~= "Vector3" or not finite(d) then d = ent.Root.CFrame.LookVector end
	d = Vector3.new(d.X, 0, d.Z)
	if d.Magnitude < 0.01 then d = Vector3.new(ent.Root.CFrame.LookVector.X, 0, ent.Root.CFrame.LookVector.Z) end
	return d.Unit
end

-- Common gate: alive, allowed to fight, not stunned, data loaded.
local function gate(player)
	if not DataService.Get(player) then return nil, "NoData" end
	local ent = Combat.EntityOf(player)
	if not ent then return nil, "Dead" end
	if not Combat.CanUse(player) then return nil, "CombatDisabled" end
	if Combat.Mod(ent.Model, "Stunned") then return nil, "Stunned" end
	return ent
end

function Basic.Attack(player, payload)
	local ent, err = gate(player)
	if not ent then return false, err end
	local model = ent.Model
	if Combat.Mod(model, "Blocking") then return false, "Blocking" end
	if Combat.Mod(model, "Flying") and not Combat.Mod(model, "AttackWhileFlying") then return false, "Flying" end

	local s, now = pstate(player), os.clock()
	if now < s.NextAttack then return false, "Cooldown" end
	if now - s.LastAttack > Cfg.ComboWindow then s.Combo = 0 end
	s.Combo = s.Combo % #Cfg.ComboDamage + 1
	s.LastAttack = now
	s.NextAttack = now + Cfg.AttackInterval / Combat.Mod(model, "AttackSpeed")
	model:SetAttribute("Combo", s.Combo)
	model:SetAttribute("AttackTick", (model:GetAttribute("AttackTick") or 0) + 1)

	local dir = flatDir(ent, payload)
	local dmg = Cfg.ComboDamage[s.Combo]
	local finisher = s.Combo == #Cfg.ComboDamage
	local cosCone = math.cos(math.rad(Cfg.ConeDegrees))

	for _, e in ipairs(Combat.Enemies(model)) do
		local off = e.Root.Position - ent.Root.Position
		local flat = Vector3.new(off.X, 0, off.Z)
		if flat.Magnitude <= Cfg.MeleeRange + Cfg.HitRadiusPad and (flat.Magnitude < 0.5 or flat.Unit:Dot(dir) >= cosCone) then
			local dealt, blocked = Combat.Damage(model, e.Model, dmg, { Basic = true, Melee = true })
			if dealt and dealt > 0 and not blocked then
				e.Model:SetAttribute("HitTick", (e.Model:GetAttribute("HitTick") or 0) + 1)
				Combat.Stun(e.Model, finisher and Cfg.FinisherStun or Cfg.HitStun)
				if finisher then
					Combat.Impulse(e, dir * Cfg.KnockbackSpeed + Vector3.new(0, 12, 0), 0.2)
				end
			end
		end
	end
	return true, s.Combo
end

function Basic.SetBlock(player, on)
	local ent, err = gate(player)
	if not ent then
		if on then return false, err end
		-- releasing block must always work, even when stunned
		local e2 = Combat.EntityOf(player)
		if e2 then Combat.RemoveStatus(e2.Model, "Blocking") end
		return true
	end
	if on then
		if Combat.Mod(ent.Model, "Flying") then return false, "Flying" end
		Combat.AddStatus(ent.Model, "Blocking", nil, { Blocking = true, Speed = Cfg.BlockSpeed })
	else
		Combat.RemoveStatus(ent.Model, "Blocking")
	end
	return true
end

function Basic.Dash(player, payload)
	local ent, err = gate(player)
	if not ent then return false, err end
	local s, now = pstate(player), os.clock()
	if now < s.NextDash then return false, "Cooldown" end
	if Combat.Mod(ent.Model, "Flying") then return false, "Flying" end
	if not Combat.SpendStamina(ent.Model, Cfg.DashStamina) then return false, "NoStamina" end

	s.NextDash = now + Cfg.DashCooldown
	Combat.RemoveStatus(ent.Model, "Blocking")
	local dir = flatDir(ent, payload)
	local dist = Cfg.DashDistance * Combat.Mod(ent.Model, "Dash")
	Combat.Impulse(ent, dir * (dist / Cfg.DashTime), Cfg.DashTime)
	Combat.AddStatus(ent.Model, "DashIFrames", Cfg.DashIFrames, { Invulnerable = true })
	ent.Model:SetAttribute("DashTick", (ent.Model:GetAttribute("DashTick") or 0) + 1)
	return true
end

function Basic.Init(Router)
	Router.Register("Attack", { rate = 6, burst = 4 }, function(player, p) return Basic.Attack(player, p) end)
	Router.Register("Block", { rate = 6, burst = 6 }, function(player, p) return Basic.SetBlock(player, p.on == true) end)
	Router.Register("Dash", { rate = 3, burst = 3 }, function(player, p) return Basic.Dash(player, p) end)
end

return Basic
