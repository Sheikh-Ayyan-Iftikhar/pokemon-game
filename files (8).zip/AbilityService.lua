-- ModuleScript
-- Location: ServerScriptService > Server > AbilityService
-- Validates and runs move requests. The client only says "use move #N, aiming here".
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Cfg = require(ReplicatedStorage.Shared.Config.CombatConfig)
local Moves = require(ReplicatedStorage.Shared.Config.Moves)
local Kits = require(ReplicatedStorage.Shared.Config.Kits)
local DataService = require(script.Parent.DataService)
local SyncService = require(script.Parent.SyncService)
local LoadoutService = require(script.Parent.LoadoutService)
local Combat = require(script.Parent.CombatService)
local Executors = require(script.Parent.Executors)
local PassiveService = require(script.Parent.PassiveService)

local Ability = {}

local function finite(v)
	return v.X == v.X and v.Y == v.Y and v.Z == v.Z and math.abs(v.X) < 1e6 and math.abs(v.Y) < 1e6 and math.abs(v.Z) < 1e6
end

local function parseAim(ent, payload)
	local dir = payload.dir
	if typeof(dir) ~= "Vector3" or not finite(dir) or dir.Magnitude < 0.01 then
		dir = ent.Root.CFrame.LookVector
	end
	dir = dir.Unit
	local point = payload.point
	if typeof(point) ~= "Vector3" or not finite(point)
		or (point - ent.Root.Position).Magnitude > Cfg.MaxAimPointDistance then
		point = nil
	end
	return dir, point
end

local function isAttack(spec)
	local e = spec.Exec
	return e ~= "Self" and e ~= "Flight" and e ~= "Rewind" and e ~= "Transform" and e ~= "Teleport"
end

local function cooldownLeft(model, moveId)
	return math.max(0, (Combat.State(model).Cooldowns[moveId] or 0) - os.clock())
end

-- Index 1..N into the player's current move list (Active Pokemon, or Ditto's copied form).
function Ability.Use(player, index, payload)
	local data = DataService.Get(player)
	if not data then return false, "NoData" end
	local ent = Combat.EntityOf(player)
	if not ent then return false, "Dead" end
	if not Combat.CanUse(player) then return false, "CombatDisabled" end
	if Combat.Mod(ent.Model, "Stunned") then return false, "Stunned" end
	if Combat.Mod(ent.Model, "Blocking") then return false, "Blocking" end
	if type(index) ~= "number" or index % 1 ~= 0 then return false, "BadRequest" end

	local uid = data.Loadout.Active
	local inst = uid ~= "" and data.Owned[uid]
	if not inst or not table.find(data.Stationed, uid) then return false, "NoActiveEquipped" end

	local state = Combat.State(ent.Model)
	local kitId = state.TransformInto or inst.Id
	local moves = Kits.Resolve(kitId, data.Settings.ArceusPicks, (not state.TransformInto) and state.Transformed)
	local moveId = moves[index]
	local spec = moveId and Moves[moveId]
	if not spec then return false, "BadMove" end

	if cooldownLeft(ent.Model, moveId) > 0 then return false, "OnCooldown" end
	local cost = spec.Cost or Cfg.DefaultMoveCost
	if state.Stamina < cost then return false, "NoStamina" end
	if isAttack(spec) and Combat.Mod(ent.Model, "Flying")
		and not Combat.Mod(ent.Model, "AttackWhileFlying") and not spec.AllowWhileFlying then
		return false, "CannotAttackWhileFlying"
	end

	local dir, point = parseAim(ent, payload)
	local ctx = { Caster = ent, Spec = spec, Dir = dir, Point = point, Data = payload }
	local exec = Executors[spec.Exec]
	if not exec then return false, "BadExecutor" end
	if exec(ctx) == false then return false, "NoTarget" end

	state.Stamina -= cost
	state.Cooldowns[moveId] = os.clock() + spec.Cooldown
	player:SetAttribute("CD_" .. moveId, workspace:GetServerTimeNow() + spec.Cooldown)
	return true, moveId
end

-- Mew: gain a random active ability, twice per match.
function Ability.UseBorrowed(player, payload)
	local data = DataService.Get(player)
	if not data then return false, "NoData" end
	local ent = Combat.EntityOf(player)
	if not ent then return false, "Dead" end
	if not Combat.CanUse(player) then return false, "CombatDisabled" end

	local equipped = LoadoutService.GetEquippedDefs(data)
	local hasMew = false
	for _, slot in ipairs({ "Passive1", "Passive2", "Passive3" }) do
		if equipped[slot] and equipped[slot].Id == "MEW" then hasMew = true end
	end
	if not hasMew then return false, "NoMew" end
	if not PassiveService.ConsumeMewCharge(player) then return false, "NoCharges" end

	local pool = {}
	for id, kit in pairs(Kits.ById) do
		if kit.Moves then table.insert(pool, id) end
	end
	local pick = pool[math.random(#pool)]
	local list = Kits.ById[pick].Moves
	local moveId = list[math.random(#list)]
	local spec = Moves[moveId]

	local dir, point = parseAim(ent, payload)
	local ok = Executors[spec.Exec]({ Caster = ent, Spec = spec, Dir = dir, Point = point, Data = payload })
	if ok == false then
		PassiveService.RefundMewCharge(player)
		return false, "NoTarget"
	end
	return true, moveId
end

function Ability.SetArceusPicks(player, list)
	local data = DataService.Get(player)
	if not data then return false, "NoData" end
	if player:GetAttribute("InMatch") then return false, "InMatch" end
	local kit = Kits.ById.ARCEUS
	if type(list) ~= "table" or #list ~= kit.Picks then return false, "BadRequest" end
	local seen, clean = {}, {}
	for _, id in ipairs(list) do
		if type(id) ~= "string" or not table.find(kit.Pool, id) or seen[id] then return false, "BadPick" end
		seen[id] = true
		table.insert(clean, id)
	end
	data.Settings.ArceusPicks = clean
	SyncService.Queue(player)
	return true
end

function Ability.Init(Router)
	Router.Register("UseMove", { rate = 5, burst = 6 }, function(player, p)
		return Ability.Use(player, p.index, p)
	end)
	Router.Register("UseBorrowed", { rate = 2, burst = 2 }, function(player, p)
		return Ability.UseBorrowed(player, p)
	end)
	Router.Register("SetArceusPicks", { rate = 1, burst = 2 }, function(player, p)
		return Ability.SetArceusPicks(player, p.moves)
	end)
end

return Ability
