-- LocalScript
-- Location: StarterPlayer > StarterPlayerScripts > RebirthTest
-- Studio test keys (delete when you build the real Rebirth UI):
--   B = show rebirth info    V = REBIRTH    C = give yourself 1,000,000 coins (Studio only)
local UserInputService = game:GetService("UserInputService")
local Api = require(script.Parent:WaitForChild("Api"))
Api.Start()

UserInputService.InputBegan:Connect(function(input, processed)
	if processed then return end
	if input.KeyCode == Enum.KeyCode.B then
		local ok, info = Api.Request("RebirthInfo")
		print("RebirthInfo", ok)
		if ok then
			for k, v in pairs(info) do print("  ", k, typeof(v) == "table" and table.concat(v, ", ") or tostring(v)) end
		end
	elseif input.KeyCode == Enum.KeyCode.V then
		local current = Api.State and Api.State.Rebirths or 0
		print("Rebirth", Api.Request("Rebirth", { expected = current }))
	elseif input.KeyCode == Enum.KeyCode.C then
		print("DebugCoins", Api.Request("DebugCoins", { amount = 1000000 }))
	end
end)
