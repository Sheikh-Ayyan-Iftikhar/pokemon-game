-- ModuleScript
-- Location: ReplicatedStorage > Shared > Config > Kits
-- Which moves each ACTIVE Pokemon gives. Active slot = one Pokemon; its moves become the player's move list.
-- TransformBelow = HP ratio under which the "transformed" form unlocks (TransformMoves + TransformMods).
local Kits = {}
local K = {
	ARCEUS = {
		Pool = { "DIALGA_REWIND", "DIALGA_TIMEFIELD", "DIALGA_RESTORE", "PALKIA_WARP", "PALKIA_PORTALS", "PALKIA_DIMTHROW", "PALKIA_REALM",
			"GIRATINA_RIFTS", "GIRATINA_ANTIMATTER", "GIRATINA_BLIND" },
		Picks = 4,
		TransformBelow = 0.5, TransformMoves = { "ARCEUS_UNIVERSE", "ARCEUS_CLONES" },
		TransformMods = { BasicInvulnerable = true }, -- immune to basic attacks unless the attacker is transformed too
	},
	RAYQUAZA = { Moves = { "RAYQUAZA_METEORS", "RAYQUAZA_STORM", "RAYQUAZA_SPACE" },
		TransformBelow = 0.5, TransformMoves = { "RAYQUAZA_METEORFLIGHT", "RAYQUAZA_DEBRIS", "RAYQUAZA_SPACETHROW" } },
	MEWTWO = { Moves = { "MEWTWO_ARMOR", "MEWTWO_BLASTS", "MEWTWO_TENTACLE" },
		TransformBelow = 0.5, TransformMoves = { "MEWTWO_FLIGHT", "MEWTWO_LASER" },
		TransformAura = { Range = 80, Mods = { Glitch = true } } }, -- opponents get glitchy vision continuously
	KYOGRE = { Moves = { "KYOGRE_DEPTHS", "KYOGRE_FLOOD", "KYOGRE_CHAIN" },
		TransformBelow = 0.5, TransformMoves = { "KYOGRE_TRIDENT", "KYOGRE_SHARKTANK" } },
	DIALGA = { Moves = { "DIALGA_REWIND", "DIALGA_TIMEFIELD", "DIALGA_RESTORE" } },
	GIRATINA = { Moves = { "GIRATINA_RIFTS", "GIRATINA_ANTIMATTER", "GIRATINA_BLIND" } },
	LUGIA = { Moves = { "LUGIA_TORNADOS", "LUGIA_WINDWAVE", "LUGIA_SKYCARRY" } },
	PALKIA = { Moves = { "PALKIA_WARP", "PALKIA_PORTALS", "PALKIA_DIMTHROW", "PALKIA_REALM" } },
	GARCHOMP = { Moves = { "GARCHOMP_FLY", "GARCHOMP_SENSORWAVE", "GARCHOMP_BLADES" },
		TransformBelow = 0.4, TransformMoves = {}, TransformMods = { Reflect = 0.4, AttackWhileFlying = true } },
	CHARIZARD = { Moves = { "CHARIZARD_FLAMETHROWER", "CHARIZARD_IGNITE" },
		TransformBelow = 0.2, TransformMoves = {}, TransformMods = { ImmuneBasic = true, ImmuneMelee = true } }, -- melts basic + melee attacks
	GYARADOS = { Moves = { "GYARADOS_QUAKE", "GYARADOS_TSUNAMI", "GYARADOS_BURROW" } },
	LUCARIO = { Moves = { "LUCARIO_AURA", "LUCARIO_BARRAGE", "LUCARIO_DARKBALL" } },
	GRENINJA = { Moves = { "GRENINJA_SHURIKEN", "GRENINJA_KUNAI" } },
	MIMIKYU = { Moves = { "MIMIKYU_DODGE", "MIMIKYU_VANISH" } },
	PIKACHU = { Moves = { "PIKACHU_THUNDERBOLT", "PIKACHU_RUSH" }, Always = { Dash = 1.3, BasicDamageDealt = 1.3 } },
	SQUIRTLE = { Moves = { "SQUIRTLE_SHELL" } },
	DITTO = { Moves = { "DITTO_TRANSFORM" } },
}
Kits.ById = K

function Kits.Get(pokemonId)
	return K[pokemonId]
end

-- Returns the ordered list of move ids the player can use right now.
function Kits.Resolve(pokemonId, arceusPicks, transformed)
	local kit = K[pokemonId]
	if not kit then return {} end
	local out = {}
	if kit.Pool then
		local valid = {}
		if type(arceusPicks) == "table" and #arceusPicks == kit.Picks then
			local seen = {}
			for _, id in ipairs(arceusPicks) do
				if type(id) == "string" and table.find(kit.Pool, id) and not seen[id] then
					seen[id] = true
					table.insert(valid, id)
				end
			end
		end
		if #valid ~= kit.Picks then
			valid = {}
			for i = 1, kit.Picks do valid[i] = kit.Pool[i] end
		end
		for _, id in ipairs(valid) do table.insert(out, id) end
	else
		for _, id in ipairs(kit.Moves or {}) do table.insert(out, id) end
	end
	if transformed and kit.TransformMoves then
		for _, id in ipairs(kit.TransformMoves) do table.insert(out, id) end
	end
	return out
end

return Kits
