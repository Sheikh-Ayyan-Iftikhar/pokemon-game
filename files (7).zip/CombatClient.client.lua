-- LocalScript
-- Location: StarterPlayer > StarterPlayerScripts > CombatClient
-- Test controls: keys 1-6 = use move 1-6 (aims at your mouse), R = Mew's borrowed ability.
-- Also: small move/cooldown HUD, knockback/dash/flight handler, blind + glitch screen effects.
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Remotes = require(ReplicatedStorage.Shared.Remotes)
local Kits = require(ReplicatedStorage.Shared.Config.Kits)
local Moves = require(ReplicatedStorage.Shared.Config.Moves)
local Api = require(script.Parent:WaitForChild("Api"))

local player = Players.LocalPlayer
local mouse = player:GetMouse()
Api.Start()

-- ---------- current move list ----------
local function currentMoves()
	local s = Api.State
	if not s then return {} end
	local uid = s.Loadout.Active
	local inst = uid ~= "" and s.Owned[uid]
	if not inst then return {} end
	local char = player.Character
	local into = char and char:GetAttribute("TransformedInto")
	local transformed = char ~= nil and char:GetAttribute("Transformed") == true
	return Kits.Resolve(into or inst.Id, s.Settings.ArceusPicks, (not into) and transformed)
end

-- ---------- input ----------
local function aim()
	local char = player.Character
	local root = char and char:FindFirstChild("HumanoidRootPart")
	if not root then return nil end
	local p = mouse.Hit.Position
	local d = p - root.Position
	if d.Magnitude < 0.1 then return root.CFrame.LookVector, p end
	return d.Unit, p
end

local KEYS = {
	[Enum.KeyCode.One] = 1, [Enum.KeyCode.Two] = 2, [Enum.KeyCode.Three] = 3,
	[Enum.KeyCode.Four] = 4, [Enum.KeyCode.Five] = 5, [Enum.KeyCode.Six] = 6,
}

UserInputService.InputBegan:Connect(function(input, processed)
	if processed then return end
	local dir, point = aim()
	if not dir then return end
	if KEYS[input.KeyCode] then
		local ok, res = Api.Request("UseMove", { index = KEYS[input.KeyCode], dir = dir, point = point })
		if not ok then print("[UseMove] failed:", res) end
	elseif input.KeyCode == Enum.KeyCode.R then
		local ok, res = Api.Request("UseBorrowed", { dir = dir, point = point })
		print("[UseBorrowed]", ok, res)
	end
end)

-- ---------- HUD ----------
local gui = Instance.new("ScreenGui")
gui.Name = "CombatHud"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local list = Instance.new("Frame")
list.BackgroundTransparency = 1
list.Position = UDim2.new(0, 12, 1, -230)
list.Size = UDim2.new(0, 330, 0, 210)
list.Parent = gui
local layout = Instance.new("UIListLayout")
layout.VerticalAlignment = Enum.VerticalAlignment.Bottom
layout.Padding = UDim.new(0, 4)
layout.Parent = list

local labels = {}
local function getLabel(i)
	if not labels[i] then
		local l = Instance.new("TextLabel")
		l.Size = UDim2.new(1, 0, 0, 26)
		l.BackgroundColor3 = Color3.fromRGB(25, 25, 35)
		l.BackgroundTransparency = 0.25
		l.TextColor3 = Color3.new(1, 1, 1)
		l.Font = Enum.Font.GothamMedium
		l.TextSize = 14
		l.TextXAlignment = Enum.TextXAlignment.Left
		l.LayoutOrder = -i
		l.Parent = list
		labels[i] = l
	end
	return labels[i]
end

RunService.RenderStepped:Connect(function()
	local moves = currentMoves()
	for i = 1, math.max(#moves, #labels) do
		local l = getLabel(i)
		local id = moves[i]
		if id then
			local cdEnd = player:GetAttribute("CD_" .. id) or 0
			local left = math.max(0, cdEnd - workspace:GetServerTimeNow())
			l.Visible = true
			l.Text = ("  [%d] %s  %s"):format(i, Moves[id].Name, left > 0 and ("%.1fs"):format(left) or "READY")
			l.TextColor3 = left > 0 and Color3.fromRGB(170, 170, 170) or Color3.new(1, 1, 1)
		else
			l.Visible = false
		end
	end
end)

-- ---------- blind / glitch overlays ----------
local blind = Instance.new("Frame")
blind.Size = UDim2.fromScale(1, 1)
blind.BackgroundColor3 = Color3.new(1, 1, 1)
blind.BorderSizePixel = 0
blind.Visible = false
blind.ZIndex = 50
blind.Parent = gui

local glitch = Instance.new("Frame")
glitch.Size = UDim2.fromScale(1, 1)
glitch.BorderSizePixel = 0
glitch.BackgroundTransparency = 1
glitch.ZIndex = 49
glitch.Parent = gui

RunService.RenderStepped:Connect(function()
	local char = player.Character
	blind.Visible = char ~= nil and char:GetAttribute("Blinded") == true
	if char and char:GetAttribute("Glitched") == true then
		glitch.BackgroundColor3 = Color3.fromHSV(math.random(), 1, 1)
		glitch.BackgroundTransparency = 0.8 + math.random() * 0.15
		glitch.Position = UDim2.fromOffset(math.random(-8, 8), math.random(-8, 8))
	else
		glitch.BackgroundTransparency = 1
	end
end)

-- ---------- server-driven physics (knockback / dash / flight) ----------
Remotes.Get("Impulse").OnClientEvent:Connect(function(info)
	local char = player.Character
	local root = char and char:FindFirstChild("HumanoidRootPart")
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	if not root or not hum or type(info) ~= "table" then return end
	local t0 = os.clock()

	if info.mode == "Set" and typeof(info.v) == "Vector3" then
		local conn
		conn = RunService.Heartbeat:Connect(function()
			if os.clock() - t0 > (info.t or 0.25) or not root.Parent then
				conn:Disconnect()
				return
			end
			local cur = root.AssemblyLinearVelocity
			local v = info.v
			root.AssemblyLinearVelocity = Vector3.new(v.X, v.Y ~= 0 and v.Y or cur.Y, v.Z)
		end)
	elseif info.mode == "Fly" then
		local speed = math.clamp(tonumber(info.speed) or 70, 10, 150)
		local conn
		conn = RunService.Heartbeat:Connect(function()
			if os.clock() - t0 > (info.t or 5) or not root.Parent or hum.Health <= 0 then
				conn:Disconnect()
				return
			end
			if hum.MoveDirection.Magnitude > 0 then
				root.AssemblyLinearVelocity = workspace.CurrentCamera.CFrame.LookVector * speed
			else
				root.AssemblyLinearVelocity = Vector3.zero
			end
		end)
	end
end)
