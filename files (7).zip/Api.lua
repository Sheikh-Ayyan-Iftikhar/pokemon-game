-- ModuleScript  (REPLACES the Phase 1 version: Start() is now safe to call from several scripts)
-- Location: StarterPlayer > StarterPlayerScripts > Api
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Remotes = require(ReplicatedStorage.Shared.Remotes)

local Api = { State = nil }
local changed = Instance.new("BindableEvent")
Api.Changed = changed.Event
local started = false

function Api.Request(action, payload)
	local ok, success, result = pcall(function()
		return Remotes.Get("Request"):InvokeServer(action, payload or {})
	end)
	if not ok then return false, "NetworkError" end
	return success, result
end

function Api.Start()
	if started then return end
	started = true
	Remotes.Get("Sync").OnClientEvent:Connect(function(state)
		Api.State = state
		changed:Fire(state)
	end)
	local ok, state = Api.Request("GetState")
	if ok and state then
		Api.State = state
		changed:Fire(state)
	end
end

return Api
