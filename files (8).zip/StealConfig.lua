-- ModuleScript
-- Location: ReplicatedStorage > Shared > Config > StealConfig
-- The architecture doc defines the FLOW of stealing, not the numbers. These are tunable defaults.
return {
	HoldTime = 3,          -- seconds the thief must hold the prompt (owner gets time to react)
	CarryTime = 90,        -- thief must reach their own base within this time or the Pokemon returns
	Cooldown = 20,         -- per-thief delay between steal attempts
	Range = 14,            -- max distance from the pedestal when the steal completes
	DeliveryRadius = 12,   -- distance to own Delivery pad that counts as "returned to my base"
	CarrySpeed = 0.85,     -- walk speed multiplier while carrying
	RaidGrace = 8,         -- seconds both players can fight after a thief starts a steal attempt
	LockDuration = 120,    -- owner can lock their base (defensive system) for this long...
	LockCooldown = 300,    -- ...then must wait this long before locking again
	SpawnAtBase = true,    -- players spawn at their own base
}
