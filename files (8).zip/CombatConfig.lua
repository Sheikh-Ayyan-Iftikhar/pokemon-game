-- ModuleScript  (REPLACES the Phase 2 version - adds basic-attack / block / dash values)
-- Location: ReplicatedStorage > Shared > Config > CombatConfig
-- All values are TUNABLE DEFAULTS (your docs do not define combat numbers).
return {
	BaseWalkSpeed = 16,
	BaseJumpPower = 50,
	MaxStamina = 100,
	StaminaRegen = 6,
	DefaultMoveCost = 15,
	HistorySeconds = 8,
	HistoryInterval = 0.25,
	MaxAimPointDistance = 250,
	StepInterval = 0.1,
	PassiveTick = 0.25,
	HitRadiusPad = 2.5,

	-- Basic attack (3-hit combo)
	ComboDamage = { 8, 8, 14 },
	AttackInterval = 0.45,     -- seconds between swings (divided by the AttackSpeed modifier)
	ComboWindow = 1.0,         -- time to land the next hit and keep the combo going
	MeleeRange = 7,
	ConeDegrees = 60,          -- half-angle in front of the attacker
	HitStun = 0.25,
	FinisherStun = 0.5,
	KnockbackSpeed = 45,       -- applied on the 3rd hit

	-- Block
	BlockReduction = 0.7,      -- blocked hits deal 30%
	BlockStaminaPerDamage = 0.5,
	BlockSpeed = 0.5,          -- walk speed multiplier while blocking
	GuardBreakStun = 1.5,      -- when stamina runs out while blocking

	-- Dash
	DashDistance = 25,
	DashTime = 0.2,
	DashStamina = 10,
	DashCooldown = 2,
	DashIFrames = 0.2,
}
