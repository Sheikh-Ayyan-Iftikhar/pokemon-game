-- ModuleScript
-- Location: ServerScriptService > Server > TransferJournal
-- Closes the "server crashed between the two saves" gap for Pokemon transfers (stealing + wagers).
-- Idea: before a transfer moves in memory, write a small record to a SEPARATE DataStore saying "uid X now belongs to player B".
-- If everything saves normally the record is deleted. If the server dies half-way, the next time EITHER player loads,
-- Apply() reads the record and makes that player's profile agree (remove it from the old owner / add it to the new one).
-- The newest record per Pokemon uid is always the authority, so stale leftovers cannot duplicate or resurrect a Pokemon.
local DataStoreService = game:GetService("DataStoreService")

local store = DataStoreService:GetDataStore("TransferJournal_v1")
local J = {}

local function retry(fn, tries)
	tries = tries or 3
	for i = 1, tries do
		local ok, res = pcall(fn)
		if ok then return true, res end
		if i < tries then task.wait(i) end
	end
	return false
end

local function ukey(uid) return "U_" .. uid end
local function pkey(userId) return "P_" .. tostring(userId) end

local function indexSet(userId, uid, dir)
	return retry(function()
		return store:UpdateAsync(pkey(userId), function(old)
			old = old or {}
			old[uid] = dir -- nil removes the entry
			return old
		end)
	end)
end

-- Returns true only if the intent is fully recorded. Call BEFORE the in-memory transfer.
function J.Begin(uid, inst, fromId, toId)
	local okU = retry(function()
		return store:UpdateAsync(ukey(uid), function()
			return { Owner = toId, From = fromId, Id = inst.Id, Obtained = inst.Obtained, T = os.time() }
		end)
	end)
	if not okU then return false end
	if not indexSet(fromId, uid, "out") or not indexSet(toId, uid, "in") then
		-- best-effort rollback so a half-written record cannot trigger a transfer nobody approved
		indexSet(fromId, uid, nil)
		indexSet(toId, uid, nil)
		retry(function() return store:RemoveAsync(ukey(uid)) end)
		return false
	end
	return true
end

-- Call after BOTH profiles saved successfully. Best effort: leftovers are harmless (see header).
function J.Complete(uid, fromId, toId)
	indexSet(fromId, uid, nil)
	indexSet(toId, uid, nil)
	retry(function() return store:RemoveAsync(ukey(uid)) end)
end

-- Call when a profile loads, before it is used. Returns the list of applied uids, or nil + error if the journal is unreadable
-- (the caller must then refuse to load, because loading blind could duplicate a Pokemon).
function J.Apply(userId, data)
	local okI, index = retry(function() return store:GetAsync(pkey(userId)) end)
	if not okI then return nil, "JournalError" end
	local applied = {}
	if type(index) ~= "table" then return applied end

	for uid, dir in pairs(index) do
		local okU, u = retry(function() return store:GetAsync(ukey(uid)) end)
		if not okU then return nil, "JournalError" end
		if type(u) == "table" then
			if dir == "in" and u.Owner == userId then
				if not data.Owned[uid] then
					data.Owned[uid] = { Id = u.Id, Obtained = u.Obtained }
				end
			elseif dir == "out" and u.Owner ~= userId then
				if data.Owned[uid] then
					data.Owned[uid] = nil
					local idx = table.find(data.Stationed, uid)
					if idx then table.remove(data.Stationed, idx) end
					for slot, v in pairs(data.Loadout) do
						if v == uid then data.Loadout[slot] = "" end
					end
				end
				indexSet(u.Owner, uid, "in") -- make sure the new owner will receive it
			end
		end
		table.insert(applied, uid)
	end
	return applied
end

-- Call after the profile has been saved once with the applied changes.
function J.Clean(userId, applied)
	for _, uid in ipairs(applied) do indexSet(userId, uid, nil) end
end

return J
