-- ModuleScript
-- Location: ServerScriptService > Server > Fx
-- Placeholder visuals (neon parts). Replace with your own particles/models/sounds later.
local TweenService = game:GetService("TweenService")
local Debris = game:GetService("Debris")

local Fx = {}

local function folder()
	local f = workspace:FindFirstChild("Effects")
	if not f then
		f = Instance.new("Folder")
		f.Name = "Effects"
		f.Parent = workspace
	end
	return f
end

local function basePart(size, color, shape)
	local p = Instance.new("Part")
	p.Anchored = true
	p.CanCollide = false
	p.CanQuery = false
	p.CanTouch = false
	p.CastShadow = false
	p.Material = Enum.Material.Neon
	p.Color = color or Color3.new(1, 1, 1)
	p.Size = size
	if shape then p.Shape = shape end
	p.Parent = folder()
	return p
end

local function groundY(pos)
	local r = workspace:Raycast(pos + Vector3.new(0, 5, 0), Vector3.new(0, -150, 0))
	return r and r.Position.Y + 0.2 or pos.Y
end

function Fx.Sphere(pos, radius, color, life)
	local p = basePart(Vector3.one, color, Enum.PartType.Ball)
	p.Position = pos
	p.Transparency = 0.4
	TweenService:Create(p, TweenInfo.new(life), { Size = Vector3.one * radius * 2, Transparency = 1 }):Play()
	Debris:AddItem(p, life + 0.1)
end

function Fx.Telegraph(pos, radius, life, color)
	local p = basePart(Vector3.new(0.3, radius * 2, radius * 2), color or Color3.fromRGB(255, 60, 60), Enum.PartType.Cylinder)
	p.CFrame = CFrame.new(pos.X, groundY(pos), pos.Z) * CFrame.Angles(0, 0, math.rad(90))
	p.Transparency = 0.6
	Debris:AddItem(p, life)
end

function Fx.Projectile(pos, size, color)
	local p = basePart(size, color, Enum.PartType.Ball)
	p.Position = pos
	return p
end

function Fx.Cage(pos, size, color, life)
	local p = basePart(size, color, Enum.PartType.Block)
	p.Position = pos
	p.Transparency = 0.7
	Debris:AddItem(p, life)
end

function Fx.Platform(pos, size, color)
	local p = Instance.new("Part")
	p.Anchored = true
	p.Size = Vector3.new(size, 2, size)
	p.Position = pos
	p.Color = color or Color3.fromRGB(120, 120, 200)
	p.Material = Enum.Material.Glass
	p.Parent = folder()
	return p
end

function Fx.Clones(model, positions, life)
	for _, pos in ipairs(positions) do
		local ok, c = pcall(function() return model:Clone() end)
		if ok and c then
			for _, d in ipairs(c:GetDescendants()) do
				if d:IsA("Script") or d:IsA("LocalScript") or d:IsA("Humanoid") then
					d:Destroy()
				elseif d:IsA("BasePart") then
					d.Anchored = true
					d.CanCollide = false
					d.CanQuery = false
					d.Transparency = 0.5
				end
			end
			c.Parent = folder()
			c:PivotTo(CFrame.new(pos))
			Debris:AddItem(c, life)
		end
	end
end

function Fx.Sound(id, pos)
	if not id then return end
	local p = basePart(Vector3.one * 0.1, nil, nil)
	p.Transparency = 1
	p.Position = pos
	local s = Instance.new("Sound")
	s.SoundId = id
	s.RollOffMaxDistance = 150
	s.Parent = p
	s:Play()
	Debris:AddItem(p, 6)
end

return Fx
