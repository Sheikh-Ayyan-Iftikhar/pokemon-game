# Phase 4: Ranked PvP + Wager PvP

Compiles as Luau (4 files). **Not run in Roblox Studio** (I have no Studio). Expect small bugs. The Elo math was checked numerically.
Roster: the 30 Pokemon from the inherited-powers doc. This folder holds ONLY new/changed files; keep Phase 1-3 for the rest.

## Install
REPLACE: `Server/Main` (Script).
ADD: `Server/MatchService` (ModuleScript, ServerScriptService > Server), `Shared/Config/PvpConfig` (ModuleScript, ReplicatedStorage > Shared > Config),
`Client/PvpTest` (LocalScript, StarterPlayer > StarterPlayerScripts, test keys only).

## Test (Studio > Test > Players: 2)
- Ranked: both press **K**. After a few seconds they are paired, teleported to a placeholder arena, 5 s countdown, then fight
  (Mouse1 / F / Q / keys 1-6). Winner/loser Elo changes + coins. **L** leaves the queue.
- Wager: Player A presses **J** (risks first stationed Pokemon), Player B presses **H** (offers theirs), Player A presses **G** to confirm.
  Both Pokemon get LOCKED, match runs, winner receives the loser's Pokemon. **N** declines.
- Each player starts with one Charmander, so the wager is Charmander vs Charmander (use DebugEquip for other Pokemon).

## Rules (my defaults, since your doc leaves these open - all in PvpConfig.lua)
| Situation | What happens |
|---|---|
| Win (wager) | Winner receives the loser's wagered Pokemon (ownership transfers, both saved immediately) |
| Win/loss (ranked) | Elo (K=32) changes, coins reward; no Pokemon move in ranked |
| Draw, time-out (180 s), double KO | Nobody loses anything; ranked counts as a draw |
| Opponent disconnects, WAGER | Match cancelled, nobody loses anything |
| Opponent disconnects, RANKED fight | Leaver takes a loss, other player wins |
| Disconnect before the fight starts | Cancelled, no rank change |
| Error / no free arena / invite expired / server shutdown | Cancelled, nothing moves (Pokemon only move on an explicit win) |
| Fairness | Wagered Pokemon may differ by at most 1 rarity tier (MaxRarityGap) |
| Wager flow | Invite -> opponent picks (sees yours) -> challenger confirms (sees theirs). Both locked from confirm until settled |

NOTE vs. what I proposed earlier: I did NOT implement a "30 second to reconnect" grace. A player who leaves the server loses that session,
so they cannot resume the same match. Leaving is handled immediately with the table above.

## Safety built in
- Wagered Pokemon are locked (cannot be unstationed, stolen, or moved) until settlement; settlement runs once (idempotent).
- Both players need room for one more Pokemon (they could win one), checked at confirm and again at settlement.
- Match thread errors are caught: match is cancelled and wagers unlocked.
- `MatchService.OnLeaving` runs before the leaver's data is released, so rank changes are saved.
- Players in a match cannot be stolen from, change loadout, station/unstation, or be attacked by non-participants.

## Limits (honest)
- Matchmaking only pairs players in the SAME server. A real cross-server ranked queue needs MemoryStoreService + reserved servers
  (not built; planned for the hardening phase). With few players per server, ranked matches will be rare until then.
- Same-pair win-trading / rank boosting protection is not implemented.
- Placeholder arenas (a walled platform far above the map). Your own: Models in Workspace > Arenas with parts SpawnA and SpawnB.
- No match UI yet. State is exposed as player attributes for the UI phase: MatchPhase, MatchCountdown, MatchEndsAt, MatchOpponent,
  WagerInvite (id to accept), WagerConfirm (id to confirm).
- Same crash gap as stealing: a server crash between the two saves right after a wager payout could leave one file stale.

## Next
Phase 5: Rebirth. I need your rule: your architecture doc says what rebirth must NOT do (no combat boost) but not its cost, what resets,
or what is kept. I will propose defaults (e.g. resets coins + base level, keeps Pokemon and rank) unless you tell me otherwise.
