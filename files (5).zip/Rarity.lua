-- ModuleScript
-- Location: ReplicatedStorage > Shared > Config > Rarity
return {
	Order = { "Common", "Rare", "Epic", "Legendary", "Mythical" },
	Color = {
		Common    = Color3.fromRGB(180, 180, 180),
		Rare      = Color3.fromRGB(70, 130, 220),
		Epic      = Color3.fromRGB(160, 80, 220),
		Legendary = Color3.fromRGB(240, 170, 40),
		Mythical  = Color3.fromRGB(230, 60, 80),
	},
}
