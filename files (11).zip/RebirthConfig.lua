-- ModuleScript
-- Location: ReplicatedStorage > Shared > Config > RebirthConfig
-- Architecture doc (confirmed): rebirth = ECONOMIC reset only. Collection is kept. Rewards are ECONOMIC unlocks.
-- It must NOT directly increase combat damage or ability strength. Rank: "not specified" -> I keep it.
-- "Which individual base upgrades reset has not been finalized" -> my default: base level resets (ResetBaseLevel).
-- All numbers are MY tunable defaults.
local Economy = require(script.Parent.Economy)

local R = {}

R.MaxRebirths = 20
R.BaseCost = 50000
R.CostGrowth = 2.2
R.ResetBaseLevel = true          -- set false if base upgrades should survive rebirth

-- Economic unlocks per rebirth (none of these touch combat):
--   income multiplier:   Economy.RebirthBonusPerLevel (+25% income per rebirth, already used by BaseService)
R.ShopDiscountPerRebirth = 0.03  -- cheaper Pokemon purchases and base upgrades
R.MaxDiscount = 0.30
R.PendingBonusSeconds = 1800     -- income pool holds +30 min per rebirth
R.OfflineBonusSeconds = 1800     -- offline income window +30 min per rebirth
R.MaxPendingSecondsCap = 8 * 3600
R.MaxOfflineSecondsCap = 24 * 3600

function R.Cost(rebirths)
	return math.floor(R.BaseCost * R.CostGrowth ^ rebirths)
end

function R.ShopMultiplier(rebirths)
	return 1 - math.min(R.MaxDiscount, R.ShopDiscountPerRebirth * rebirths)
end

function R.MaxPending(rebirths)
	return math.min(R.MaxPendingSecondsCap, Economy.MaxPendingSeconds + R.PendingBonusSeconds * rebirths)
end

function R.OfflineCap(rebirths)
	return math.min(R.MaxOfflineSecondsCap, Economy.OfflineCapSeconds + R.OfflineBonusSeconds * rebirths)
end

-- Pure function (unit-tested): which stationed Pokemon stay stationed after the base shrinks.
-- Equipped Pokemon (loadout) are kept first so the combat loadout survives rebirth, then the rest in order.
function R.PickKept(loadout, stationed, capacity)
	local keep, set = {}, {}
	local function add(uid)
		if uid and uid ~= "" and not set[uid] and #keep < capacity and table.find(stationed, uid) then
			set[uid] = true
			table.insert(keep, uid)
		end
	end
	for _, slot in ipairs({ "Active", "Passive1", "Passive2", "Passive3" }) do add(loadout[slot]) end
	for _, uid in ipairs(stationed) do add(uid) end
	return keep
end

return R
