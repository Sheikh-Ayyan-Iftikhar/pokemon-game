-- ModuleScript
-- Location: ServerScriptService > Server > PassiveService
-- Applies equipped passive Pokemon effects + the Active Pokemon's "always on" and "transformed" effects.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Cfg = require(ReplicatedStorage.Shared.Config.CombatConfig)
local Kits = require(ReplicatedStorage.Shared.Config.Kits)
local Passives = require(ReplicatedStorage.Shared.Config.Passives)
local DataService = require(script.Parent.DataService)
local LoadoutService = require(script.Parent.LoadoutService)
local Combat = require(script.Parent.CombatService)

local Passive = {}
local ps = {} -- [Player] = per-match trigger state

local function playerState(player)
	if not ps[player] then ps[player] = {} end
	return ps[player]
end

function Passive.ResetForMatch(player)
	ps[player] = nil
end

function Passive.Clear(player)
	ps[player] = nil
end

function Passive.MewCharges(player)
	return playerState(player).mew or 0
end

function Passive.ConsumeMewCharge(player)
	local st = playerState(player)
	if (st.mew or 0) <= 0 then return false end
	st.mew -= 1
	return true
end

function Passive.RefundMewCharge(player)
	local st = playerState(player)
	st.mew = (st.mew or 0) + 1
end

local function condMet(rule, ratio, isNight)
	local w = rule.When
	if w == "Always" then return true end
	if w == "HpBelow" then return ratio < rule.Ratio end
	if w == "Night" then return isNight end
	if w == "Day" then return not isNight end
	return false
end

local function syncStatuses(model, desired)
	local s = Combat.State(model)
	for name in pairs(s.Statuses) do
		local prefix = name:sub(1, 2)
		if (prefix == "K_" or prefix == "P_") and desired[name] == nil then
			Combat.RemoveStatus(model, name)
		end
	end
	for name, mods in pairs(desired) do
		local st = s.Statuses[name]
		if not st or st.Mods ~= mods then
			Combat.AddStatus(model, name, nil, mods)
		end
	end
end

local function evaluate(player, ent, data)
	local model, hum = ent.Model, ent.Hum
	local ratio = hum.Health / math.max(1, hum.MaxHealth)
	local now = os.clock()
	local isNight = workspace:GetAttribute("MapTime") == "Night"
	local state = playerState(player)
	local desired = {}

	local equipped = LoadoutService.GetEquippedDefs(data)

	-- Active Pokemon: always-on mods and transformed form
	local transformed = false
	local active = equipped.Active
	if active then
		local kit = Kits.Get(active.Id)
		if kit then
			if kit.Always then desired["K_Always"] = kit.Always end
			if kit.TransformBelow and ratio < kit.TransformBelow then
				transformed = true
				desired["K_Transformed"] = kit.TransformMods or {}
				if kit.TransformAura then
					for _, e in ipairs(Combat.Enemies(model)) do
						if (e.Root.Position - ent.Root.Position).Magnitude <= kit.TransformAura.Range then
							Combat.AddStatus(e.Model, "AuraDebuff", 1.0, kit.TransformAura.Mods)
						end
					end
				end
			end
		end
	end
	Combat.State(model).Transformed = transformed
	model:SetAttribute("Transformed", transformed)

	-- Passive Pokemon
	for _, slot in ipairs({ "Passive1", "Passive2", "Passive3" }) do
		local def = equipped[slot]
		local spec = def and Passives[def.Id]
		if spec then
			for i, rule in ipairs(spec.Rules or {}) do
				if condMet(rule, ratio, isNight) then
					desired["P_" .. def.Id .. i] = rule.Mods
				end
			end
			for _, trig in ipairs(spec.Triggers or {}) do
				local t = trig.Type
				if t == "RegenOnce" then
					if ratio < trig.Ratio and not state.regenUsed then
						state.regenUsed = true
						task.spawn(function()
							local ticks = math.max(1, math.floor(trig.Seconds / 0.5))
							local per = trig.TotalPct * hum.MaxHealth / ticks
							for _ = 1, ticks do
								if hum.Health <= 0 then return end
								Combat.Heal(model, per)
								task.wait(0.5)
							end
						end)
					end
				elseif t == "CycleBuff" then
					if not state.deoxysNext or now >= state.deoxysNext then
						state.deoxysNext = now + trig.Every
						local pick = math.random(3)
						local mods = pick == 1 and { DamageDealt = trig.Boost }
							or pick == 2 and { DamageTaken = 1 / trig.Boost }
							or { Speed = trig.Boost }
						Combat.AddStatus(model, "DEOXYS_" .. pick, trig.Duration, mods)
					end
				elseif t == "RandomInvisible" then
					if trig.When ~= "Night" or isNight then
						if not state.gStart then
							state.gStart = now
							state.gAt = now + math.random() * (trig.Every - trig.Duration)
							state.gFired = false
						end
						if now >= state.gStart + trig.Every then
							state.gStart += trig.Every
							state.gAt = state.gStart + math.random() * (trig.Every - trig.Duration)
							state.gFired = false
						end
						if not state.gFired and now >= state.gAt then
							state.gFired = true
							Combat.AddStatus(model, "GengarVeil", trig.Duration, { Invisible = true })
						end
					else
						state.gStart = nil
					end
				elseif t == "MewBorrow" then
					if state.mew == nil then state.mew = trig.Charges end
				end
			end
		end
	end

	syncStatuses(model, desired)
end

function Passive.Start()
	task.spawn(function()
		while true do
			task.wait(Cfg.PassiveTick)
			for _, player in ipairs(Players:GetPlayers()) do
				local ent = Combat.EntityOf(player)
				local data = DataService.Get(player)
				if ent and data then
					local ok, err = pcall(evaluate, player, ent, data)
					if not ok then warn("[PassiveService] " .. tostring(err)) end
				end
			end
		end
	end)
end

return Passive
