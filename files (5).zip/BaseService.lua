-- ModuleScript
-- Location: ServerScriptService > Server > BaseService
-- Station / unstation, capacity, upgrades, passive income.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local PokemonData = require(ReplicatedStorage.Shared.Config.PokemonData)
local Economy = require(ReplicatedStorage.Shared.Config.Economy)
local DataService = require(script.Parent.DataService)
local SyncService = require(script.Parent.SyncService)
local LoadoutService = require(script.Parent.LoadoutService)

local Base = {}

function Base.Capacity(data)
	return Economy.BaseCapacity[data.BaseLevel] or Economy.BaseCapacity[#Economy.BaseCapacity]
end

function Base.IncomePerSecond(data)
	local total = 0
	for _, uid in ipairs(data.Stationed) do
		local inst = data.Owned[uid]
		local def = inst and PokemonData.Get(inst.Id)
		if def then
			total += Economy.RarityIncome[def.Rarity] or 0
		end
	end
	return total * Economy.RebirthMultiplier(data.Rebirths)
end

function Base.Station(player, uid)
	local data = DataService.Get(player)
	if not data then return false, "NoData" end
	if type(uid) ~= "string" then return false, "BadRequest" end
	if player:GetAttribute("InMatch") then return false, "InMatch" end
	if not data.Owned[uid] then return false, "NotOwned" end
	if table.find(data.Stationed, uid) then return false, "AlreadyStationed" end
	if #data.Stationed >= Base.Capacity(data) then return false, "BaseFull" end
	table.insert(data.Stationed, uid)
	SyncService.Queue(player)
	return true
end

function Base.Unstation(player, uid)
	local data = DataService.Get(player)
	if not data then return false, "NoData" end
	if type(uid) ~= "string" then return false, "BadRequest" end
	if player:GetAttribute("InMatch") then return false, "InMatch" end
	local idx = table.find(data.Stationed, uid)
	if not idx then return false, "NotStationed" end
	table.remove(data.Stationed, idx)
	LoadoutService.ClearUid(data, uid) -- ability is lost when the Pokemon leaves the base
	SyncService.Queue(player)
	return true
end

function Base.Upgrade(player)
	local data = DataService.Get(player)
	if not data then return false, "NoData" end
	local nextLevel = data.BaseLevel + 1
	local cost = Economy.BaseUpgradeCost[nextLevel]
	if not cost then return false, "MaxLevel" end
	if data.Coins < cost then return false, "NotEnoughCoins" end
	data.Coins -= cost
	data.BaseLevel = nextLevel
	SyncService.Queue(player)
	return true, nextLevel
end

function Base.Collect(player)
	local data = DataService.Get(player)
	if not data then return false, "NoData" end
	local whole = math.floor(data.Pending)
	if whole < 1 then return false, "NothingToCollect" end
	data.Pending -= whole
	data.Coins += whole
	SyncService.Queue(player)
	return true, whole
end

-- Called once after data loads.
function Base.ApplyOffline(player)
	local data = DataService.Get(player)
	if not data or data.LastSeen == 0 then return end
	local away = math.clamp(os.time() - data.LastSeen, 0, Economy.OfflineCapSeconds)
	local rate = Base.IncomePerSecond(data)
	local cap = rate * Economy.MaxPendingSeconds
	data.Pending = math.min(cap, data.Pending + rate * away * Economy.OfflineRate)
end

function Base.Start()
	task.spawn(function()
		local last = os.clock()
		while true do
			task.wait(1)
			local now = os.clock()
			local dt = now - last
			last = now
			for _, player in ipairs(Players:GetPlayers()) do
				local data = DataService.Get(player)
				if data then
					local rate = Base.IncomePerSecond(data)
					local cap = rate * Economy.MaxPendingSeconds
					if data.Pending < cap then
						data.Pending = math.min(cap, data.Pending + rate * dt)
					end
					player:SetAttribute("IncomePerSecond", rate) -- replicates to client automatically
				end
			end
		end
	end)
end

function Base.Init(Router)
	Router.Register("Station", { rate = 2, burst = 5 }, function(player, p)
		if not Router.IsId(p.uid) then return false, "BadRequest" end
		return Base.Station(player, p.uid)
	end)
	Router.Register("Unstation", { rate = 2, burst = 5 }, function(player, p)
		if not Router.IsId(p.uid) then return false, "BadRequest" end
		return Base.Unstation(player, p.uid)
	end)
	Router.Register("UpgradeBase", { rate = 1, burst = 2 }, function(player)
		return Base.Upgrade(player)
	end)
	Router.Register("CollectIncome", { rate = 1, burst = 2 }, function(player)
		return Base.Collect(player)
	end)
end

return Base
