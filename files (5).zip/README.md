# Phase 1: Data, Collection, Base, Income, Loadout

All 14 files compile as Luau. They have NOT been run in Roblox Studio (I have no Studio), so test them there.

## Where each file goes in Roblox Studio

| File | Type | Location |
|---|---|---|
| Shared/Remotes.lua | ModuleScript | ReplicatedStorage > Shared > Remotes |
| Shared/Config/Rarity.lua | ModuleScript | ReplicatedStorage > Shared > Config > Rarity |
| Shared/Config/Economy.lua | ModuleScript | ReplicatedStorage > Shared > Config > Economy |
| Shared/Config/PokemonData.lua | ModuleScript | ReplicatedStorage > Shared > Config > PokemonData |
| Server/Main.server.lua | **Script** | ServerScriptService > Server > Main |
| Server/DataService.lua | ModuleScript | ServerScriptService > Server > DataService |
| Server/RateLimiter.lua | ModuleScript | ServerScriptService > Server > RateLimiter |
| Server/Router.lua | ModuleScript | ServerScriptService > Server > Router |
| Server/SyncService.lua | ModuleScript | ServerScriptService > Server > SyncService |
| Server/InventoryService.lua | ModuleScript | ServerScriptService > Server > InventoryService |
| Server/BaseService.lua | ModuleScript | ServerScriptService > Server > BaseService |
| Server/LoadoutService.lua | ModuleScript | ServerScriptService > Server > LoadoutService |
| Client/Api.lua | ModuleScript | StarterPlayer > StarterPlayerScripts > Api |
| Client/ClientTest.client.lua | LocalScript | StarterPlayer > StarterPlayerScripts > ClientTest |

Create the folders `Shared`, `Config` and `Server` as Folder objects first. Names must match exactly.

## Testing
1. Game Settings > Security > turn on "Enable Studio Access to API Services" (needed to test saving).
2. Press Play. Output should show `[State] ...` lines, then the Collect and Buy results.
3. If real data cannot load in Studio, a temporary profile is used and nothing is saved. A warning says so.

## Rules implemented (from your documents)
- 1 Active slot + 3 Passive slots (architecture doc, section 5).
- Only Pokemon STATIONED in the base can be equipped. Unstationing, stealing or losing a Pokemon clears its loadout slot.
- Passive income comes from stationed Pokemon.
- Rebirth multiplier is economy-only. It never touches combat.
- Pokemon are unique instances (uid), so stealing and wagers can move one specific Pokemon.
- Everything is server-authoritative. The client only sends requests through one validated, rate-limited remote.

## Values I had to invent (not in your docs, all in Economy.lua)
Starting coins, starter Pokemon (Charmander), base capacity per level, upgrade costs, income per rarity, shop prices,
which rarities are purchasable, offline income, and the rebirth bonus. Also my own rule: the same species cannot
sit in two loadout slots.

## Unclear points in your Pokemon_Inherited_Powers doc (need your decision before Phase 2)
- Groudon: "WHEN HEALTH LESS THAN 40%" hangs at the end. Does the -60% damage only apply below 40% HP, or always?
- Deoxys: "buff for 10 seconds, in every 6 seconds" overlaps itself. What is the real timing?
- Palkia: "attacks are decreased by 50 SECOND" is probably 50%.
- Kyogre transformed: "30% WATER" is unclear.
- Mew: "random active ability of any Pokemon twice per match" needs a rule for which moves are allowed.
- Arceus: "select 4 powers before the match" from Dialga, Palkia, Giratina. Needs a pick screen.
- Day/night: Gengar, Umbreon and Bulbasaur depend on night/day maps. Each map needs a time-of-day flag.

## Not defined anywhere in your docs (architecture doc says so itself)
Wager disconnects/ties/cancellations, combat damage model and cooldowns for the Pokemon moves, which base upgrades
reset on rebirth, and rebirth costs. I will propose safe defaults when we reach those phases.
