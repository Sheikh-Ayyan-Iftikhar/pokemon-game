-- ModuleScript
-- Location: ServerScriptService > Server > SettingsService
-- Saves player settings (validated whitelist only).
local DataService = require(script.Parent.DataService)
local SyncService = require(script.Parent.SyncService)

local S = {}

local RULES = {
	LightingEffects = function(v) return type(v) == "boolean" end,
	UiScale = function(v) return v == 0.8 or v == 1 or v == 1.2 end,
}

function S.Init(Router)
	Router.Register("SetSetting", { rate = 2, burst = 4 }, function(player, p)
		local data = DataService.Get(player)
		if not data then return false, "NoData" end
		local rule = type(p.key) == "string" and RULES[p.key]
		if not rule or not rule(p.value) then return false, "BadRequest" end
		data.Settings[p.key] = p.value
		SyncService.Queue(player)
		return true
	end)
end

return S
