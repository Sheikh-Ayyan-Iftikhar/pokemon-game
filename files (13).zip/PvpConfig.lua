-- ModuleScript
-- Location: ReplicatedStorage > Shared > Config > PvpConfig
-- Your architecture doc leaves wager/ranked details open ("disconnects, ties, exploits, cancellations ... still need to be designed").
-- Everything here is MY proposed default. Change freely.
return {
	-- Ranked (Elo)
	RankedK = 32,
	MinElo = 0,
	QueueBaseRange = 100,     -- allowed Elo difference at queue start
	QueueRangeGrowth = 10,    -- allowed difference grows by this per second waiting
	QueueMaxRange = 500,
	WinCoins = 100,           -- ranked rewards (coins only; no Pokemon moves in ranked)
	LossCoins = 20,
	DrawCoins = 40,

	PairWindow = 1800,        -- win-trading guard: same two players...
	PairLimit = 3,            -- ...after this many ranked games inside the window earn nothing

	-- Match
	Countdown = 5,
	MatchTime = 180,          -- time out = DRAW (no Pokemon moves, Elo drawn)
	MaxArenas = 10,           -- placeholder arenas created on demand

	-- Wager
	InviteTimeout = 30,
	MaxRarityGap = 1,         -- wagered Pokemon may differ by at most this many rarity tiers (Common<Rare<Epic<Legendary<Mythical)
}
