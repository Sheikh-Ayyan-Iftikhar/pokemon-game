-- ModuleScript
-- Location: ServerScriptService > Server > RateLimiter
-- Token bucket per player per action.
local RateLimiter = {}
local buckets = {} -- [Player] = { [action] = { tokens, last } }

function RateLimiter.Allow(player, action, ratePerSec, burst)
	local perPlayer = buckets[player]
	if not perPlayer then
		perPlayer = {}
		buckets[player] = perPlayer
	end
	local now = os.clock()
	local b = perPlayer[action]
	if not b then
		b = { tokens = burst, last = now }
		perPlayer[action] = b
	end
	b.tokens = math.min(burst, b.tokens + (now - b.last) * ratePerSec)
	b.last = now
	if b.tokens < 1 then
		return false
	end
	b.tokens -= 1
	return true
end

function RateLimiter.Clear(player)
	buckets[player] = nil
end

return RateLimiter
