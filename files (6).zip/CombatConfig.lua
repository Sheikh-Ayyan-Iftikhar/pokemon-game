-- ModuleScript
-- Location: ReplicatedStorage > Shared > Config > CombatConfig
-- All values are TUNABLE DEFAULTS (your docs do not define them).
return {
	BaseWalkSpeed = 16,
	BaseJumpPower = 50,
	MaxStamina = 100,
	StaminaRegen = 6,        -- per second
	DefaultMoveCost = 15,    -- stamina; moves can override with Cost
	HistorySeconds = 8,      -- how far back Dialga's rewind can go
	HistoryInterval = 0.25,
	MaxAimPointDistance = 250,
	StepInterval = 0.1,      -- status expiry / DoT / stamina tick
	PassiveTick = 0.25,
	HitRadiusPad = 2.5,      -- approx body radius added to every hit test
}
