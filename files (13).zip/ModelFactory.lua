-- ModuleScript
-- Location: ReplicatedStorage > Shared > ModelFactory
-- Builds a simple 3D model for each Pokemon out of parts (no external assets needed).
-- The server stores them in ServerStorage > PokemonModels (base pedestals + wild spawns use them);
-- the client builds its own copy for the 3D previews in the Collection menu.
-- Your own models always win: put a Model named by Pokemon id in ServerStorage > PokemonModels BEFORE the game starts.
-- Front of every model is -Z. Body center is roughly the model center. PrimaryPart = "Body".
local Looks = require(script.Parent.Config.PokemonLooks)

local F = {}

local BLOCK, BALL, CYL = Enum.PartType.Block, Enum.PartType.Ball, Enum.PartType.Cylinder

local function part(model, name, shape, size, cf, color, material, neon)
	local p = Instance.new("Part")
	p.Name = name
	p.Shape = shape
	p.Size = size
	p.CFrame = cf
	p.Color = color
	p.Material = neon and Enum.Material.Neon or (material or Enum.Material.SmoothPlastic)
	p.TopSurface = Enum.SurfaceType.Smooth
	p.BottomSurface = Enum.SurfaceType.Smooth
	p.CanCollide = false
	p.Massless = true
	p.Parent = model
	return p
end

local function wedge(model, name, size, cf, color)
	local w = Instance.new("WedgePart")
	w.Name = name
	w.Size = size
	w.CFrame = cf
	w.Color = color
	w.Material = Enum.Material.SmoothPlastic
	w.TopSurface = Enum.SurfaceType.Smooth
	w.BottomSurface = Enum.SurfaceType.Smooth
	w.CanCollide = false
	w.Massless = true
	w.Parent = model
	return w
end

local function eyes(model, headCF, s, spread, z)
	for _, sx in ipairs({ -1, 1 }) do
		part(model, "Eye", BALL, Vector3.one * 0.55 * s, headCF * CFrame.new(sx * spread * s, 0.25 * s, z * s), Color3.new(0.05, 0.05, 0.08))
		part(model, "EyeShine", BALL, Vector3.one * 0.2 * s, headCF * CFrame.new(sx * spread * s, 0.4 * s, (z - 0.2) * s), Color3.new(1, 1, 1))
	end
end

-- ---------- body templates: return body part, head CFrame, tail CFrame (for extras) ----------
local T = {}

function T.blob(model, s, c1, c2)
	local body = part(model, "Body", BALL, Vector3.new(4, 3.6, 4) * s, CFrame.new(0, 0, 0), c1)
	part(model, "Belly", BALL, Vector3.new(3, 2.4, 2.2) * s, CFrame.new(0, -0.5 * s, -1.2 * s), c2)
	eyes(model, CFrame.new(0, 0.7 * s, -1.6 * s), s, 0.9, -0.2)
	part(model, "Foot", BALL, Vector3.new(1.4, 1, 1.6) * s, CFrame.new(-1.2 * s, -1.8 * s, -0.3 * s), c1)
	part(model, "Foot", BALL, Vector3.new(1.4, 1, 1.6) * s, CFrame.new(1.2 * s, -1.8 * s, -0.3 * s), c1)
	return body, CFrame.new(0, 1.6 * s, -0.4 * s), CFrame.new(0, -0.6 * s, 2 * s)
end

function T.quad(model, s, c1, c2)
	local body = part(model, "Body", BLOCK, Vector3.new(2.2, 1.8, 3.4) * s, CFrame.new(0, 0, 0), c1)
	local headCF = CFrame.new(0, 0.9 * s, -2 * s)
	part(model, "Head", BALL, Vector3.new(2.2, 2, 2) * s, headCF, c1)
	eyes(model, headCF, s, 0.6, -0.9)
	part(model, "Snout", BALL, Vector3.new(0.7, 0.5, 0.6) * s, headCF * CFrame.new(0, -0.3 * s, -1 * s), c2)
	for _, p in ipairs({ { -0.8, -1.2 }, { 0.8, -1.2 }, { -0.8, 1.2 }, { 0.8, 1.2 } }) do
		part(model, "Leg", BLOCK, Vector3.new(0.7, 1.4, 0.7) * s, CFrame.new(p[1] * s, -1.5 * s, p[2] * s), c2)
	end
	return body, headCF, CFrame.new(0, 0.3 * s, 2 * s)
end

function T.biped(model, s, c1, c2)
	local body = part(model, "Body", BLOCK, Vector3.new(2.2, 2.6, 1.6) * s, CFrame.new(0, 0, 0), c1)
	part(model, "Belly", BLOCK, Vector3.new(1.6, 1.8, 0.3) * s, CFrame.new(0, -0.1 * s, -0.8 * s), c2)
	local headCF = CFrame.new(0, 2.2 * s, -0.1 * s)
	part(model, "Head", BALL, Vector3.new(2, 1.9, 1.9) * s, headCF, c1)
	eyes(model, headCF, s, 0.55, -0.85)
	for _, sx in ipairs({ -1, 1 }) do
		part(model, "Arm", BLOCK, Vector3.new(0.6, 2, 0.6) * s, CFrame.new(sx * 1.5 * s, 0.1 * s, -0.2 * s) * CFrame.Angles(math.rad(-15), 0, 0), c1)
		part(model, "Leg", BLOCK, Vector3.new(0.8, 1.8, 0.9) * s, CFrame.new(sx * 0.6 * s, -2.2 * s, 0), c2)
	end
	return body, headCF, CFrame.new(0, -1 * s, 1.1 * s)
end

function T.serpent(model, s, c1, c2)
	local body = part(model, "Body", BALL, Vector3.new(2.6, 2.6, 2.6) * s, CFrame.new(0, 0, 0), c1)
	local prev = Vector3.new(0, 0, 0)
	for i = 1, 8 do
		local size = (2.4 - i * 0.2) * s
		local pos = Vector3.new(math.sin(i * 0.9) * 1.6 * s, math.cos(i * 0.7) * 0.8 * s, i * 2 * s)
		part(model, "Seg", BALL, Vector3.one * size, CFrame.new(pos), (i % 2 == 0) and c2 or c1)
		prev = pos
	end
	local headCF = CFrame.new(0, 0.4 * s, -2 * s)
	part(model, "Head", BALL, Vector3.new(2.6, 2.2, 2.8) * s, headCF, c1)
	eyes(model, headCF, s, 0.8, -1.2)
	return body, headCF, CFrame.new(prev)
end

function T.dragon(model, s, c1, c2)
	local body = part(model, "Body", BALL, Vector3.new(3.4, 3.2, 4.6) * s, CFrame.new(0, 0, 0), c1)
	part(model, "Belly", BALL, Vector3.new(2.4, 2, 3.2) * s, CFrame.new(0, -0.7 * s, -0.4 * s), c2)
	part(model, "Neck", CYL, Vector3.new(2.4, 1.1, 1.1) * s, CFrame.new(0, 1.7 * s, -1.9 * s) * CFrame.Angles(0, 0, math.rad(60)), c1)
	local headCF = CFrame.new(0, 3 * s, -2.7 * s)
	part(model, "Head", BALL, Vector3.new(2, 1.8, 2.4) * s, headCF, c1)
	part(model, "Jaw", BALL, Vector3.new(1.2, 0.7, 1.2) * s, headCF * CFrame.new(0, -0.5 * s, -1.1 * s), c2)
	eyes(model, headCF, s, 0.6, -0.7)
	for _, p in ipairs({ { -1.2, -1.4 }, { 1.2, -1.4 }, { -1.2, 1.4 }, { 1.2, 1.4 } }) do
		part(model, "Leg", BLOCK, Vector3.new(1, 1.8, 1) * s, CFrame.new(p[1] * s, -2.2 * s, p[2] * s), c2)
	end
	return body, headCF, CFrame.new(0, -0.2 * s, 2.6 * s)
end

function T.bird(model, s, c1, c2)
	local body = part(model, "Body", BALL, Vector3.new(2.6, 2.4, 4) * s, CFrame.new(0, 0, 0), c1)
	part(model, "Neck", CYL, Vector3.new(2, 0.9, 0.9) * s, CFrame.new(0, 1.2 * s, -1.8 * s) * CFrame.Angles(0, 0, math.rad(65)), c1)
	local headCF = CFrame.new(0, 2.2 * s, -2.4 * s)
	part(model, "Head", BALL, Vector3.new(1.6, 1.5, 1.8) * s, headCF, c1)
	wedge(model, "Beak", Vector3.new(0.6, 0.5, 1.1) * s, headCF * CFrame.new(0, -0.2 * s, -1.3 * s) * CFrame.Angles(0, math.rad(180), 0), c2)
	eyes(model, headCF, s, 0.5, -0.6)
	for _, sx in ipairs({ -1, 1 }) do
		wedge(model, "Wing", Vector3.new(0.4, 2.6, 4.4) * s, CFrame.new(sx * 3 * s, 0.4 * s, 0.3 * s) * CFrame.Angles(0, 0, sx * math.rad(-20)), c2)
	end
	return body, headCF, CFrame.new(0, 0, 2.4 * s)
end

-- ---------- extras ----------
local X = {}

function X.ears(model, headCF, tailCF, s, c1, c2)
	for _, sx in ipairs({ -1, 1 }) do
		wedge(model, "Ear", Vector3.new(0.4, 1.8, 0.8) * s, headCF * CFrame.new(sx * 0.7 * s, 1.5 * s, 0.1 * s) * CFrame.Angles(0, 0, sx * math.rad(-12)), c2)
	end
end

function X.horn(model, headCF, tailCF, s, c1, c2)
	wedge(model, "Horn", Vector3.new(0.5, 1.4, 0.5) * s, headCF * CFrame.new(0, 1.3 * s, -0.3 * s), c2)
end

function X.tail(model, headCF, tailCF, s, c1, c2)
	for i = 1, 4 do
		part(model, "Tail", BALL, Vector3.one * (1.2 - i * 0.2) * s, tailCF * CFrame.new(0, i * 0.35 * s, i * 0.9 * s), (i % 2 == 0) and c2 or c1)
	end
end

function X.flame(model, headCF, tailCF, s)
	part(model, "Flame", BALL, Vector3.new(1.1, 1.5, 1.1) * s, tailCF * CFrame.new(0, 1.2 * s, 4.2 * s), Color3.fromRGB(255, 150, 40), nil, true)
	part(model, "FlameCore", BALL, Vector3.new(0.6, 0.9, 0.6) * s, tailCF * CFrame.new(0, 1.1 * s, 4.2 * s), Color3.fromRGB(255, 240, 150), nil, true)
end

function X.wings(model, headCF, tailCF, s, c1, c2)
	for _, sx in ipairs({ -1, 1 }) do
		wedge(model, "Wing", Vector3.new(0.3, 3.2, 3.6) * s, CFrame.new(sx * 2.4 * s, 1.6 * s, 0.8 * s) * CFrame.Angles(0, 0, sx * math.rad(-25)), c2)
	end
end

function X.spikes(model, headCF, tailCF, s, c1, c2)
	for i = 1, 4 do
		wedge(model, "Spike", Vector3.new(0.4, 0.9, 0.8) * s, CFrame.new(0, 1.9 * s, (i - 2) * 1.1 * s) * CFrame.Angles(0, math.rad(90), 0), c2)
	end
end

function X.fins(model, headCF, tailCF, s, c1, c2)
	for _, sx in ipairs({ -1, 1 }) do
		wedge(model, "Fin", Vector3.new(0.3, 1.8, 2.2) * s, CFrame.new(sx * 2.2 * s, 0, 0) * CFrame.Angles(0, 0, sx * math.rad(-35)), c2)
	end
end

function X.halo(model, headCF, tailCF, s, c1, c2)
	for i = 1, 12 do
		local a = (i / 12) * math.pi * 2
		part(model, "Halo", BLOCK, Vector3.new(0.5, 0.5, 0.9) * s, CFrame.new(0, 0.6 * s, 0.4 * s) * CFrame.Angles(0, 0, 0)
			* CFrame.new(math.cos(a) * 3.6 * s, math.sin(a) * 3.6 * s, 2.8 * s) * CFrame.Angles(0, 0, a), c2, nil, true)
	end
end

function X.shell(model, headCF, tailCF, s, c1, c2)
	part(model, "Shell", BALL, Vector3.new(2.6, 1.8, 2.6) * s, CFrame.new(0, 0.8 * s, 0.4 * s), c2)
end

function X.bulb(model, headCF, tailCF, s, c1, c2)
	part(model, "Bulb", BALL, Vector3.new(1.8, 1.6, 1.8) * s, CFrame.new(0, 1.4 * s, 0.4 * s), c2)
	wedge(model, "Leaf", Vector3.new(0.2, 1, 0.9) * s, CFrame.new(0, 2.4 * s, 0.4 * s), Color3.fromRGB(90, 190, 90))
end

-- ---------- public ----------
function F.Build(id)
	local look = Looks[id]
	if not look then return nil end
	local model = Instance.new("Model")
	model.Name = id
	local s = look.S
	local body, headCF, tailCF = T[look.T](model, s, look.C1, look.C2)
	for _, e in ipairs(look.E) do
		if X[e] then X[e](model, headCF, tailCF, s, look.C1, look.C2) end
	end
	model.PrimaryPart = body
	for _, p in ipairs(model:GetChildren()) do
		if p:IsA("BasePart") and p ~= body then
			local w = Instance.new("WeldConstraint")
			w.Part0 = body
			w.Part1 = p
			w.Parent = body
		end
	end
	return model
end

function F.Has(id)
	return Looks[id] ~= nil
end

return F
