-- ModuleScript
-- Location: ServerScriptService > Server > SyncService
-- Sends the player's own state to their client (debounced). The client only ever READS this.
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Remotes = require(ReplicatedStorage.Shared.Remotes)
local DataService = require(script.Parent.DataService)

local SyncService = {}
local queued = {}

function SyncService.Snapshot(player)
	local d = DataService.Get(player)
	if not d then
		return nil
	end
	return {
		Coins = d.Coins,
		Pending = math.floor(d.Pending),
		Owned = d.Owned,
		Stationed = d.Stationed,
		BaseLevel = d.BaseLevel,
		Loadout = d.Loadout,
		Rebirths = d.Rebirths,
		Rank = d.Rank,
		Settings = d.Settings,
	}
end

function SyncService.Push(player)
	local snap = SyncService.Snapshot(player)
	if snap then
		Remotes.Get("Sync"):FireClient(player, snap)
	end
end

-- Call after any change to player data.
function SyncService.Queue(player)
	if queued[player] then
		return
	end
	queued[player] = true
	task.delay(0.2, function()
		queued[player] = nil
		if player.Parent then
			SyncService.Push(player)
		end
	end)
end

function SyncService.Init(Router)
	Router.Register("GetState", { rate = 1, burst = 3 }, function(player)
		return true, SyncService.Snapshot(player)
	end)
end

return SyncService
