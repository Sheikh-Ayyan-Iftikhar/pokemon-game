-- ModuleScript
-- Location: ReplicatedStorage > Shared > Config > PokemonLooks
-- How each Pokemon is drawn by ModelFactory (simple original part-built models).
-- T = body template: blob, quad, biped, serpent, dragon, bird.   S = scale.   E = extras.
local C = Color3.fromRGB
return {
	ARCEUS    = { T = "quad",    C1 = C(245, 245, 235), C2 = C(230, 190, 60),  E = { "halo", "horn", "tail" }, S = 1.8 },
	RAYQUAZA  = { T = "serpent", C1 = C(40, 150, 90),   C2 = C(240, 200, 60),  E = { "spikes", "fins" }, S = 2 },
	MEWTWO    = { T = "biped",   C1 = C(225, 215, 235), C2 = C(150, 90, 190),  E = { "tail", "horn" }, S = 1.4 },
	KYOGRE    = { T = "blob",    C1 = C(40, 90, 200),   C2 = C(235, 235, 245), E = { "fins" }, S = 2.2 },
	GROUDON   = { T = "blob",    C1 = C(190, 50, 40),   C2 = C(60, 60, 60),    E = { "spikes" }, S = 2.2 },
	DIALGA    = { T = "dragon",  C1 = C(70, 100, 170),  C2 = C(220, 225, 235), E = { "spikes" }, S = 2 },
	GIRATINA  = { T = "dragon",  C1 = C(50, 50, 60),    C2 = C(190, 50, 50),   E = { "spikes", "wings" }, S = 2 },
	LUGIA     = { T = "bird",    C1 = C(235, 240, 250), C2 = C(70, 110, 190),  E = { "fins" }, S = 2 },
	PALKIA    = { T = "dragon",  C1 = C(215, 190, 215), C2 = C(240, 120, 200), E = { "fins" }, S = 2 },
	GARCHOMP  = { T = "dragon",  C1 = C(60, 80, 150),   C2 = C(200, 60, 60),   E = { "fins", "spikes" }, S = 1.6 },
	DRAGONITE = { T = "biped",   C1 = C(240, 170, 70),  C2 = C(240, 230, 190), E = { "wings", "tail", "horn" }, S = 1.6 },
	DEOXYS    = { T = "biped",   C1 = C(190, 60, 60),   C2 = C(80, 110, 220),  E = { "spikes", "tail" }, S = 1.4 },
	MEW       = { T = "biped",   C1 = C(245, 190, 210), C2 = C(255, 255, 255), E = { "tail", "ears" }, S = 0.9 },
	CHARIZARD = { T = "dragon",  C1 = C(235, 130, 50),  C2 = C(240, 215, 160), E = { "wings", "flame", "horn" }, S = 1.7 },
	GYARADOS  = { T = "serpent", C1 = C(60, 110, 200),  C2 = C(240, 230, 190), E = { "fins", "spikes" }, S = 2 },
	LUCARIO   = { T = "biped",   C1 = C(70, 110, 190),  C2 = C(240, 210, 80),  E = { "ears", "spikes" }, S = 1.2 },
	GARDEVOIR = { T = "biped",   C1 = C(240, 240, 240), C2 = C(70, 170, 110),  E = { "ears" }, S = 1.3 },
	GRENINJA  = { T = "biped",   C1 = C(50, 90, 180),   C2 = C(240, 240, 250), E = { "tail" }, S = 1.1 },
	ALAKAZAM  = { T = "biped",   C1 = C(235, 200, 80),  C2 = C(150, 100, 60),  E = { "ears", "horn" }, S = 1.2 },
	GENGAR    = { T = "blob",    C1 = C(90, 60, 140),   C2 = C(230, 60, 80),   E = { "ears", "spikes" }, S = 1.3 },
	SNORLAX   = { T = "blob",    C1 = C(40, 90, 100),   C2 = C(240, 235, 205), E = { "ears" }, S = 2 },
	MIMIKYU   = { T = "biped",   C1 = C(235, 210, 90),  C2 = C(60, 50, 50),    E = { "ears" }, S = 1 },
	SYLVEON   = { T = "quad",    C1 = C(245, 205, 220), C2 = C(100, 160, 230), E = { "ears", "tail" }, S = 1 },
	UMBREON   = { T = "quad",    C1 = C(40, 40, 50),    C2 = C(240, 215, 70),  E = { "ears", "tail" }, S = 1 },
	PIKACHU   = { T = "quad",    C1 = C(245, 215, 60),  C2 = C(220, 60, 50),   E = { "ears", "tail" }, S = 0.9 },
	EEVEE     = { T = "quad",    C1 = C(170, 115, 70),  C2 = C(240, 225, 190), E = { "ears", "tail" }, S = 0.9 },
	SQUIRTLE  = { T = "quad",    C1 = C(100, 175, 215), C2 = C(160, 110, 60),  E = { "shell", "tail" }, S = 0.9 },
	BULBASAUR = { T = "quad",    C1 = C(110, 185, 160), C2 = C(70, 150, 70),   E = { "bulb", "tail" }, S = 0.9 },
	CHARMANDER = { T = "biped",  C1 = C(235, 135, 60),  C2 = C(245, 225, 170), E = { "flame", "tail" }, S = 0.9 },
	DITTO     = { T = "blob",    C1 = C(200, 170, 225), C2 = C(120, 90, 160),  E = {}, S = 1 },
}
