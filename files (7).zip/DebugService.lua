-- ModuleScript
-- Location: ServerScriptService > Server > DebugService
-- STUDIO ONLY. Lets you grant + station + equip any Pokemon instantly to test its moves/passives.
-- Refuses to register on live servers. Delete this file before publishing if you like.
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local PokemonData = require(ReplicatedStorage.Shared.Config.PokemonData)
local Economy = require(ReplicatedStorage.Shared.Config.Economy)
local DataService = require(script.Parent.DataService)
local InventoryService = require(script.Parent.InventoryService)
local BaseService = require(script.Parent.BaseService)
local LoadoutService = require(script.Parent.LoadoutService)

local Debug = {}

function Debug.Init(Router)
	if not RunService:IsStudio() then return end

	Router.Register("DebugEquip", { rate = 5, burst = 10 }, function(player, p)
		if not Router.IsId(p.pokemonId) then return false, "BadRequest" end
		local def = PokemonData.Get(p.pokemonId)
		if not def then return false, "UnknownPokemon" end
		local data = DataService.Get(player)

		local uid
		for u, inst in pairs(data.Owned) do
			if inst.Id == def.Id then uid = u break end
		end
		if not uid then uid = InventoryService.Grant(player, def.Id) end
		if not uid then return false, "GrantFailed" end

		if not table.find(data.Stationed, uid) then
			if #data.Stationed >= BaseService.Capacity(data) then
				data.BaseLevel = #Economy.BaseCapacity
			end
			-- still full: unstation something that is not equipped
			local guard = 0
			while #data.Stationed >= BaseService.Capacity(data) and guard < 40 do
				guard += 1
				for _, other in ipairs(data.Stationed) do
					local equipped = false
					for _, v in pairs(data.Loadout) do if v == other then equipped = true end end
					if not equipped then BaseService.Unstation(player, other) break end
				end
			end
			local ok, err = BaseService.Station(player, uid)
			if not ok then return false, err end
		end

		local slot = "Active"
		if def.Kind == "Passive" then
			slot = "Passive1"
			for _, s in ipairs({ "Passive1", "Passive2", "Passive3" }) do
				if data.Loadout[s] == "" then slot = s break end
			end
		end
		return LoadoutService.Equip(player, slot, uid)
	end)
end

return Debug
