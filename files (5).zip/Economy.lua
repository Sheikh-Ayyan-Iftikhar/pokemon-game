-- ModuleScript
-- Location: ReplicatedStorage > Shared > Config > Economy
-- NOTE: Your documents do not define any numbers for the economy.
-- Every value below is a TUNABLE DEFAULT, not something from your design docs.
local Economy = {}

Economy.StartingCoins = 250
Economy.StarterPokemonIds = { "CHARMANDER" } -- given once to new players and stationed automatically
Economy.MaxOwned = 200                       -- keeps save data size bounded

-- Base: index = base level
Economy.BaseCapacity = { 4, 6, 8, 10, 12 }
Economy.BaseUpgradeCost = { [2] = 500, [3] = 2500, [4] = 10000, [5] = 40000 } -- cost to reach that level

-- Income per second per stationed Pokemon, by rarity
Economy.RarityIncome = { Common = 1, Rare = 4, Epic = 12, Legendary = 40, Mythical = 120 }

-- Shop
Economy.RarityPrice = { Common = 100, Rare = 600, Epic = 3500, Legendary = 20000, Mythical = 100000 }
Economy.PurchasableRarities = { Common = true, Rare = true, Epic = true } -- Legendary/Mythical: steal / wager / drops only

-- Passive income pool
Economy.MaxPendingSeconds = 2 * 3600  -- uncollected income stops growing after this much time
Economy.OfflineCapSeconds = 8 * 3600
Economy.OfflineRate = 0.5

-- Rebirth: economic only (architecture doc: must NOT increase combat damage or ability strength)
Economy.RebirthBonusPerLevel = 0.25
function Economy.RebirthMultiplier(rebirths)
	return 1 + rebirths * Economy.RebirthBonusPerLevel
end

return Economy
