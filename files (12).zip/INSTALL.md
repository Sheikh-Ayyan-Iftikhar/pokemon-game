# Roblox Studio mein game kaise dalein (step by step)

Is folder mein 39 scripts hain (Phase 1 se 5 tak, sab latest versions). Aap ko kuch code type nahi karna, sirf import karna hai.
**Dhyan:** yeh code kabhi Roblox Studio mein run nahi hua (mere paas Studio nahi). Files ka format aur syntax check ho chuka hai,
lekin pehli baar chalane par chhote bugs aa sakte hain. Neeche "Errors bhejna" wala hissa dekhein.

## Zaroori cheezein
1. **Roblox Studio** (free): create.roblox.com se download karein, apne Roblox account se login karein.
2. Studio mein **New > Baseplate** se ek naya place kholen.

## Step 1: Place ko publish karein (saving test karne ke liye zaroori)
- **File > Publish to Roblox** (ya Save to Roblox), koi naam dein (maslan "Pokemon Game").
- **Home tab > Game Settings > Security** mein **"Enable Studio Access to API Services"** ON karein, phir Save.
  (Bina iske data saving Studio mein kaam nahi karti; game phir bhi chalegi lekin temporary data ke saath.)

## Step 2: Scripts import karein (Explorer window zaroori hai: View > Explorer)
Har file ke liye: Explorer mein sahi item par **right-click > Insert from File...** aur file chunein.

| # | File | Kis par right-click karein | Kya banega |
|---|---|---|---|
| 1 | `1_ReplicatedStorage__Shared.rbxmx` | **ReplicatedStorage** | folder `Shared` (Remotes + folder Config) |
| 2 | `2_ServerScriptService__Server.rbxmx` | **ServerScriptService** | folder `Server` (20 modules + `Main` script) |
| 3 | `3_StarterPlayerScripts__Client.rbxmx` | **StarterPlayer > StarterPlayerScripts** | 3 scripts: Api, CombatClient, AnimClient |
| 4 | `4_OPTIONAL_StarterPlayerScripts__TestScripts.rbxmx` | **StarterPlayer > StarterPlayerScripts** | test scripts (ClientTest, PvpTest, RebirthTest) |

File 4 sirf testing ke liye hai. Asli game publish karne se pehle use delete kar dein.

Import ke baad Explorer aisa dikhna chahiye:
```
ReplicatedStorage
  Shared (Remotes, Config > Animations, CombatConfig, Economy, Kits, Moves, Passives, PokemonData, PvpConfig, Rarity, RebirthConfig, StealConfig)
ServerScriptService
  Server (AbilityService, BaseService, BaseWorld, BasicCombat, CombatService, DataService, DebugService, Executors, Fx, InventoryService,
          LoadoutService, Locks, Main, MatchService, Notify, PassiveService, RateLimiter, RebirthService, Router, StealService, SyncService)
StarterPlayer > StarterPlayerScripts
  AnimClient, Api, CombatClient (+ ClientTest, PvpTest, RebirthTest agar file 4 import ki)
```
**Naam aur jagah bilkul yehi honi chahiye**, warna scripts ek doosre ko nahi dhoondh payengi.

## Step 3: Chalayein aur test karein
- Pehle **View > Output** kholen (yahan errors dikhte hain).
- **Home > Play** (ya F5): 1 player. Do players ke liye **Test tab > Clients and Servers > Players: 2 > Start**.
- Aap apne placeholder base par spawn honge (Workspace mein `Bases` aur `Effects` folder khud ban jate hain).
  Ek Charmander gend ki shakal mein pedestal par hoga.
- File 4 import ki ho to 3 second baad ClientTest Pikachu aur Snorlax khud equip kar deta hai.

### Controls
| Key | Kaam |
|---|---|
| Mouse1 | basic attack (3-hit combo) |
| F (dabaye rakhein) | block |
| Q | dash |
| 1 - 6 | Active Pokémon ke moves |
| R | Mew ka borrowed ability |
| E (pedestal par 3 sec hold) | doosre ke base se steal |
| K / L | ranked queue join / leave |
| J / H / G / N | wager invite / accept / confirm / decline |
| C / B / V | (Studio) 1,000,000 coins / rebirth info / rebirth |

Damage test karne ke liye: Workspace mein Rig Builder se ek dummy daalein aur Tag Editor se usay tag `CombatDummy` dein,
ya 2 players mode mein ek doosre par try karein (Studio mein sab ek doosre ko maar sakte hain).

## Agar "Insert from File" kaam na kare (manual tareeqa)
`RobloxGame_Source.zip` kholen. Andar `src/Shared`, `src/Server`, `src/Client` folders hain.
Har `.lua` file ke liye Explorer mein sahi jagah **+ > ModuleScript** (ya Script / LocalScript) banayein, naam file ke naam jaisa dein
(`.lua` ke bagair), aur file ka poora text paste kar dein:
- `Main.server.lua` = **Script** (ServerScriptService > Server ke andar)
- `*.client.lua` = **LocalScript** (StarterPlayerScripts mein)
- baqi sab = **ModuleScript** (folders: ReplicatedStorage > Shared / Shared > Config, ServerScriptService > Server, StarterPlayerScripts).

## Aam masle
| Output mein message | Matlab / hal |
|---|---|
| `Infinite yield possible on 'ReplicatedStorage.Shared'` | Folder ghalat jagah par hai. `Shared` ReplicatedStorage ke seedha andar hona chahiye |
| `... is not a valid member of ...` | koi script ghalat folder mein hai ya naam badal gaya |
| `Could not load real data ... TEMPORARY data` | Step 1 ka API access ON nahi ya place publish nahi hua. Game chalti hai magar save nahi hota |
| Kuch bhi nahi hota | `Main` ModuleScript ban gayi ho to Script mein badlein, aur Server folder ke andar honi chahiye |
| Pokémon sirf gend dikhte hain | Normal hai. Asli 3D models aap ko `ServerStorage > PokemonModels` mein dene hain (naam = Pokémon id, maslan `PIKACHU`) |

## Errors bhejna
Play ke baad Output window mein **laal** lines copy karke mujhe bhej dein (ya screenshot). Main fix kar ke naye files de dunga.

## Abhi kya NAHI hai (honest list)
- **Koi menu/UI nahi** (collection, shop, loadout, rebirth, PvP screens). Abhi sirf test keys hain. Yeh Phase 7 hai.
- **Maps nahi** (6 maps), **3D models nahi**, **animations nahi**, VFX sirf neon parts. Yeh Studio mein aap ko banana hai ya Toolbox/artist se lena hai.
- Security/hardening ka aakhri pass (Phase 6) baqi hai, is liye abhi isay public na karein.
- Roster 30 Pokémon ka hai (aap ke doc ke mutabiq), 40 nahi.

Asli game banne tak: Phase 6 (hardening) + Phase 7 (UI) + aap ka art/maps ka kaam.
