-- ModuleScript
-- Location: ServerScriptService > Server > Security
-- Anti-exploit helpers: strikes, movement/teleport validation, server-teleport "grace" windows.
-- The movement check is a HEURISTIC: it can false-positive on bad lag, so it rubber-bands first and only kicks after many strikes.
local Players = game:GetService("Players")

local Security = {}

local CFG = {
	Tolerance = 1.35,       -- allowed horizontal speed = WalkSpeed * Tolerance + Slack
	Slack = 24,
	FlyingSpeed = 175,      -- allowed while the server-set "Flying" status is active
	MaxRise = 95,           -- studs/second upward without a server impulse/teleport
	KickAt = 12,            -- strikes before kick
	DecayEvery = 8,         -- seconds per strike forgiven
}

local state = {}
local function st(player)
	local s = state[player]
	if not s then
		s = { Grace = 0, Strikes = 0, LastDecay = os.clock() }
		state[player] = s
	end
	return s
end

function Security.Clear(player)
	state[player] = nil
end

-- Call right before the SERVER moves a player (teleport, impulse, dash...) so it is not mistaken for cheating.
function Security.Grace(player, seconds)
	local s = st(player)
	s.Grace = math.max(s.Grace, os.clock() + seconds)
end

function Security.GraceModel(model, seconds)
	local p = model and Players:GetPlayerFromCharacter(model)
	if p then Security.Grace(p, seconds) end
end

function Security.GraceEntity(ent, seconds)
	if ent and ent.Player then Security.Grace(ent.Player, seconds) end
end

function Security.Strike(player, reason, weight)
	local s = st(player)
	s.Strikes += weight or 1
	if s.Strikes >= CFG.KickAt then
		warn(("[Security] kicking %s (%s)"):format(player.Name, tostring(reason)))
		player:Kick("Kicked by anti-cheat (" .. tostring(reason) .. ").")
	end
end

function Security.Start(Combat)
	task.spawn(function()
		while true do
			task.wait(0.5)
			local now = os.clock()
			for _, player in ipairs(Players:GetPlayers()) do
				local s = st(player)
				if now - s.LastDecay > CFG.DecayEvery then
					s.LastDecay = now
					s.Strikes = math.max(0, s.Strikes - 1)
				end
				local ent = Combat.EntityOf(player)
				if not ent then
					s.Model = nil
				else
					local pos = ent.Root.Position
					if s.Model ~= ent.Model then
						s.Model, s.Last, s.T = ent.Model, pos, now -- new character: start fresh
					elseif now < s.Grace or ent.Root.Anchored then
						s.Last, s.T = pos, now
					else
						local dt = math.max(0.05, now - s.T)
						local d = pos - s.Last
						local horizontal = Vector3.new(d.X, 0, d.Z).Magnitude / dt
						local rise = d.Y / dt
						local allowed = ent.Hum.WalkSpeed * CFG.Tolerance + CFG.Slack
						if Combat.Mod(ent.Model, "Flying") then allowed = math.max(allowed, CFG.FlyingSpeed) end
						if horizontal > allowed or (rise > CFG.MaxRise and not Combat.Mod(ent.Model, "Flying")) then
							-- rubber-band back to the last position that looked valid
							ent.Model:PivotTo(CFrame.new(s.Last) * ent.Root.CFrame.Rotation)
							s.Grace = now + 0.4
							s.T = now
							Security.Strike(player, "movement", 1)
						else
							s.Last, s.T = pos, now
						end
					end
				end
			end
		end
	end)
end

return Security
