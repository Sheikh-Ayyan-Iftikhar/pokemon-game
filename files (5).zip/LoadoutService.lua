-- ModuleScript
-- Location: ServerScriptService > Server > LoadoutService
-- Architecture rules: 1 Active slot + 3 Passive slots, only Pokemon STATIONED in the base can be equipped.
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local PokemonData = require(ReplicatedStorage.Shared.Config.PokemonData)
local DataService = require(script.Parent.DataService)
local SyncService = require(script.Parent.SyncService)

local SLOT_KIND = { Active = "Active", Passive1 = "Passive", Passive2 = "Passive", Passive3 = "Passive" }

local Loadout = {}

function Loadout.Equip(player, slot, uid)
	local data = DataService.Get(player)
	if not data then return false, "NoData" end
	if type(slot) ~= "string" or not SLOT_KIND[slot] then return false, "BadSlot" end
	if type(uid) ~= "string" then return false, "BadRequest" end
	if player:GetAttribute("InMatch") then return false, "InMatch" end

	local inst = data.Owned[uid]
	if not inst then return false, "NotOwned" end
	if not table.find(data.Stationed, uid) then return false, "NotStationed" end

	local def = PokemonData.Get(inst.Id)
	if not def then return false, "UnknownPokemon" end
	if def.Kind ~= SLOT_KIND[slot] then return false, "WrongKind" end

	-- Same Pokemon (or same species) cannot occupy two slots.
	for otherSlot, otherUid in pairs(data.Loadout) do
		if otherSlot ~= slot and otherUid ~= "" then
			local other = data.Owned[otherUid]
			if otherUid == uid or (other and other.Id == inst.Id) then
				return false, "AlreadyEquipped"
			end
		end
	end

	data.Loadout[slot] = uid
	SyncService.Queue(player)
	return true
end

function Loadout.Unequip(player, slot)
	local data = DataService.Get(player)
	if not data then return false, "NoData" end
	if type(slot) ~= "string" or not SLOT_KIND[slot] then return false, "BadSlot" end
	if player:GetAttribute("InMatch") then return false, "InMatch" end
	data.Loadout[slot] = ""
	SyncService.Queue(player)
	return true
end

-- Used when a Pokemon leaves the base / is stolen / is lost.
function Loadout.ClearUid(data, uid)
	for slot, v in pairs(data.Loadout) do
		if v == uid then
			data.Loadout[slot] = ""
		end
	end
end

-- Returns the PokemonData defs currently equipped (for the ability system in Phase 2).
function Loadout.GetEquippedDefs(data)
	local out = {}
	for slot, uid in pairs(data.Loadout) do
		local inst = uid ~= "" and data.Owned[uid]
		if inst and table.find(data.Stationed, uid) then
			out[slot] = PokemonData.Get(inst.Id)
		end
	end
	return out
end

function Loadout.Init(Router)
	Router.Register("Equip", { rate = 2, burst = 4 }, function(player, p)
		if not Router.IsId(p.slot) or not Router.IsId(p.uid) then return false, "BadRequest" end
		return Loadout.Equip(player, p.slot, p.uid)
	end)
	Router.Register("Unequip", { rate = 2, burst = 4 }, function(player, p)
		if not Router.IsId(p.slot) then return false, "BadRequest" end
		return Loadout.Unequip(player, p.slot)
	end)
end

return Loadout
