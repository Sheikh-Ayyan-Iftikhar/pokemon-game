-- ModuleScript
-- Location: ServerScriptService > Server > Executors
-- One function per move "Exec" type. The 50 moves are config entries that pick one of these and pass parameters.
-- Every executor returns false if the move could not be used (no target etc.): then NO cooldown/stamina is spent.
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Remotes = require(ReplicatedStorage.Shared.Remotes)
local Cfg = require(ReplicatedStorage.Shared.Config.CombatConfig)
local Kits = require(ReplicatedStorage.Shared.Config.Kits)
local PokemonData = require(ReplicatedStorage.Shared.Config.PokemonData)
local Combat = require(script.Parent.CombatService)
local Fx = require(script.Parent.Fx)

local E = {}

-- ---------- helpers ----------
local function tagsOf(spec)
	return { Ability = true, Melee = spec.Melee }
end

local function applyEffects(effects, ent, casterEnt)
	for _, e in ipairs(effects or {}) do
		Combat.AddStatus(ent.Model, e.Status, e.Duration, e.Mods, {
			Shield = e.Shield, Dot = e.Dot, Source = casterEnt and casterEnt.Model or nil,
		})
	end
end

local function hit(ctx, ent, damage, tags)
	if damage and damage > 0 then
		Combat.Damage(ctx.Caster.Model, ent.Model, damage, tags or tagsOf(ctx.Spec))
	end
	applyEffects(ctx.Spec.Effects, ent, ctx.Caster)
end

local function segDist(a, b, p)
	local ab = b - a
	local len2 = ab:Dot(ab)
	local t = len2 > 0 and math.clamp((p - a):Dot(ab) / len2, 0, 1) or 0
	return (a + ab * t - p).Magnitude
end

local function nearestEnemy(ctx, range)
	local root = ctx.Caster.Root.Position
	local ref = ctx.Point or root
	local best, bestD
	for _, e in ipairs(Combat.Enemies(ctx.Caster.Model)) do
		if (e.Root.Position - root).Magnitude <= range then
			local d = (e.Root.Position - ref).Magnitude
			if not bestD or d < bestD then best, bestD = e, d end
		end
	end
	return best
end

local function resolveCenter(ctx, spec)
	local root = ctx.Caster.Root.Position
	local c = spec.Center or "Self"
	if c == "Self" then
		return root
	elseif c == "Front" then
		return root + ctx.Dir * (spec.Offset or 10)
	elseif c == "Aim" then
		local maxR = spec.Range or 50
		local p = ctx.Point or (root + ctx.Dir * maxR)
		local off = p - root
		if off.Magnitude > maxR then p = root + off.Unit * maxR end
		return p
	elseif c == "Target" then
		local t = nearestEnemy(ctx, spec.Range or 50)
		return t and t.Root.Position or nil
	end
	return root
end

-- ---------- Projectile ----------
local function fireProjectile(ctx, origin, dir)
	local spec, caster = ctx.Spec, ctx.Caster
	local part = Fx.Projectile(origin, spec.Size or Vector3.new(2, 2, 2), spec.Color)
	local speed = (spec.Speed or 100) * Combat.Mod(caster.Model, "ProjectileSpeed")
	local range = spec.Range or 80
	local radius = (spec.Radius or 3) + Cfg.HitRadiusPad
	local pos, traveled, hitSet, conn = origin, 0, {}, nil

	local function finish()
		if conn then conn:Disconnect() end
		part:Destroy()
	end

	conn = RunService.Heartbeat:Connect(function(dt)
		local step = speed * dt
		local nextPos = pos + dir * step
		for _, e in ipairs(Combat.Enemies(caster.Model)) do
			if not hitSet[e.Model] and segDist(pos, nextPos, e.Root.Position) <= radius then
				hitSet[e.Model] = true
				hit(ctx, e, spec.Damage)
				if not spec.Pierce then
					finish()
					return
				end
			end
		end
		pos = nextPos
		part.Position = pos
		traveled += step
		if traveled >= range then finish() end
	end)
end

function E.Projectile(ctx)
	local spec, caster = ctx.Spec, ctx.Caster
	task.spawn(function()
		for r = 1, spec.Repeat or 1 do
			if caster.Hum.Health <= 0 then return end
			local count = spec.Count or 1
			for i = 1, count do
				local dir = ctx.Dir
				if spec.Spread and count > 1 then
					local ang = math.rad(spec.Spread) * ((i - 1) / (count - 1) - 0.5) * 2
					dir = CFrame.Angles(0, ang, 0) * dir
				end
				local origin = caster.Root.Position + Vector3.new(0, 1, 0) + dir * 3
				if spec.Origin == "Scatter" then
					local a, rr = math.random() * math.pi * 2, math.random() * (spec.OriginRadius or 10)
					origin = caster.Root.Position + Vector3.new(math.cos(a) * rr, 4, math.sin(a) * rr)
				end
				fireProjectile(ctx, origin, dir)
			end
			if r < (spec.Repeat or 1) then task.wait(spec.Interval or 0) end
		end
	end)
	return true
end

-- ---------- Aoe (instant, delayed, repeated, scattered, following) ----------
function E.Aoe(ctx)
	local spec, caster = ctx.Spec, ctx.Caster
	local center = resolveCenter(ctx, spec)
	if not center then return false end

	task.spawn(function()
		local points = { center }
		if spec.Scatter then
			points = {}
			for i = 1, spec.Count or 5 do
				local a = math.random() * math.pi * 2
				local r = math.sqrt(math.random()) * (spec.ScatterRadius or 10)
				points[i] = center + Vector3.new(math.cos(a) * r, 0, math.sin(a) * r)
			end
		end
		if spec.Clones then
			Fx.Clones(caster.Model, points, (spec.Delay or 0) + (spec.Ticks or 1) * (spec.TickEvery or 0.5))
		end
		if (spec.Delay or 0) > 0 then
			for _, p in ipairs(points) do Fx.Telegraph(p, spec.Radius, spec.Delay, spec.Color) end
			task.wait(spec.Delay)
		end
		for tick = 1, spec.Ticks or 1 do
			if caster.Hum.Health <= 0 then return end
			if spec.Follow then
				local fresh = Combat.EntityFromModel(caster.Model)
				if not fresh then return end
				local c = resolveCenter({ Caster = fresh, Spec = spec, Dir = fresh.Root.CFrame.LookVector }, spec)
				if c then points = { c } end
			end
			for _, p in ipairs(points) do
				Fx.Sphere(p, spec.Radius, spec.Color, 0.3)
				for _, e in ipairs(Combat.Enemies(caster.Model)) do
					if (e.Root.Position - p).Magnitude <= spec.Radius + Cfg.HitRadiusPad then
						hit(ctx, e, spec.Damage)
						if spec.Lift then Combat.Impulse(e, Vector3.new(0, spec.Lift, 0), 0.3) end
						if spec.Pull then
							local inward = p - e.Root.Position
							inward = Vector3.new(inward.X, 0, inward.Z)
							if inward.Magnitude > 1 then Combat.Impulse(e, inward.Unit * spec.Pull, 0.25) end
						end
					end
				end
			end
			if tick < (spec.Ticks or 1) then task.wait(spec.TickEvery or 0.5) end
		end
	end)
	return true
end

-- ---------- Dash ----------
function E.Dash(ctx)
	local spec, caster = ctx.Spec, ctx.Caster
	local dir = Vector3.new(ctx.Dir.X, 0, ctx.Dir.Z)
	dir = dir.Magnitude > 0.01 and dir.Unit or caster.Root.CFrame.LookVector
	local time = spec.Time or 0.25
	local dist = (spec.Distance or 30) * Combat.Mod(caster.Model, "Dash")
	Combat.Impulse(caster, dir * (dist / time), time)
	task.spawn(function()
		local t0, hitSet = os.clock(), {}
		while os.clock() - t0 < time + 0.05 do
			for _, e in ipairs(Combat.Enemies(caster.Model)) do
				if not hitSet[e.Model] and (e.Root.Position - caster.Root.Position).Magnitude <= (spec.Radius or 5) + Cfg.HitRadiusPad then
					hitSet[e.Model] = true
					hit(ctx, e, spec.Damage)
				end
			end
			task.wait()
		end
	end)
	return true
end

-- ---------- Self buffs / shields / heals ----------
function E.Self(ctx)
	local spec, caster = ctx.Spec, ctx.Caster
	for _, e in ipairs(spec.SelfEffects or {}) do
		Combat.AddStatus(caster.Model, e.Status, e.Duration, e.Mods, { Shield = e.Shield })
	end
	if spec.Heal then Combat.Heal(caster.Model, spec.Heal) end
	Fx.Sphere(caster.Root.Position, 5, spec.Color, 0.4)
	return true
end

-- ---------- Teleport ----------
function E.Teleport(ctx)
	local spec, caster = ctx.Spec, ctx.Caster
	local root = caster.Root.Position
	local off = (ctx.Point or (root + ctx.Dir * (spec.MaxRange or 50))) - root
	if off.Magnitude > (spec.MaxRange or 50) then off = off.Unit * (spec.MaxRange or 50) end
	if off.Magnitude < 1 then return false end
	local params = RaycastParams.new()
	params.FilterType = Enum.RaycastFilterType.Exclude
	params.FilterDescendantsInstances = { caster.Model }
	local r = workspace:Raycast(root, off, params)
	local dest = r and (r.Position - off.Unit * 3) or (root + off)
	caster.Model:PivotTo(CFrame.new(dest) * caster.Root.CFrame.Rotation)
	Fx.Sphere(root, 5, spec.Color or Color3.fromRGB(255, 150, 230), 0.4)
	return true
end

-- ---------- Rewind (Dialga) ----------
function E.Rewind(ctx)
	local spec = ctx.Spec
	return Combat.Rewind(ctx.Caster, spec.Seconds or 3, { Health = spec.Health, Stamina = spec.Stamina, Position = spec.Position })
end

-- ---------- Flight ----------
-- Server sets the Flying status; the client steers (see CombatClient). Real anti-cheat for speed comes in the security pass.
function E.Flight(ctx)
	local spec, caster = ctx.Spec, ctx.Caster
	Combat.AddStatus(caster.Model, "Flying", spec.Duration, { Flying = true })
	if caster.Player then
		Remotes.Get("Impulse"):FireClient(caster.Player, { mode = "Fly", speed = spec.Speed or 70, t = spec.Duration or 5 })
	end
	return true
end

-- ---------- Compound: run several executors together ----------
function E.Compound(ctx)
	local any = false
	for _, sub in ipairs(ctx.Spec.Steps) do
		local subCtx = { Caster = ctx.Caster, Spec = sub, Dir = ctx.Dir, Point = ctx.Point, Data = ctx.Data }
		if E[sub.Exec](subCtx) ~= false then any = true end
	end
	return any
end

-- ---------- Carry (lift / trap / slam / hop / drop an enemy) ----------
function E.Carry(ctx)
	local spec, caster = ctx.Spec, ctx.Caster
	local target = nearestEnemy(ctx, spec.Range or 30)
	if not target then return false end
	local startPos = target.Root.Position
	local rot = target.Root.CFrame.Rotation
	local duration, height, every = spec.Duration or 4, spec.Height or 0, spec.TickEvery or 1
	if spec.Cage then Fx.Cage(startPos, Vector3.new(14, 14, 14), spec.Color, duration) end

	task.spawn(function()
		local wasAnchored = target.Root.Anchored
		local casterWasAnchored = caster.Root.Anchored
		target.Root.Anchored = true
		if spec.CarryCaster then caster.Root.Anchored = true end
		local t0 = os.clock()
		local nextTick, slamUntil, hop = t0 + every, 0, Vector3.zero

		while os.clock() - t0 < duration do
			if target.Hum.Health <= 0 or caster.Hum.Health <= 0 or not target.Root.Parent then break end
			local t = os.clock() - t0
			local y = height * math.sin(math.min(1, t / math.min(0.8, duration)) * math.pi / 2)
			if spec.Slam and os.clock() < slamUntil then y = 0 end
			local pos = startPos + hop + Vector3.new(0, y, 0)
			target.Model:PivotTo(CFrame.new(pos) * rot)
			if spec.CarryCaster then
				caster.Model:PivotTo(CFrame.new(pos + Vector3.new(0, 0, 5)) * caster.Root.CFrame.Rotation)
			end
			if os.clock() >= nextTick then
				nextTick += every
				hit(ctx, target, spec.TickDamage)
				if spec.Slam then slamUntil = os.clock() + 0.2 end
				if spec.Hops then
					local a, r = math.random() * math.pi * 2, math.random() * (spec.HopRadius or 30)
					hop = Vector3.new(math.cos(a) * r, 0, math.sin(a) * r)
				end
			end
			task.wait()
		end

		pcall(function() target.Root.Anchored = wasAnchored end)
		if spec.CarryCaster then pcall(function() caster.Root.Anchored = casterWasAnchored end) end
		if target.Hum.Health > 0 then
			if spec.DropDamage then hit(ctx, target, spec.DropDamage) end
			if height > 0 then Combat.Impulse(target, Vector3.new(0, -(spec.DropSpeed or 80), 0), 0.4) end
		end
	end)
	return true
end

-- ---------- Realm (pull caster + enemy into a far-away arena, then return both) ----------
local realmCounter = 0
function E.Realm(ctx)
	local spec, caster = ctx.Spec, ctx.Caster
	local target = nearestEnemy(ctx, spec.Range or 40)
	if not target then return false end
	realmCounter = (realmCounter % 40) + 1
	local origin = Vector3.new(realmCounter * 300, 6000, 0)
	local platform = Fx.Platform(origin, 140, spec.Color)
	local saved = {
		[caster.Model] = caster.Root.CFrame,
		[target.Model] = target.Root.CFrame,
	}
	caster.Model:PivotTo(CFrame.new(origin + Vector3.new(-18, 4, 0)))
	target.Model:PivotTo(CFrame.new(origin + Vector3.new(18, 4, 0)))
	applyEffects(spec.Effects, target, caster)
	for _, e in ipairs(spec.CasterEffects or {}) do
		Combat.AddStatus(caster.Model, e.Status, e.Duration, e.Mods)
	end
	task.delay(spec.Duration or 10, function()
		for model, cf in pairs(saved) do
			local hum = model.Parent and model:FindFirstChildOfClass("Humanoid")
			if hum and hum.Health > 0 then model:PivotTo(cf) end
		end
		platform:Destroy()
	end)
	return true
end

-- ---------- Burrow (Gyarados) ----------
function E.Burrow(ctx)
	local spec, caster = ctx.Spec, ctx.Caster
	Combat.AddStatus(caster.Model, "Burrowed", spec.Duration, { Invulnerable = true, Invisible = true, Speed = 1.4 })
	task.delay(spec.Duration, function()
		local fresh = Combat.EntityFromModel(caster.Model)
		if not fresh then return end
		local from = fresh.Root.Position
		local p = ctx.Point or from
		local off = p - from
		if off.Magnitude > (spec.MaxRange or 80) then p = from + off.Unit * (spec.MaxRange or 80) end
		fresh.Model:PivotTo(CFrame.new(p + Vector3.new(0, 3, 0)) * fresh.Root.CFrame.Rotation)
		E.Aoe({ Caster = fresh, Spec = spec.Emerge, Dir = ctx.Dir })
	end)
	return true
end

-- ---------- Transform (Ditto) ----------
function E.Transform(ctx)
	local spec, caster = ctx.Spec, ctx.Caster
	local pool = {}
	for _, def in ipairs(PokemonData.List) do
		local kit = Kits.Get(def.Id)
		if def.Id ~= "DITTO" and def.Kind == "Active" and def.Rarity ~= "Mythical" and kit and kit.Moves then
			table.insert(pool, def.Id)
		end
	end
	local into = ctx.Data and ctx.Data.into
	local chosen = (type(into) == "string" and table.find(pool, into)) and into or pool[math.random(#pool)]

	local s = Combat.State(caster.Model)
	s.TransformInto = chosen
	local untilT = os.clock() + (spec.Duration or 6)
	s.TransformUntil = untilT
	caster.Model:SetAttribute("TransformedInto", chosen)
	Combat.AddStatus(caster.Model, "DittoForm", spec.Duration, spec.SelfMods)
	task.delay(spec.Duration or 6, function()
		if s.TransformUntil == untilT then
			s.TransformInto = nil
			if caster.Model.Parent then caster.Model:SetAttribute("TransformedInto", nil) end
		end
	end)
	return true
end

return E
