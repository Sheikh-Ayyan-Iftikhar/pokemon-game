-- ModuleScript
-- Location: ServerScriptService > Server > WildService
-- Wild Pokemon appear on every map (only while a player is there). Hold E near one to catch it.
-- Rarity decides how often a species appears and how long the catch takes. Mythical spawns are very rare by design.
local Players = game:GetService("Players")
local ServerStorage = game:GetService("ServerStorage")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local MapCfg = require(ReplicatedStorage.Shared.Config.MapConfig)
local PokemonData = require(ReplicatedStorage.Shared.Config.PokemonData)
local Rarity = require(ReplicatedStorage.Shared.Config.Rarity)
local Economy = require(ReplicatedStorage.Shared.Config.Economy)
local DataService = require(script.Parent.DataService)
local InventoryService = require(script.Parent.InventoryService)
local BaseService = require(script.Parent.BaseService)
local Combat = require(script.Parent.CombatService)
local MapService = require(script.Parent.MapService)
local Notify = require(script.Parent.Notify)

local Wild = {}

-- All tunable defaults (not from your docs).
local WEIGHTS = { Common = 70, Rare = 22, Epic = 8, Legendary = 2.5, Mythical = 0.6 }
local HOLD = { Common = 1.2, Rare = 2, Epic = 3, Legendary = 4, Mythical = 5 }
local LIFETIME = 75
local SPAWN_EVERY = 6
local MAX_PER_MAP = 8
local CATCH_RANGE = 16
local CATCH_COOLDOWN = 2

local active = {}      -- [mapId] = { [model] = true }
local lastCatch = {}   -- [Player] = os.clock()

local function count(set) local n = 0 for _ in pairs(set) do n += 1 end return n end

local function pickSpecies(map)
	local total = 0
	for _, id in ipairs(map.WildPool) do total += WEIGHTS[PokemonData.Get(id).Rarity] end
	local r = math.random() * total
	for _, id in ipairs(map.WildPool) do
		r -= WEIGHTS[PokemonData.Get(id).Rarity]
		if r <= 0 then return id end
	end
	return map.WildPool[1]
end

local function despawn(mapId, model)
	if active[mapId] then active[mapId][model] = nil end
	if model.Parent then model:Destroy() end
end

local function eligible(player)
	if not DataService.Get(player) then return false, "NoData" end
	if not Combat.EntityOf(player) then return false, "Dead" end
	if player:GetAttribute("InMatch") or player:GetAttribute("Carrying") or Combat.InRaid(player) then return false, "Busy" end
	return true
end

local function catch(player, mapId, model, id)
	if not model.Parent or model:GetAttribute("Claimed") then return end
	local ok, err = eligible(player)
	if not ok then return end
	local ent = Combat.EntityOf(player)
	if (ent.Root.Position - model:GetPivot().Position).Magnitude > CATCH_RANGE then return end
	if os.clock() < (lastCatch[player] or 0) + CATCH_COOLDOWN then return end
	local data = DataService.Get(player)
	local owned = 0
	for _ in pairs(data.Owned) do owned += 1 end
	if owned >= Economy.MaxOwned then
		Notify.Send(player, "Your collection is full.", "bad")
		return
	end
	model:SetAttribute("Claimed", true) -- first player to finish wins; nobody else can claim it
	lastCatch[player] = os.clock()
	local uid = InventoryService.Grant(player, id)
	if uid then
		BaseService.Station(player, uid) -- harmless if the base is full
		local def = PokemonData.Get(id)
		Notify.Send(player, ("You caught %s (%s)!"):format(def.Name, def.Rarity), "good")
	end
	despawn(mapId, model)
end

local function spawnOne(map)
	local template = ServerStorage:FindFirstChild("PokemonModels") and ServerStorage.PokemonModels:FindFirstChild(pickSpecies(map))
	if not template then return end
	local id = template.Name
	local def = PokemonData.Get(id)
	local zone = map.WildZones[math.random(#map.WildZones)]
	local a, r = math.random() * math.pi * 2, math.sqrt(math.random()) * zone.Radius
	local x, z = map.Origin.X + zone.Offset.X + math.cos(a) * r, map.Origin.Z + zone.Offset.Z + math.sin(a) * r
	local y = MapService.GroundAt(x, z, map.Origin.Y)

	local model = template:Clone()
	for _, d in ipairs(model:GetDescendants()) do
		if d:IsA("BasePart") then
			d.Anchored = true
			d.CanCollide = false
		end
	end
	local size = model:GetExtentsSize()
	model:PivotTo(CFrame.new(x, y + size.Y / 2 + 0.5, z) * CFrame.Angles(0, math.random() * math.pi * 2, 0))
	model.Name = "Wild_" .. id
	model.Parent = workspace

	local root = model.PrimaryPart or model:FindFirstChildWhichIsA("BasePart", true)
	local gui = Instance.new("BillboardGui")
	gui.Size = UDim2.new(0, 160, 0, 44)
	gui.StudsOffset = Vector3.new(0, size.Y / 2 + 3, 0)
	gui.AlwaysOnTop = true
	gui.Parent = root
	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 1
	label.TextScaled = true
	label.Font = Enum.Font.GothamBold
	label.TextColor3 = Rarity.Color[def.Rarity]
	label.TextStrokeTransparency = 0.3
	label.Text = ("%s [%s]"):format(def.Name, def.Rarity)
	label.Parent = gui

	local prompt = Instance.new("ProximityPrompt")
	prompt.ActionText = "Catch"
	prompt.ObjectText = def.Name
	prompt.HoldDuration = HOLD[def.Rarity]
	prompt.MaxActivationDistance = 12
	prompt.RequiresLineOfSight = false
	prompt.Parent = root
	prompt.Triggered:Connect(function(player) catch(player, map.Id, model, id) end)

	active[map.Id][model] = true
	task.delay(LIFETIME, function() despawn(map.Id, model) end)
end

function Wild.Start()
	for _, m in ipairs(MapCfg.List) do active[m.Id] = {} end
	task.spawn(function()
		while true do
			task.wait(SPAWN_EVERY)
			local present = {}
			for _, player in ipairs(Players:GetPlayers()) do
				local mid = player:GetAttribute("MapId")
				if mid then present[mid] = (present[mid] or 0) + 1 end
			end
			for _, m in ipairs(MapCfg.List) do
				local players = present[m.Id] or 0
				if players > 0 and count(active[m.Id]) < math.min(MAX_PER_MAP, 3 + players * 2) then
					local ok, err = pcall(spawnOne, m)
					if not ok then warn("[WildService] " .. tostring(err)) end
				end
			end
		end
	end)
end

function Wild.Clear(player)
	lastCatch[player] = nil
end

return Wild
