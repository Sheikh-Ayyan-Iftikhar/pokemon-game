-- LocalScript
-- Location: StarterPlayer > StarterPlayerScripts > AnimClient
-- Plays combat animations for EVERY character (yours, other players, dummies) when the server bumps an attribute.
-- Put your animation ids in Shared/Config/Animations. Empty ids are simply skipped.
local Players = game:GetService("Players")
local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Anim = require(ReplicatedStorage.Shared.Config.Animations)

local function hook(model)
	local hum = model:WaitForChild("Humanoid", 10)
	if not hum then return end
	local animator = hum:FindFirstChildOfClass("Animator") or hum:WaitForChild("Animator", 5)
	if not animator then return end
	local cache = {}
	local function track(id)
		if type(id) ~= "string" or id == "" then return nil end
		if not cache[id] then
			local a = Instance.new("Animation")
			a.AnimationId = id
			cache[id] = animator:LoadAnimation(a)
		end
		return cache[id]
	end
	local function play(id)
		local t = track(id)
		if t then t:Play() end
	end
	model:GetAttributeChangedSignal("AttackTick"):Connect(function() play(Anim.Attack[model:GetAttribute("Combo") or 1]) end)
	model:GetAttributeChangedSignal("HitTick"):Connect(function() play(Anim.HitReact) end)
	model:GetAttributeChangedSignal("DashTick"):Connect(function() play(Anim.Dash) end)
	model:GetAttributeChangedSignal("Blocking"):Connect(function()
		local t = track(Anim.Block)
		if not t then return end
		if model:GetAttribute("Blocking") then
			t.Looped = true
			t:Play()
		else
			t:Stop()
		end
	end)
end

local function onPlayer(p)
	if p.Character then task.spawn(hook, p.Character) end
	p.CharacterAdded:Connect(function(c) task.spawn(hook, c) end)
end
for _, p in ipairs(Players:GetPlayers()) do onPlayer(p) end
Players.PlayerAdded:Connect(onPlayer)

for _, m in ipairs(CollectionService:GetTagged("CombatDummy")) do task.spawn(hook, m) end
CollectionService:GetInstanceAddedSignal("CombatDummy"):Connect(function(m) task.spawn(hook, m) end)
