-- ModuleScript
-- Location: ReplicatedStorage > Shared > Config > PokemonData
-- Source: Pokemon_Inherited_Powers_Updated.docx (30 entries).
-- Kind = "Active" -> can only go in the Active slot. Kind = "Passive" -> only in Passive slots.
-- Summary is a short description for UI. Real move logic comes in Phase 2 (ability framework).
local function P(id, name, rarity, kind, style, summary)
	return { Id = id, Name = name, Rarity = rarity, Kind = kind, Style = style, Summary = summary }
end

local list = {
	-- MYTHICAL
	P("ARCEUS", "Arceus", "Mythical", "Active", "Adaptive creator",
		"Uses Dialga/Palkia/Giratina moves (pick 4 before match). Below 50% HP: universe explosion, immune to basic attacks, summons clones."),
	P("RAYQUAZA", "Rayquaza", "Mythical", "Active", "Sky and weather lord",
		"Meteors, storm, sends opponent to space. Below 50% HP: rides a meteor, debris slam, space throw."),
	P("MEWTWO", "Mewtwo", "Mythical", "Active", "Engineered psychic mind",
		"Armor absorbs 50% for 10s, self explosions for 8s, robotic tentacle crush. Below 50% HP: glitch vision, robot flight, hand laser."),
	P("KYOGRE", "Kyogre", "Mythical", "Active", "Ocean and storm",
		"Underwater realm 10s (+30% stats), map flood 5s, water chain slam. Below 50% HP: trident, shark tank trap."),
	P("GROUDON", "Groudon", "Mythical", "Passive", "Land and heat",
		"+40% health and stamina (only one), -60% damage from all attacks except dimensional."),
	-- LEGENDARY
	P("DIALGA", "Dialga", "Legendary", "Active", "Time",
		"Rewind time 4s, slow opponent and environment 5s, rewind own health and stamina 3s."),
	P("GIRATINA", "Giratina", "Legendary", "Active", "Antimatter and dimensions",
		"Purple rifts (4s damage), antimatter explosion, blind opponent 6s."),
	P("LUGIA", "Lugia", "Legendary", "Active", "Storm guardian",
		"Tornados 7s, wind waves, carries opponent into the sky for 4s of hits."),
	P("PALKIA", "Palkia", "Legendary", "Active", "Space",
		"Limited teleport, portal lasers 4s, dimension throw 5s, shared dimension 12s with reduced opponent attacks."),
	P("GARCHOMP", "Garchomp", "Legendary", "Active", "Supersonic predator",
		"Fast flight (no attacks), sensor waves, blade throw 7s. Below 40% HP: reflects 40% damage, can attack while flying."),
	-- EPIC
	P("DRAGONITE", "Dragonite", "Epic", "Passive", "Gentle giant rescuer",
		"Regenerates health for 10s once HP drops below 30%."),
	P("DEOXYS", "Deoxys", "Epic", "Passive", "Mutable alien",
		"+30% attack, defense or speed (one at a time) in repeating cycles."),
	P("MEW", "Mew", "Epic", "Passive", "Everything-learner",
		"Gains the active ability of a random Pokemon, twice per match."),
	P("CHARIZARD", "Charizard", "Epic", "Active", "Honorable fire warrior",
		"Fire breath 6s, burn opponent 4s. Below 20% HP: melts basic and melee attacks."),
	P("GYARADOS", "Gyarados", "Epic", "Active", "Berserker",
		"Earthquake opens the ground, tsunami covers the ground, burrow and pop out anywhere."),
	P("LUCARIO", "Lucario", "Epic", "Active", "Aura sage",
		"Aura -50% damage 6s, dark energy melee 5s, huge dark energy ball slam."),
	-- RARE
	P("GARDEVOIR", "Gardevoir", "Rare", "Passive", "Psychic protector",
		"Shows opponent move cooldowns when HP below 40%."),
	P("GRENINJA", "Greninja", "Rare", "Active", "Shadow ninja",
		"Water shurikens, water kunai dash attack."),
	P("ALAKAZAM", "Alakazam", "Rare", "Passive", "Genius mind",
		"+40% dodge chance when HP below 20%."),
	P("GENGAR", "Gengar", "Rare", "Passive", "Shadow trickster",
		"On night maps: turns invisible for 4s every 15s."),
	P("SNORLAX", "Snorlax", "Rare", "Passive", "Endurance tank",
		"Below 15% HP: opponent attacks reduced by 50%."),
	P("MIMIKYU", "Mimikyu", "Rare", "Active", "Costume ghost",
		"Dodge every opponent move 5s, invisibility 5s with -50% damage."),
	-- COMMON
	P("SYLVEON", "Sylveon", "Common", "Passive", "Peacemaker",
		"Opponent basic attacks -20%."),
	P("UMBREON", "Umbreon", "Common", "Passive", "Moon defender",
		"All abilities +5% on night maps."),
	P("PIKACHU", "Pikachu", "Common", "Active", "Electric speedster",
		"Dash and basic attacks +30%, lightning strike, attack speed +40% for 4s."),
	P("EEVEE", "Eevee", "Common", "Passive", "Adaptable",
		"Dash +15%."),
	P("SQUIRTLE", "Squirtle", "Common", "Active", "Shell defender",
		"Basic melee attack, earth-like shield."),
	P("BULBASAUR", "Bulbasaur", "Common", "Passive", "Sun-fed growth",
		"On daytime maps: +5% to every stat."),
	P("CHARMANDER", "Charmander", "Common", "Passive", "Life-flame",
		"+15% damage when HP below 50%."),
	P("DITTO", "Ditto", "Common", "Active", "Copycat",
		"Transforms into any Common-to-Legendary Pokemon for 6s with -40% damage, plus other basic moves."),
}

local Data = { List = list, ById = {} }
for i, p in ipairs(list) do
	assert(not Data.ById[p.Id], "Duplicate Pokemon id: " .. p.Id)
	p.Index = i
	Data.ById[p.Id] = p
end

function Data.Get(id)
	return Data.ById[id]
end

return Data
