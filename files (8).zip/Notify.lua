-- ModuleScript
-- Location: ServerScriptService > Server > Notify
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Remotes = require(ReplicatedStorage.Shared.Remotes)

local Notify = {}
function Notify.Send(player, text, kind)
	if player and player.Parent then
		Remotes.Get("Notify"):FireClient(player, { text = text, kind = kind or "info" })
	end
end
return Notify
