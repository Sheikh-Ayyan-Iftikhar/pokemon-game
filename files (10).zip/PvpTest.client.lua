-- LocalScript
-- Location: StarterPlayer > StarterPlayerScripts > PvpTest
-- Studio test keys (Test tab > Players: 2). Delete when you build the real PvP UI.
--   K = join ranked queue    L = leave queue
--   J = challenge the other player to a WAGER (risks your first stationed Pokemon)
--   H = accept a wager challenge (offers your first stationed Pokemon)
--   G = confirm a wager after the opponent picked    N = decline
local Players = game:GetService("Players")
local UserInputService = game:GetService("UserInputService")
local Api = require(script.Parent:WaitForChild("Api"))
Api.Start()
local player = Players.LocalPlayer

local function firstStationed()
	return Api.State and Api.State.Stationed[1]
end

UserInputService.InputBegan:Connect(function(input, processed)
	if processed then return end
	local k = input.KeyCode
	if k == Enum.KeyCode.K then
		print("QueueRanked", Api.Request("QueueRanked"))
	elseif k == Enum.KeyCode.L then
		print("LeaveQueue", Api.Request("LeaveQueue"))
	elseif k == Enum.KeyCode.J then
		local other
		for _, p in ipairs(Players:GetPlayers()) do
			if p ~= player then other = p break end
		end
		local uid = firstStationed()
		if other and uid then print("WagerInvite", Api.Request("WagerInvite", { userId = other.UserId, uid = uid })) end
	elseif k == Enum.KeyCode.H then
		local id, uid = player:GetAttribute("WagerInvite"), firstStationed()
		if id and uid then print("WagerAccept", Api.Request("WagerAccept", { inviteId = id, uid = uid })) end
	elseif k == Enum.KeyCode.G then
		local id = player:GetAttribute("WagerConfirm")
		if id then print("WagerConfirm", Api.Request("WagerConfirm", { inviteId = id })) end
	elseif k == Enum.KeyCode.N then
		local id = player:GetAttribute("WagerInvite") or player:GetAttribute("WagerConfirm")
		if id then print("WagerDecline", Api.Request("WagerDecline", { inviteId = id })) end
	end
end)
