-- ModuleScript
-- Location: ReplicatedStorage > Shared > Config > Moves
-- 50 moves, all DATA. Behaviour comes from the executor named in `Exec` (see Server/Executors.lua).
-- What the docs define: move concept + durations/percentages. What I filled in (tunable): Cooldown, Cost, Damage, Range, Radius, Speed.
-- Optional per move: Sfx = "rbxassetid://..." (sound). Animations/VFX are plain neon parts until you add your own.
local C = Color3.fromRGB
local function eff(status, duration, mods, extra)
	local e = { Status = status, Duration = duration, Mods = mods or {} }
	if extra then for k, v in pairs(extra) do e[k] = v end end
	return e
end
local SLOW = function(m, d) return eff("Slow", d, { Speed = m }) end

local M = {
	-- ============ DIALGA ============
	DIALGA_REWIND = { Name = "Rewind Time", Exec = "Rewind", Seconds = 4, Position = true, Health = true, Stamina = true, Cooldown = 45, Cost = 30,
		Desc = "Rewind yourself 4 seconds: position, health and stamina." },
	DIALGA_TIMEFIELD = { Name = "Time Slow", Exec = "Aoe", Center = "Self", Radius = 50, Damage = 0, Cooldown = 30, Color = C(120, 140, 255),
		Effects = { eff("TimeSlow", 5, { Speed = 0.4, AttackSpeed = 0.4, ProjectileSpeed = 0.4 }) },
		Desc = "Slows enemies and their projectiles for 5 seconds. You are unaffected." },
	DIALGA_RESTORE = { Name = "Restore", Exec = "Rewind", Seconds = 3, Health = true, Stamina = true, Cooldown = 35,
		Desc = "Rewind your health and stamina by 3 seconds." },
	-- ============ GIRATINA ============
	GIRATINA_RIFTS = { Name = "Distortion Rifts", Exec = "Aoe", Center = "Aim", Range = 50, Radius = 9, Ticks = 8, TickEvery = 0.5, Damage = 6, Pull = 25,
		Cooldown = 20, Color = C(120, 40, 160), Effects = { eff("Slow", 0.8, { Speed = 0.3 }) },
		Desc = "Purple rifts hold enemies for 4 seconds, dealing damage." },
	GIRATINA_ANTIMATTER = { Name = "Antimatter Collision", Exec = "Aoe", Center = "Aim", Range = 60, Radius = 15, Delay = 1, Damage = 50, Cooldown = 28, Cost = 30,
		Color = C(200, 60, 255), Desc = "Huge delayed explosion." },
	GIRATINA_BLIND = { Name = "Shadow Veil", Exec = "Aoe", Center = "Self", Radius = 45, Damage = 0, Cooldown = 26, Color = C(30, 0, 40),
		Effects = { eff("Blind", 6, { Blind = true }) }, Desc = "Blinds enemies for 6 seconds." },
	-- ============ PALKIA ============
	PALKIA_WARP = { Name = "Space Warp", Exec = "Teleport", MaxRange = 60, Cooldown = 8, Desc = "Limited-range teleport." },
	PALKIA_PORTALS = { Name = "Portal Lasers", Exec = "Projectile", Repeat = 8, Interval = 0.5, Origin = "Scatter", OriginRadius = 12, Damage = 9, Speed = 200,
		Range = 120, Radius = 2, Cooldown = 22, Color = C(255, 120, 220), Desc = "Portals fire lasers at the enemy for 4 seconds." },
	PALKIA_DIMTHROW = { Name = "Dimension Throw", Exec = "Carry", Range = 35, Height = 25, Duration = 5, TickEvery = 1, TickDamage = 10, Hops = true, HopRadius = 40,
		Cooldown = 30, Cost = 30, Desc = "Throws the enemy from dimension to dimension for 5 seconds." },
	PALKIA_REALM = { Name = "Palkia's Realm", Exec = "Realm", Range = 40, Duration = 12, Color = C(255, 150, 230), Cooldown = 45, Cost = 30,
		Effects = { eff("RealmWeaken", 12, { DamageDealt = 0.5 }) },
		Desc = "Pull yourself and an enemy into a dimension for 12 seconds. Their attacks deal 50% less." },
	-- ============ LUGIA ============
	LUGIA_TORNADOS = { Name = "Tornados", Exec = "Aoe", Center = "Front", Offset = 22, Radius = 11, Ticks = 14, TickEvery = 0.5, Damage = 4, Lift = 18, Pull = 12,
		Cooldown = 24, Color = C(200, 230, 255), Desc = "Tornados for 7 seconds." },
	LUGIA_WINDWAVE = { Name = "Wind Waves", Exec = "Projectile", Count = 3, Spread = 14, Damage = 18, Speed = 90, Range = 90, Radius = 4, Pierce = true,
		Cooldown = 10, Color = C(220, 240, 255), Desc = "Three huge waves of wind." },
	LUGIA_SKYCARRY = { Name = "Sky Carry", Exec = "Carry", Range = 30, Height = 50, Duration = 4, CarryCaster = true, TickEvery = 1, TickDamage = 8, DropDamage = 15,
		Cooldown = 28, Cost = 30, Desc = "Carry the enemy into the sky, hitting them for 4 seconds." },
	-- ============ GARCHOMP ============
	GARCHOMP_FLY = { Name = "Supersonic Flight", Exec = "Flight", Duration = 8, Speed = 90, Cooldown = 20, Desc = "Very fast flight. Cannot attack while flying." },
	GARCHOMP_SENSORWAVE = { Name = "Sensor Wave", Exec = "Aoe", Center = "Self", Radius = 30, Delay = 0.3, Damage = 25, Cooldown = 12, Color = C(255, 140, 60),
		Desc = "Damaging waves from his head sensors." },
	GARCHOMP_BLADES = { Name = "Wind Blades", Exec = "Compound", AllowWhileFlying = true, Cooldown = 26, Cost = 30,
		Steps = {
			{ Exec = "Flight", Duration = 7, Speed = 70 },
			{ Exec = "Projectile", Repeat = 14, Interval = 0.5, Count = 3, Spread = 20, Damage = 5, Speed = 120, Range = 70, Radius = 2, Color = C(180, 255, 180) },
		}, Desc = "Throws blades while flying for 7 seconds." },
	-- ============ RAYQUAZA ============
	RAYQUAZA_METEORS = { Name = "Meteor Rain", Exec = "Aoe", Center = "Aim", Range = 60, Scatter = true, Count = 6, ScatterRadius = 14, Radius = 6, Delay = 0.8, Damage = 28,
		Cooldown = 16, Cost = 30, Color = C(255, 120, 40), Desc = "Large meteoroids fall from the sky." },
	RAYQUAZA_STORM = { Name = "Storm", Exec = "Aoe", Center = "Front", Offset = 20, Radius = 18, Ticks = 8, TickEvery = 0.5, Damage = 6, Cooldown = 18, Color = C(90, 200, 120),
		Effects = { SLOW(0.7, 0.6) }, Desc = "A storm rolls toward the opponent." },
	RAYQUAZA_SPACE = { Name = "Earth Break", Exec = "Carry", Range = 30, Height = 80, Duration = 3, DropDamage = 25, Cooldown = 28, Cost = 30,
		Desc = "Break the ground and send the enemy into space." },
	RAYQUAZA_METEORFLIGHT = { Name = "Meteor Ride", Exec = "Flight", Duration = 10, Speed = 80, Cooldown = 22, Desc = "Fly on a meteoroid." },
	RAYQUAZA_DEBRIS = { Name = "Debris Slam", Exec = "Aoe", Center = "Self", Radius = 30, Delay = 0.6, Damage = 40, Lift = 20, Cooldown = 22, Color = C(150, 120, 90),
		Desc = "All nearby material slams into the opponents." },
	RAYQUAZA_SPACETHROW = { Name = "Orbital Throw", Exec = "Carry", Range = 35, Height = 200, Duration = 5, DropDamage = 45, DropSpeed = 140, Cooldown = 32, Cost = 30,
		Desc = "Send the enemy into space and throw them back to Earth." },
	-- ============ MEWTWO ============
	MEWTWO_ARMOR = { Name = "Psychic Armor", Exec = "Self", Cooldown = 30, SelfEffects = { eff("PsychicArmor", 10, { DamageTaken = 0.5 }) },
		Desc = "Armor absorbs 50% of enemy attacks for 10 seconds." },
	MEWTWO_BLASTS = { Name = "Psychic Blasts", Exec = "Aoe", Center = "Self", Follow = true, Radius = 12, Ticks = 16, TickEvery = 0.5, Damage = 5, Cooldown = 28,
		Color = C(190, 120, 255), Desc = "Explosions around you for 8 seconds, no aiming needed." },
	MEWTWO_TENTACLE = { Name = "Robotic Tentacle", Exec = "Aoe", Center = "Target", Range = 45, Radius = 7, Delay = 0.6, Damage = 45, Cooldown = 14, Color = C(160, 160, 200),
		Desc = "Crush an enemy with a large robotic tentacle." },
	MEWTWO_FLIGHT = { Name = "Robot Flight", Exec = "Flight", Duration = 10, Speed = 70, Cooldown = 20, Desc = "Fly like a robot." },
	MEWTWO_LASER = { Name = "Hand Laser", Exec = "Projectile", Damage = 38, Speed = 300, Range = 130, Radius = 2.5, Pierce = true, Cooldown = 10, Color = C(255, 80, 200),
		Desc = "Fire a laser from the hand." },
	-- ============ KYOGRE ============
	KYOGRE_DEPTHS = { Name = "Abyssal Realm", Exec = "Realm", Range = 40, Duration = 10, Color = C(30, 90, 200), Cooldown = 40, Cost = 30,
		CasterEffects = { eff("Deepsea", 10, { DamageDealt = 1.3, DamageTaken = 0.77, Speed = 1.3, Dash = 1.3, AttackSpeed = 1.3 }) },
		Desc = "Teleport you and the enemy underwater for 10 seconds. Your stats get +30%." },
	KYOGRE_FLOOD = { Name = "Great Flood", Exec = "Aoe", Center = "Self", Radius = 60, Ticks = 5, TickEvery = 1, Damage = 8, Cooldown = 30, Cost = 30, Color = C(40, 120, 230),
		Effects = { SLOW(0.6, 1.2) }, Desc = "A tornado from underground floods the map for 5 seconds." },
	KYOGRE_CHAIN = { Name = "Water Chain", Exec = "Carry", Range = 35, Height = 10, Duration = 4, TickEvery = 0.8, TickDamage = 12, Slam = true, Cooldown = 20,
		Desc = "Grab the enemy with a water chain and slam them repeatedly." },
	KYOGRE_TRIDENT = { Name = "Trident Strike", Exec = "Projectile", Damage = 55, Speed = 140, Range = 100, Radius = 3.5, Pierce = true, Cooldown = 12, Cost = 20, Color = C(80, 180, 255),
		Desc = "Powerful trident throw." },
	KYOGRE_SHARKTANK = { Name = "Shark Tank", Exec = "Carry", Range = 30, Height = 0, Duration = 5, TickEvery = 1, TickDamage = 10, Cage = true, Cooldown = 30, Cost = 30,
		Color = C(60, 140, 220), Desc = "Trap the enemy in a water tank with a shark." },
	-- ============ CHARIZARD ============
	CHARIZARD_FLAMETHROWER = { Name = "Flamethrower", Exec = "Aoe", Center = "Front", Offset = 14, Follow = true, Radius = 12, Ticks = 12, TickEvery = 0.5, Damage = 7,
		Cooldown = 18, Color = C(255, 120, 30), Desc = "Fire from the mouth for 6 seconds." },
	CHARIZARD_IGNITE = { Name = "Ignite", Exec = "Aoe", Center = "Aim", Range = 50, Radius = 10, Damage = 5, Cooldown = 14, Color = C(255, 80, 20),
		Effects = { eff("Burn", 4, {}, { Dot = { Damage = 5, Every = 1 } }) }, Desc = "Burns the opponent for 4 seconds." },
	-- ============ GYARADOS ============
	GYARADOS_QUAKE = { Name = "Earthquake", Exec = "Aoe", Center = "Front", Offset = 20, Radius = 16, Delay = 0.5, Damage = 35, Lift = 25, Cooldown = 16, Color = C(140, 100, 60),
		Desc = "The ground opens toward the opponent's area." },
	GYARADOS_TSUNAMI = { Name = "Tsunami", Exec = "Aoe", Center = "Self", Radius = 45, Ticks = 3, TickEvery = 1, Damage = 12, Cooldown = 28, Cost = 30, Color = C(40, 130, 220),
		Desc = "A tsunami erupts from the land and covers the ground." },
	GYARADOS_BURROW = { Name = "Burrow & Swim", Exec = "Burrow", Duration = 3, MaxRange = 80, Cooldown = 25,
		Emerge = { Exec = "Aoe", Center = "Self", Radius = 8, Damage = 25, Color = C(60, 150, 230) },
		Desc = "Go underground and pop out anywhere you aim." },
	-- ============ LUCARIO ============
	LUCARIO_AURA = { Name = "Aura Guard", Exec = "Self", Cooldown = 20, SelfEffects = { eff("AuraGuard", 6, { DamageTaken = 0.5 }) }, Desc = "-50% damage taken for 6 seconds." },
	LUCARIO_BARRAGE = { Name = "Dark Barrage", Exec = "Aoe", Center = "Self", Follow = true, Radius = 10, Ticks = 10, TickEvery = 0.5, Damage = 8, Melee = true, Cooldown = 18,
		Color = C(80, 40, 120), Desc = "Multiple dark-energy melee attacks for 5 seconds." },
	LUCARIO_DARKBALL = { Name = "Dark Energy Ball", Exec = "Aoe", Center = "Aim", Range = 50, Radius = 14, Delay = 1.2, Damage = 55, Cooldown = 26, Cost = 30, Color = C(60, 20, 100),
		Desc = "A huge dark energy ball slammed into the ground." },
	-- ============ GRENINJA ============
	GRENINJA_SHURIKEN = { Name = "Water Shuriken", Exec = "Projectile", Count = 3, Spread = 8, Damage = 12, Speed = 130, Range = 90, Radius = 1.5, Cooldown = 6, Color = C(80, 170, 255),
		Desc = "Throw water shurikens." },
	GRENINJA_KUNAI = { Name = "Kunai Dash", Exec = "Dash", Distance = 35, Time = 0.25, Damage = 28, Radius = 5, Cooldown = 10, Desc = "Dash attack with a water kunai." },
	-- ============ MIMIKYU ============
	MIMIKYU_DODGE = { Name = "Phantom Dodge", Exec = "Self", Cooldown = 25, SelfEffects = { eff("PhantomDodge", 5, { Dodge = 1 }) }, Desc = "Dodge every opponent move for 5 seconds." },
	MIMIKYU_VANISH = { Name = "Vanish", Exec = "Self", Cooldown = 22, SelfEffects = { eff("Vanish", 5, { Invisible = true, DamageDealt = 0.5 }) },
		Desc = "Invisible for 5 seconds, but your damage is halved." },
	-- ============ PIKACHU ============
	PIKACHU_THUNDERBOLT = { Name = "Thunderbolt", Exec = "Aoe", Center = "Target", Range = 60, Radius = 5, Delay = 0.4, Damage = 38, Cooldown = 12, Color = C(255, 240, 80),
		Desc = "Strike the opponent with lightning." },
	PIKACHU_RUSH = { Name = "Quick Charge", Exec = "Self", Cooldown = 20, SelfEffects = { eff("QuickCharge", 4, { AttackSpeed = 1.4 }) }, Desc = "+40% attack speed for 4 seconds." },
	-- ============ SQUIRTLE / DITTO ============
	SQUIRTLE_SHELL = { Name = "Earth Shield", Exec = "Self", Cooldown = 18, SelfEffects = { eff("EarthShield", 5, {}, { Shield = 35 }) }, Desc = "Form an earth-like shield." },
	DITTO_TRANSFORM = { Name = "Transform", Exec = "Transform", Duration = 6, Cooldown = 40, Cost = 30, SelfMods = { DamageDealt = 0.6 },
		Desc = "Become any Common-to-Legendary Pokemon for 6 seconds with 40% less damage." },
	-- ============ ARCEUS (transformed) ============
	ARCEUS_UNIVERSE = { Name = "Universe Collapse", Exec = "Aoe", Center = "Self", Radius = 90, Delay = 2, Damage = 80, Cooldown = 50, Cost = 30, Color = C(255, 255, 255),
		Desc = "Cause the universe to explode." },
	ARCEUS_CLONES = { Name = "Multiverse Clones", Exec = "Aoe", Center = "Target", Range = 60, Scatter = true, Count = 5, ScatterRadius = 10, Radius = 5, Clones = true, Delay = 0.5,
		Ticks = 3, TickEvery = 0.6, Damage = 20, Cooldown = 30, Cost = 30, Color = C(255, 230, 150), Desc = "Teleport clones of yourself from multiple universes." },
}

local count = 0
for id, m in pairs(M) do
	m.Id = id
	m.Cooldown = m.Cooldown or 10
	count += 1
end
M._Count = count
return M
