-- ModuleScript
-- Location: StarterPlayer > StarterPlayerScripts > UI
-- Small widget helpers + theme used by UIController.
local UI = {}

UI.C = {
	bg = Color3.fromRGB(16, 18, 30),
	panel = Color3.fromRGB(26, 29, 46),
	panel2 = Color3.fromRGB(37, 41, 64),
	accent = Color3.fromRGB(88, 140, 255),
	good = Color3.fromRGB(70, 190, 110),
	bad = Color3.fromRGB(220, 80, 80),
	warn = Color3.fromRGB(240, 180, 60),
	text = Color3.fromRGB(240, 242, 250),
	sub = Color3.fromRGB(150, 156, 180),
	off = Color3.fromRGB(70, 74, 98),
}
UI.Font = Enum.Font.GothamMedium
UI.FontBold = Enum.Font.GothamBold

function UI.make(class, props, parent)
	local o = Instance.new(class)
	for k, v in pairs(props or {}) do o[k] = v end
	if parent then o.Parent = parent end
	return o
end

function UI.round(o, r)
	UI.make("UICorner", { CornerRadius = UDim.new(0, r or 8) }, o)
end

function UI.stroke(o, color, thickness)
	UI.make("UIStroke", { Color = color or UI.C.panel2, Thickness = thickness or 1, ApplyStrokeMode = Enum.ApplyStrokeMode.Border }, o)
end

function UI.label(parent, text, size, color, props)
	local l = UI.make("TextLabel", {
		BackgroundTransparency = 1, Text = text, TextSize = size or 16, TextColor3 = color or UI.C.text, Font = UI.Font,
		TextXAlignment = Enum.TextXAlignment.Left, TextYAlignment = Enum.TextYAlignment.Top, TextWrapped = true,
		Size = UDim2.new(1, 0, 0, (size or 16) + 6),
	}, parent)
	for k, v in pairs(props or {}) do l[k] = v end
	return l
end

-- onClick runs in its own thread; a click is ignored while the previous one is still running.
function UI.button(parent, text, onClick, props)
	local b = UI.make("TextButton", {
		Text = text, TextSize = 15, Font = UI.FontBold, TextColor3 = UI.C.text, BackgroundColor3 = UI.C.accent,
		AutoButtonColor = true, Size = UDim2.new(0, 120, 0, 34),
	}, parent)
	UI.round(b, 8)
	for k, v in pairs(props or {}) do b[k] = v end
	local busy = false
	b.Activated:Connect(function()
		if busy then return end
		busy = true
		task.spawn(function()
			local ok, err = pcall(onClick, b)
			if not ok then warn("[UI] button error: " .. tostring(err)) end
			task.wait(0.15)
			busy = false
		end)
	end)
	return b
end

-- Scrolling list (default) or grid.
function UI.scroll(parent, props, grid)
	local s = UI.make("ScrollingFrame", {
		BackgroundTransparency = 1, BorderSizePixel = 0, ScrollBarThickness = 5, ScrollBarImageColor3 = UI.C.sub,
		CanvasSize = UDim2.new(), AutomaticCanvasSize = Enum.AutomaticSize.Y, Size = UDim2.new(1, 0, 1, 0),
	}, parent)
	for k, v in pairs(props or {}) do s[k] = v end
	if grid then
		UI.make("UIGridLayout", { CellSize = grid, CellPadding = UDim2.new(0, 6, 0, 6), SortOrder = Enum.SortOrder.LayoutOrder }, s)
	else
		UI.make("UIListLayout", { Padding = UDim.new(0, 6), SortOrder = Enum.SortOrder.LayoutOrder }, s)
	end
	return s
end

function UI.clear(container)
	for _, c in ipairs(container:GetChildren()) do
		if not (c:IsA("UIListLayout") or c:IsA("UIGridLayout") or c:IsA("UIPadding") or c:IsA("UICorner") or c:IsA("UIStroke") or c:IsA("UIScale")) then
			c:Destroy()
		end
	end
end

function UI.card(parent, props)
	local f = UI.make("Frame", { BackgroundColor3 = UI.C.panel2, Size = UDim2.new(1, 0, 0, 40) }, parent)
	UI.round(f, 8)
	for k, v in pairs(props or {}) do f[k] = v end
	return f
end

function UI.bar(parent, color, props)
	local back = UI.make("Frame", { BackgroundColor3 = UI.C.off, Size = UDim2.new(1, 0, 0, 14) }, parent)
	UI.round(back, 7)
	for k, v in pairs(props or {}) do back[k] = v end
	local fill = UI.make("Frame", { BackgroundColor3 = color, Size = UDim2.new(1, 0, 1, 0), BorderSizePixel = 0 }, back)
	UI.round(fill, 7)
	return back, fill
end

return UI
