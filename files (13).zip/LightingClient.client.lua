-- LocalScript
-- Location: StarterPlayer > StarterPlayerScripts > LightingClient
-- Applies the lighting/atmosphere of the map you are on (changes only YOUR screen, so every player sees their own map correctly).
local Players = game:GetService("Players")
local Lighting = game:GetService("Lighting")
local TweenService = game:GetService("TweenService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local MapCfg = require(ReplicatedStorage.Shared.Config.MapConfig)
local Api = require(script.Parent:WaitForChild("Api"))
local player = Players.LocalPlayer
Api.Start()

local function effect(class, name)
	local e = Lighting:FindFirstChild(name)
	if not e then
		e = Instance.new(class)
		e.Name = name
		e.Parent = Lighting
	end
	return e
end

local function effectsEnabled()
	local s = Api.State and Api.State.Settings
	return not s or s.LightingEffects ~= false
end

local currentMap
local function apply(map)
	if not map then return end
	currentMap = map
	local L = map.Lighting
	local info = TweenInfo.new(2, Enum.EasingStyle.Sine)
	TweenService:Create(Lighting, info, { Brightness = L.Brightness, Ambient = L.Ambient, OutdoorAmbient = L.OutdoorAmbient, ClockTime = L.ClockTime }):Play()

	local atm = effect("Atmosphere", "MapAtmosphere")
	TweenService:Create(atm, info, {
		Density = L.Atmosphere.Density, Offset = L.Atmosphere.Offset, Color = L.Atmosphere.Color,
		Decay = L.Atmosphere.Decay, Glare = L.Atmosphere.Glare, Haze = L.Atmosphere.Haze,
	}):Play()

	local cc = effect("ColorCorrectionEffect", "MapColor")
	cc.Enabled = effectsEnabled()
	TweenService:Create(cc, info, { Brightness = L.Color.Brightness, Contrast = L.Color.Contrast, Saturation = L.Color.Saturation, TintColor = L.Color.Tint }):Play()

	local bloom = effect("BloomEffect", "MapBloom")
	bloom.Enabled = effectsEnabled()
	bloom.Intensity, bloom.Size, bloom.Threshold = L.Bloom.Intensity, L.Bloom.Size, L.Bloom.Threshold

	local sky = Lighting:FindFirstChildOfClass("Sky") or Instance.new("Sky")
	sky.Parent = Lighting
	sky.StarCount = L.Stars
	sky.CelestialBodiesShown = L.Stars == 0
end

local function refreshFromAttr()
	apply(MapCfg.ById[player:GetAttribute("MapId") or "celestial"])
end

player:GetAttributeChangedSignal("MapId"):Connect(refreshFromAttr)
Api.Changed:Connect(function()
	if currentMap then
		effect("ColorCorrectionEffect", "MapColor").Enabled = effectsEnabled()
		effect("BloomEffect", "MapBloom").Enabled = effectsEnabled()
	end
end)
refreshFromAttr()
