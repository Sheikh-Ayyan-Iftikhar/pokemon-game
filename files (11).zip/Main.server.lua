-- Script (NOT a ModuleScript)  (REPLACES the Phase 4 version)
-- Location: ServerScriptService > Server > Main
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Remotes = require(ReplicatedStorage.Shared.Remotes)
local Economy = require(ReplicatedStorage.Shared.Config.Economy)

local Server = script.Parent
local DataService = require(Server.DataService)
local RateLimiter = require(Server.RateLimiter)
local Router = require(Server.Router)
local SyncService = require(Server.SyncService)
local InventoryService = require(Server.InventoryService)
local BaseService = require(Server.BaseService)
local LoadoutService = require(Server.LoadoutService)
local CombatService = require(Server.CombatService)
local PassiveService = require(Server.PassiveService)
local AbilityService = require(Server.AbilityService)
local BasicCombat = require(Server.BasicCombat)
local BaseWorld = require(Server.BaseWorld)
local StealService = require(Server.StealService)
local MatchService = require(Server.MatchService)
local RebirthService = require(Server.RebirthService)
local DebugService = require(Server.DebugService)

Remotes.Init()
BaseWorld.Init()

SyncService.Init(Router)
InventoryService.Init(Router)
BaseService.Init(Router)
LoadoutService.Init(Router)
AbilityService.Init(Router)
BasicCombat.Init(Router)
StealService.Init(Router)
MatchService.Init(Router)
RebirthService.Init(Router)
DebugService.Init(Router) -- registers only in Studio

Router.Start()
DataService.Start()
BaseService.Start()
CombatService.Start()
PassiveService.Start()
BaseWorld.Start()
MatchService.Start()

local function onPlayerAdded(player)
	local data, err = DataService.Load(player)
	if not data then
		if err ~= "Left" and player.Parent then
			player:Kick("Could not load your data (" .. tostring(err) .. "). Please rejoin.")
		end
		return
	end
	if not player.Parent then
		DataService.Release(player)
		return
	end

	if not data.StarterGiven then
		data.StarterGiven = true
		for _, id in ipairs(Economy.StarterPokemonIds) do
			local uid = InventoryService.Grant(player, id)
			if uid then BaseService.Station(player, uid) end
		end
	end

	BaseService.ApplyOffline(player)
	BaseWorld.Assign(player)
	SyncService.Push(player)
end

Players.PlayerAdded:Connect(onPlayerAdded)
for _, player in ipairs(Players:GetPlayers()) do
	task.spawn(onPlayerAdded, player)
end

Players.PlayerRemoving:Connect(function(player)
	StealService.OnLeaving(player) -- first, synchronously: nobody may touch this player's data while it is being saved
	MatchService.OnLeaving(player) -- also synchronous: settles/cancels matches BEFORE the data is released
	RateLimiter.Clear(player)
	PassiveService.Clear(player)
	BasicCombat.Clear(player)
	BaseWorld.Release(player)
	DataService.Release(player)
end)
