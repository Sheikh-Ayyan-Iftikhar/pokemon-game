-- ModuleScript
-- Location: ServerScriptService > Server > Locks
-- Server-memory lock on individual Pokemon instances. A locked Pokemon cannot be unstationed or moved
-- (used while a thief is carrying it; the wager phase will use it too).
local Locks = {}
local locked = {} -- [uid] = reason

function Locks.Lock(uid, reason) locked[uid] = reason or true end
function Locks.Unlock(uid) locked[uid] = nil end
function Locks.IsLocked(uid) return locked[uid] ~= nil end
function Locks.Reason(uid) return locked[uid] end

return Locks
