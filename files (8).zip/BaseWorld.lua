-- ModuleScript
-- Location: ServerScriptService > Server > BaseWorld
-- The PHYSICAL bases: assigns one to each player, shows their stationed Pokemon on pedestals, hosts the steal prompts.
--
-- Your own maps: put Models in Workspace > Bases. Each Model needs these parts:
--   Zone (a Part covering the base, any transparency), Delivery (pad where thieves deliver), Pedestal1 ... Pedestal12,
--   and optionally Spawn. If Workspace > Bases does not exist, simple placeholder bases are generated for testing.
-- Your own Pokemon models: put Models named by Pokemon id (e.g. "PIKACHU") in ServerStorage > PokemonModels.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local ServerStorage = game:GetService("ServerStorage")

local PokemonData = require(ReplicatedStorage.Shared.Config.PokemonData)
local Rarity = require(ReplicatedStorage.Shared.Config.Rarity)
local StealCfg = require(ReplicatedStorage.Shared.Config.StealConfig)
local DataService = require(script.Parent.DataService)
local Locks = require(script.Parent.Locks)

local PEDESTALS = 12
local BaseWorld = {}
BaseWorld.OnHold = nil    -- function(player, slot, index)  set by StealService
BaseWorld.OnTrigger = nil -- function(player, slot, index)  set by StealService

local slots = {}
local byPlayer = {}

-- ---------- placeholder bases ----------
local function newPart(parent, name, size, pos, color)
	local p = Instance.new("Part")
	p.Name = name
	p.Anchored = true
	p.Size = size
	p.Position = pos
	p.Color = color
	p.Parent = parent
	return p
end

local function buildPlaceholders()
	local folder = Instance.new("Folder")
	folder.Name = "Bases"
	folder.Parent = workspace
	for i = 1, 8 do
		local model = Instance.new("Model")
		model.Name = "Base" .. i
		model.Parent = folder
		local o = Vector3.new((i - 1) * 110 - 385, 0.5, 300)
		newPart(model, "Floor", Vector3.new(100, 1, 100), o, Color3.fromRGB(70, 70, 80))
		local zone = newPart(model, "Zone", Vector3.new(100, 40, 100), o + Vector3.new(0, 20, 0), Color3.fromRGB(80, 200, 120))
		zone.Transparency = 1
		zone.CanCollide = false
		zone.CanQuery = false
		newPart(model, "Delivery", Vector3.new(12, 0.4, 12), o + Vector3.new(0, 1.2, 38), Color3.fromRGB(60, 220, 100))
		local sp = newPart(model, "Spawn", Vector3.new(6, 0.4, 6), o + Vector3.new(0, 1.2, 28), Color3.fromRGB(255, 255, 255))
		sp.Transparency = 1
		sp.CanCollide = false
		for k = 1, PEDESTALS do
			local row, col = math.floor((k - 1) / 6), (k - 1) % 6
			newPart(model, "Pedestal" .. k, Vector3.new(6, 2, 6), o + Vector3.new(-30 + col * 12, 2, -20 + row * 18), Color3.fromRGB(150, 150, 160))
		end
	end
	return folder
end

-- ---------- display ----------
local function makeDisplay(def, pos, ghost)
	local models = ServerStorage:FindFirstChild("PokemonModels")
	local template = models and models:FindFirstChild(def.Id)
	local model
	if template then
		model = template:Clone()
		model:PivotTo(CFrame.new(pos))
		for _, d in ipairs(model:GetDescendants()) do
			if d:IsA("BasePart") then
				d.Anchored = true
				d.CanCollide = false
				if ghost then d.Transparency = 0.8 end
			end
		end
	else
		model = Instance.new("Model")
		model.Name = def.Id
		local p = Instance.new("Part")
		p.Shape = Enum.PartType.Ball
		p.Size = Vector3.one * 4
		p.Anchored = true
		p.CanCollide = false
		p.Material = Enum.Material.Neon
		p.Color = Rarity.Color[def.Rarity] or Color3.new(1, 1, 1)
		p.Transparency = ghost and 0.8 or 0
		p.Position = pos
		p.Parent = model
		model.PrimaryPart = p
	end
	local root = model.PrimaryPart or model:FindFirstChildWhichIsA("BasePart", true)
	if root then
		local gui = Instance.new("BillboardGui")
		gui.Size = UDim2.new(0, 150, 0, 40)
		gui.StudsOffset = Vector3.new(0, 4, 0)
		gui.AlwaysOnTop = true
		gui.Parent = root
		local label = Instance.new("TextLabel")
		label.Size = UDim2.fromScale(1, 1)
		label.BackgroundTransparency = 1
		label.TextScaled = true
		label.Font = Enum.Font.GothamBold
		label.TextColor3 = ghost and Color3.fromRGB(255, 120, 120) or (Rarity.Color[def.Rarity] or Color3.new(1, 1, 1))
		label.TextStrokeTransparency = 0.3
		label.Text = ghost and "STOLEN!" or def.Name
		label.Parent = gui
	end
	return model
end

local function clearDisplay(slot)
	for _, d in pairs(slot.Display) do d:Destroy() end
	slot.Display = {}
end

local function signature(slot, data)
	local parts = { slot.Owner and tostring(slot.Owner.UserId) or "none", tostring(slot.LockedUntil > os.clock()) }
	if data then
		for _, uid in ipairs(data.Stationed) do
			table.insert(parts, uid .. (Locks.IsLocked(uid) and "!" or ""))
		end
	end
	return table.concat(parts, ",")
end

local function buildDisplay(slot, data)
	clearDisplay(slot)
	local locked = slot.LockedUntil > os.clock()
	slot.Zone:SetAttribute("Locked", locked)
	slot.Zone.Color = locked and Color3.fromRGB(220, 60, 60) or Color3.fromRGB(80, 200, 120)
	for i, ped in pairs(slot.Pedestals) do
		local uid = data and data.Stationed[i]
		local inst = uid and data.Owned[uid]
		local def = inst and PokemonData.Get(inst.Id)
		local prompt = slot.Prompts[i]
		if def then
			local stolen = Locks.IsLocked(uid)
			local display = makeDisplay(def, ped.Position + Vector3.new(0, ped.Size.Y / 2 + 3, 0), stolen)
			display.Parent = slot.Model
			slot.Display[i] = display
			prompt.ObjectText = def.Name
			prompt.Enabled = (not stolen) and (not locked)
		else
			prompt.Enabled = false
		end
	end
end

-- ---------- slots ----------
local function collect(model)
	local zone, delivery = model:FindFirstChild("Zone"), model:FindFirstChild("Delivery")
	if not zone or not delivery then
		warn("[BaseWorld] " .. model.Name .. " needs parts named Zone and Delivery. Skipped.")
		return nil
	end
	local slot = {
		Model = model, Zone = zone, Delivery = delivery, Spawn = model:FindFirstChild("Spawn"),
		Pedestals = {}, Prompts = {}, Display = {},
		Owner = nil, Sig = nil, LockedUntil = 0, LockCooldownUntil = 0,
	}
	for i = 1, PEDESTALS do
		local ped = model:FindFirstChild("Pedestal" .. i)
		if ped then
			slot.Pedestals[i] = ped
			local prompt = Instance.new("ProximityPrompt")
			prompt.ActionText = "Steal"
			prompt.ObjectText = "Pokemon"
			prompt.HoldDuration = StealCfg.HoldTime
			prompt.MaxActivationDistance = 10
			prompt.RequiresLineOfSight = false
			prompt.Enabled = false
			prompt.Parent = ped
			prompt.PromptButtonHoldBegan:Connect(function(p)
				if BaseWorld.OnHold then BaseWorld.OnHold(p, slot, i) end
			end)
			prompt.Triggered:Connect(function(p)
				if BaseWorld.OnTrigger then BaseWorld.OnTrigger(p, slot, i) end
			end)
			slot.Prompts[i] = prompt
		end
	end
	return slot
end

function BaseWorld.Init()
	local folder = workspace:FindFirstChild("Bases") or buildPlaceholders()
	for _, model in ipairs(folder:GetChildren()) do
		if model:IsA("Model") then
			local slot = collect(model)
			if slot then table.insert(slots, slot) end
		end
	end
	if #slots == 0 then warn("[BaseWorld] No usable bases found in Workspace > Bases.") end
end

function BaseWorld.GetBase(player)
	return byPlayer[player]
end

function BaseWorld.IsInside(slot, position)
	local rel = slot.Zone.CFrame:PointToObjectSpace(position)
	local half = slot.Zone.Size / 2
	return math.abs(rel.X) <= half.X and math.abs(rel.Y) <= half.Y and math.abs(rel.Z) <= half.Z
end

local function toSpawn(player, char)
	local slot = byPlayer[player]
	if not slot or not StealCfg.SpawnAtBase then return end
	local root = char:WaitForChild("HumanoidRootPart", 5)
	if root then
		task.wait()
		char:PivotTo((slot.Spawn or slot.Delivery).CFrame + Vector3.new(0, 4, 0))
	end
end

function BaseWorld.Assign(player)
	if byPlayer[player] then return byPlayer[player] end
	for _, slot in ipairs(slots) do
		if not slot.Owner then
			slot.Owner = player
			slot.Sig = nil
			byPlayer[player] = slot
			slot.Model:SetAttribute("OwnerUserId", player.UserId)
			slot.Model:SetAttribute("OwnerName", player.Name)
			player.CharacterAdded:Connect(function(char) toSpawn(player, char) end)
			if player.Character then task.spawn(toSpawn, player, player.Character) end
			return slot
		end
	end
	return nil
end

function BaseWorld.Release(player)
	local slot = byPlayer[player]
	if slot then
		clearDisplay(slot)
		for _, prompt in pairs(slot.Prompts) do prompt.Enabled = false end
		slot.Owner = nil
		slot.LockedUntil = 0
		slot.LockCooldownUntil = 0
		slot.Sig = nil
		slot.Model:SetAttribute("OwnerUserId", nil)
		slot.Model:SetAttribute("OwnerName", nil)
		byPlayer[player] = nil
	end
end

function BaseWorld.Start()
	task.spawn(function()
		while true do
			task.wait(1)
			for _, slot in ipairs(slots) do
				if slot.Owner then
					local data = DataService.Get(slot.Owner)
					local sig = signature(slot, data)
					if sig ~= slot.Sig then
						slot.Sig = sig
						buildDisplay(slot, data)
					end
				end
			end
		end
	end)
end

return BaseWorld
