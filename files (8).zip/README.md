# Phase 3: Basic Combat + Stealing (+ physical bases)

Compiles as Luau (17 files). **Not run in Roblox Studio** (I have no Studio). Expect small bugs.
Roster: still the 30 Pokemon from the inherited-powers doc.
This folder holds ONLY new/changed files. Keep your Phase 1 + Phase 2 files for everything not listed here.

## Install
REPLACE (same name/location as before):
`Shared/Remotes`, `Shared/Config/CombatConfig`, `Server/Main` (Script), `Server/CombatService`, `Server/AbilityService`,
`Server/BaseService`, `Server/InventoryService`, `Client/CombatClient`.

ADD:
| File | Type | Location |
|---|---|---|
| Shared/Config/StealConfig, Animations | ModuleScript | ReplicatedStorage > Shared > Config |
| Server/Locks, Notify, BasicCombat, BaseWorld, StealService | ModuleScript | ServerScriptService > Server |
| Client/AnimClient | LocalScript | StarterPlayer > StarterPlayerScripts |

## Controls (test)
**Mouse1** attack (3-hit combo) | **F** hold to block | **Q** dash | **1-6** moves | **R** Mew's borrowed ability.

## How to test stealing (2 players)
Studio > Test tab > Clients and Servers > Players: 2 > Start. Each player spawns at their own placeholder base
(a plate with 12 pedestals; your Pokemon float above them; green pad = delivery).
1. Player A walks to Player B's base, holds **E** on a pedestal for 3 seconds.
2. A now carries it (slower, "STOLEN!" ghost on the pedestal). B can fight A (raid is on).
3. If A reaches A's own green pad, ownership transfers. If A dies, leaves, or takes more than 90 s, it returns.
4. Owner can lock the base: `Api.Request("LockBase")` (UI button comes with the UI phase).

## Rules implemented (from your architecture doc)
- Thief enters another base, takes a Pokemon, owner may respond, ownership changes ONLY on delivery to the thief's own base.
- New owner gets it stationed if there is room (otherwise owned but not stationed).
- Previous owner loses its income and, if equipped, its ability (loadout slot cleared).
- Defensive system: base lock (duration + cooldown). Pokemon being carried are locked (cannot be unstationed or moved).
- Players can only fight outside matches during a raid (thief <-> victim). Everything else stays non-damageable on live servers.

## Safety decisions
- You can only steal from players in the SAME server. Offline players / other servers are never touched.
- Transfer is all-or-nothing in memory, then both players are saved immediately.
  Known gap: if the server crashes in the milliseconds between the two saves, one file could be stale (duplicate or lost Pokemon).
  Fixing that fully needs a cross-server transaction log; it goes into the security/hardening phase.
- `StealService.OnLeaving` runs before the data is released, so nobody can steal from a player whose data is being saved.

## Values I invented (tunable)
StealConfig.lua: hold 3 s, carry 90 s, cooldown 20 s, lock 120 s / cooldown 300 s, range, speed while carrying.
CombatConfig.lua: combo damage 8/8/14, swing interval 0.45 s, melee range 7, 60 degree cone, stuns, block (70% reduction, drains stamina,
guard break stun 1.5 s), dash (25 studs, 10 stamina, 2 s cooldown, 0.2 s invulnerable).

## Limits
- 8 placeholder bases. A 9th player in a server gets no base (cannot steal or deliver). Add more Models to Workspace > Bases for more.
- Block works from all directions. Basic hits land at the moment of the swing (no wind-up/hit window yet).
- No animations exist: paste your ids into Animations.lua (AnimClient plays them for every character). VFX/sounds are not included.
- Pokemon on pedestals are colored balls until you add models to ServerStorage > PokemonModels (named by Pokemon id).
- Your own map bases: Models in Workspace > Bases with parts named Zone, Delivery, Pedestal1..Pedestal12 (+ optional Spawn).
- Stealing numbers/rules not in your doc: base lock, carry timer, raid window, spawn-at-base. Tell me if you want any changed.

## Next
Phase 4: Ranked PvP + wager PvP (needs your decision on disconnects/ties/cancellations; I will propose safe defaults).
