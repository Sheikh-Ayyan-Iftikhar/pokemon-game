# Phase 5: Rebirth

Compiles as Luau (6 files). **Not run in Roblox Studio** (I have no Studio). The pure logic (cost curve, discount caps, which Pokemon stay stationed) was unit-tested.
Roster: the 30 Pokemon from the inherited-powers doc. This folder holds ONLY new/changed files; keep Phase 1-4 for the rest.

## Install
REPLACE: `Server/Main` (Script), `Server/BaseService`, `Server/InventoryService`.
ADD: `Server/RebirthService` (ModuleScript, ServerScriptService > Server), `Shared/Config/RebirthConfig` (ModuleScript, ReplicatedStorage > Shared > Config),
`Client/RebirthTest` (LocalScript, StarterPlayer > StarterPlayerScripts; test keys only).

## Test (Studio)
**C** = give yourself 1,000,000 coins (Studio only) | **B** = rebirth info | **V** = rebirth.
You will see coins/base level reset, Rebirths go up, income multiplier rise, and your equipped Pokemon stay stationed.

## Rules (from your architecture doc)
- Rebirth = economic reset only. **Collection is kept.** Rewards are economic unlocks. **No combat power is increased** (damage/ability strength untouched).
- Combat loadout is not reset: equipped Pokemon are kept stationed first. Pokemon that no longer fit are **unstationed, never deleted**.

## My defaults where the doc is silent (all in RebirthConfig.lua / Economy.lua)
| Thing | Default |
|---|---|
| Resets | coins (back to starting coins), uncollected income, base level (set `ResetBaseLevel = false` to keep base upgrades) |
| Keeps | all Pokemon, equipped loadout, ranked standing, settings |
| Cost | 50,000 x 2.2^rebirths (rebirth #6 costs ~2.6M; #20 would be ~160B: tune this once real income numbers exist) |
| Max rebirths | 20 |
| Economic unlocks per rebirth | +25% passive income, -3% Pokemon prices and base-upgrade cost (max -30%), income pool +30 min, offline window +30 min |
| Not unlocked | Pokemon access. I did NOT make Legendary/Mythical purchasable via rebirth (it would indirectly raise combat power). Say if you want that |

## Safety
- Server-authoritative. The client sends `expected = rebirths it saw`; a stale or double click cannot rebirth twice.
- Blocked during a match, a raid (thief or victim), or while any stationed Pokemon is locked (carried/wagered).
- The reset is one block with no yields (all-or-nothing), then saved immediately.

## Limits
- No rebirth UI yet; actions `RebirthInfo` and `Rebirth` are ready for the UI phase (info returns cost, blocker, next multipliers, what resets/keeps).
- A shrunk base means fewer Pokemon earning income after rebirth (they stay owned; re-station them as the base is upgraded again).

## Next
Phase 6: security/hardening pass (movement and teleport checks, the transfer crash gap, cross-server ranked queue via MemoryStoreService, win-trading checks),
then Phase 7: UI. Maps, 3D models and animations remain Studio/art work on your side.
