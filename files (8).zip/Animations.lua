-- ModuleScript
-- Location: ReplicatedStorage > Shared > Config > Animations
-- I cannot create Roblox animations. Make them in the Animation Editor, publish, and paste the ids here
-- as "rbxassetid://123456". Empty string = no animation (combat still works, just without animation).
return {
	Attack = { "", "", "" },   -- combo hit 1, 2, 3
	HitReact = "",
	Block = "",                -- looped while blocking
	Dash = "",
}
